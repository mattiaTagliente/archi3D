"""
Main FScoreEvaluator class for 3D model comparison.
"""

import open3d as o3d
import numpy as np
import pandas as pd
import yaml
from pathlib import Path
import logging
from datetime import datetime
import copy
import sys
import time

from .alignment import normalize_and_pre_align, align_meshes
from .metrics import compute_fscore
from .visualization import save_visualization
from .utils import euler_xyz_from_rotation_matrix, get_environment_info, get_mesh_metadata
from .fbx_converter import FBXConverter, resolve_model_path, save_conversion_log
from .workspace import (
    resolve_workspace_path,
    resolve_model_path_in_workspace,
    get_results_dir,
    get_conversion_log_path,
)

logger = logging.getLogger(__name__)


class FScoreEvaluator:
    """Main class for computing F-scores between 3D models with comprehensive logging."""

    def __init__(self, config_path, spinner_state=None, workspace_path=None):
        """
        Initialize with configuration file and optional spinner state.

        Args:
            config_path: Path to YAML configuration file
            spinner_state: Optional shared state dict for spinner updates
            workspace_path: Optional workspace root path (for archi3D integration)
        """
        self.config_path = Path(config_path)
        self.results = []
        self._spinner_state = spinner_state
        self._env_info = get_environment_info()

        # Resolve workspace
        self.workspace = resolve_workspace_path(workspace_path)
        if self.workspace:
            logger.info(f"Using workspace: {self.workspace}")

        # Initialize FBX converter
        self.fbx_converter = FBXConverter()
        if self.fbx_converter.is_available():
            logger.info("FBX converter available")
        else:
            logger.warning("FBX converter not available - FBX files will not be supported")

        # Load configuration
        with open(self.config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)

        logger.info(f"Loaded configuration with {len(self.config['test_items'])} items")
        logger.info(f"Environment: Python {self._env_info['python_version']}, "
                   f"Open3D {self._env_info['open3d_version']}")

    def _update_status(self, text):
        """Thread-safe method to update the status text for the spinner."""
        if self._spinner_state:
            self._spinner_state['text'] = text

    def load_mesh(self, filepath, auto_convert_fbx=True):
        """
        Load a 3D mesh file, converting from FBX if necessary.

        Args:
            filepath: Path to mesh file (supports .glb and .fbx)
            auto_convert_fbx: If True, automatically convert FBX to GLB

        Returns:
            Open3D TriangleMesh
        """
        filepath = Path(filepath)

        # Resolve model path (handles FBX conversion)
        resolved_path = resolve_model_path(
            filepath,
            auto_convert_fbx=auto_convert_fbx,
            fbx_converter=self.fbx_converter
        )

        if resolved_path is None:
            raise FileNotFoundError(f"File not found or conversion failed: {filepath}")

        mesh = o3d.io.read_triangle_mesh(str(resolved_path))
        if not mesh.has_vertices():
            raise ValueError(f"Mesh has no vertices: {resolved_path}")

        logger.info(
            f"Loaded mesh: {resolved_path.name} "
            f"(Vertices: {len(mesh.vertices)}, Triangles: {len(mesh.triangles)})"
        )
        return mesh

    def _process_item(self, item):
        """
        Process a single test item with comprehensive logging.

        Args:
            item: Test item dict from configuration
        """
        try:
            t0 = time.perf_counter()

            # Resolve paths (workspace-aware)
            gt_path = resolve_model_path_in_workspace(item['ground_truth'], self.workspace)
            pred_path = resolve_model_path_in_workspace(item['test_model'], self.workspace)

            # Load meshes (with FBX conversion if needed)
            self._update_status(f"Loading models for '{item['id']}'...")
            gt_mesh_orig = self.load_mesh(gt_path, auto_convert_fbx=True)
            pred_mesh_orig = self.load_mesh(pred_path, auto_convert_fbx=True)

            # Extract mesh metadata
            gt_metadata = get_mesh_metadata(gt_mesh_orig)
            pred_metadata = get_mesh_metadata(pred_mesh_orig)

            mesh_log = {
                "gt_vertices": gt_metadata["vertices"],
                "gt_triangles": gt_metadata["triangles"],
                "gt_bbox_volume": gt_metadata["bbox_volume"],
                "gt_bbox_surface_area": gt_metadata["bbox_surface_area"],
                "gt_bbox_extent": gt_metadata["bbox_extent"],
                "pred_vertices": pred_metadata["vertices"],
                "pred_triangles": pred_metadata["triangles"],
                "pred_bbox_volume": pred_metadata["bbox_volume"],
                "pred_bbox_surface_area": pred_metadata["bbox_surface_area"],
                "pred_bbox_extent": pred_metadata["bbox_extent"],
            }

            t_load = time.perf_counter()

            # Work on copies
            gt_mesh = copy.deepcopy(gt_mesh_orig)
            pred_mesh = copy.deepcopy(pred_mesh_orig)

            # Check units
            units = item.get('units', 'meters')
            if units != 'meters':
                logger.warning(
                    "Warning: Non-meter units detected. "
                    "Please ensure models are in meters for best results."
                )

            # Pre-alignment
            aligned_pred_mesh, pre_log = normalize_and_pre_align(
                pred_mesh, gt_mesh, self._update_status
            )
            t_prealign = time.perf_counter()

            # Fine alignment (ICP)
            aligned_pred_mesh, icp_log = align_meshes(
                aligned_pred_mesh, gt_mesh, self._update_status
            )
            t_icp = time.perf_counter()

            # Compute F-score
            metrics = compute_fscore(gt_mesh, aligned_pred_mesh, update_callback=self._update_status)
            t_fscore = time.perf_counter()

            # Compose total 4x4 transform (prealign then ICP)
            T_prealign = np.array(pre_log["T_prealign"])
            T_icp = np.array(icp_log["T_icp"])
            T_total = T_icp @ T_prealign

            R = T_total[:3, :3]
            t = T_total[:3, 3]
            euler_angles = euler_xyz_from_rotation_matrix(R)

            # Build result
            result = item.copy()  # Start with original config data
            result.update(metrics)
            result.update(mesh_log)

            # Status and timestamp
            result['status'] = 'PASS' if metrics['fscore'] >= 0.65 else 'FAIL'
            result['timestamp'] = datetime.now().isoformat()
            result['units'] = units

            # Transform information
            result.update({
                "transform_total": T_total.tolist(),
                "rotation_matrix": R.tolist(),
                "euler_deg_xyz": euler_angles,
                "translation_xyz": tuple(map(float, t)),
            })

            # Pre-alignment details
            result.update({
                "prealign_method": pre_log["prealign_method"],
                "scale_applied": pre_log["scale_applied"],
                "voxel_size": pre_log["voxel_size"],
                "feature_distance_thresh": pre_log["feature_distance_thresh"],
                "normal_radius": pre_log["normal_radius"],
                "fpfh_radius": pre_log["fpfh_radius"],
                "down_src_pts": pre_log["down_src_pts"],
                "down_tgt_pts": pre_log["down_tgt_pts"],
            })

            if pre_log["prealign_method"] == "ransac_fpfh":
                result.update({
                    "ransac_fitness": pre_log["ransac_fitness"],
                    "ransac_inlier_rmse": pre_log["ransac_inlier_rmse"],
                })
            elif pre_log["prealign_method"] == "pca_fallback":
                result.update({
                    "pca_best_fitness": pre_log["pca_best_fitness"],
                })

            # ICP details
            result.update({
                "icp_sample_points": icp_log["icp_sample_points"],
                "icp_sample_method": icp_log["icp_sample_method"],
                "poisson_init_factor": icp_log["poisson_init_factor"],
                "icp_max_d_coarse": icp_log["icp_max_d_coarse"],
                "icp_max_d_fine": icp_log["icp_max_d_fine"],
                "icp_fitness": icp_log["icp_fitness"],
                "icp_inlier_rmse": icp_log["icp_inlier_rmse"],
            })

            # Timing information
            result.update({
                "t_load_s": t_load - t0,
                "t_prealign_s": t_prealign - t_load,
                "t_icp_s": t_icp - t_prealign,
                "t_fscore_s": t_fscore - t_icp,
                "t_total_s": t_fscore - t0,
            })

            # Environment info
            result.update(self._env_info)

            self.results.append(result)

            # Save visualization
            self._update_status(f"Saving visualization for '{item['id']}'...")
            vis_path = save_visualization(
                item['id'], gt_mesh_orig, aligned_pred_mesh, workspace=self.workspace
            )
            if vis_path:
                self.results[-1]["vis_path"] = str(vis_path)

        except Exception as e:
            logger.error(f"\nError processing {item['id']}: {str(e)}")
            # Copy original data even on error
            result = item.copy()
            result.update({
                'error': str(e),
                'status': 'ERROR',
                'timestamp': datetime.now().isoformat()
            })
            self.results.append(result)

    def run_evaluation(self):
        """Run evaluation on all configured items."""
        logger.info("\n" + "=" * 70)
        logger.info("Starting F-score evaluation")
        logger.info("=" * 70)

        items = self.config['test_items']
        total_items = len(items)

        for i, item in enumerate(items):
            self._update_status(f"Processing item {i+1}/{total_items}: {item['id']}")
            logger.info(f"\n--- Processing Item: {item['id']} ---")
            self._process_item(item)

        self._update_status("Finalizing and saving results...")
        self.save_results()
        self.save_fbx_conversion_log()
        self.print_summary()

    def save_results(self):
        """Save results to CSV and Excel with formatting."""
        if not self.results:
            logger.warning("Warning: No results to save.")
            return

        # Sort results by original config order
        item_order = {item['id']: i for i, item in enumerate(self.config['test_items'])}
        sorted_results = sorted(self.results, key=lambda r: item_order.get(r['id'], 999))

        df = pd.DataFrame(sorted_results)

        # Get results directory (workspace-aware)
        results_dir = get_results_dir(self.workspace)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = results_dir / f"fscore_results_{timestamp}.csv"
        excel_path = results_dir / f"fscore_results_{timestamp}.xlsx"

        # Save CSV
        df.to_csv(csv_path, index=False)
        logger.info(f"\nResults saved to: {csv_path}")

        # Save Excel with formatting
        try:
            with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Results', index=False)
                worksheet = writer.sheets['Results']

                # Auto-adjust column widths
                for column in df:
                    column_length = max(df[column].astype(str).map(len).max(), len(column))
                    col_idx = df.columns.get_loc(column) + 1
                    from openpyxl.utils import get_column_letter
                    worksheet.column_dimensions[get_column_letter(col_idx)].width = column_length + 2

                # Color-code status column
                from openpyxl.styles import PatternFill
                green_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
                red_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
                yellow_fill = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')

                if 'status' in df.columns:
                    status_col_idx = df.columns.get_loc('status') + 1
                    for row_idx, row in df.iterrows():
                        cell = worksheet.cell(row=row_idx + 2, column=status_col_idx)
                        if row['status'] == 'PASS':
                            cell.fill = green_fill
                        elif row['status'] == 'FAIL':
                            cell.fill = red_fill
                        elif row['status'] == 'ERROR':
                            cell.fill = yellow_fill

            logger.info(f"Excel report saved to: {excel_path}")

        except ImportError:
            logger.warning(
                "Warning: `openpyxl` not installed. Skipping Excel export. "
                "Install with `pip install openpyxl`"
            )
        except Exception as e:
            logger.error(f"Error: Failed to save Excel report: {e}")

    def save_fbx_conversion_log(self):
        """Save FBX conversion log if any conversions occurred."""
        log_path = get_conversion_log_path(self.workspace)
        save_conversion_log(log_path)

    def print_summary(self):
        """Print evaluation summary."""
        if not self.results:
            logger.warning("Warning: No results to summarize.")
            return

        df = pd.DataFrame(self.results)
        error_count = len(df[df['status'] == 'ERROR'])
        valid_results = df[df['status'] != 'ERROR']

        if len(valid_results) == 0:
            logger.error("Error: No valid results to summarize!")
            return

        total_items = len(self.config['test_items'])
        processed_items = len(valid_results)
        passed_items = len(valid_results[valid_results['status'] == 'PASS'])
        pass_rate = (passed_items / processed_items) * 100 if processed_items > 0 else 0

        avg_fscore = valid_results['fscore'].mean() if 'fscore' in valid_results else 0.0
        avg_precision = valid_results['precision'].mean() if 'precision' in valid_results else 0.0
        avg_recall = valid_results['recall'].mean() if 'recall' in valid_results else 0.0

        summary = (
            f"\n{'=' * 70}\n"
            f"EVALUATION SUMMARY\n"
            f"{'=' * 70}\n"
            f"Total items:     {total_items}\n"
            f"Processed:       {processed_items}\n"
            f"Errors:          {error_count}\n"
            f"Passed:          {passed_items}\n"
            f"Failed:          {processed_items - passed_items}\n"
            f"Pass rate:       {pass_rate:.1f}% (of processed items)\n\n"
            f"Average metrics (on processed items):\n"
            f"  F-score:       {avg_fscore:.3f}\n"
            f"  Precision:     {avg_precision:.3f}\n"
            f"  Recall:        {avg_recall:.3f}\n"
            f"{'=' * 70}\n"
        )

        if pass_rate >= 90:
            summary += "OVERALL RESULT: DATASET PASSES (>=90% of processed items have F-score >= 0.65)\n"
        else:
            summary += "OVERALL RESULT: DATASET FAILS (<90% of processed items have F-score >= 0.65)\n"

        summary += "=" * 70
        logger.info(summary)


# ---------------------------------------------------------------------------
# Simple API for archi3D integration
# ---------------------------------------------------------------------------


def _rotation_matrix_to_quaternion(R):
    """
    Convert a 3x3 rotation matrix to quaternion (w, x, y, z).

    Args:
        R: 3x3 numpy rotation matrix

    Returns:
        dict: {"w": float, "x": float, "y": float, "z": float}
    """
    import numpy as np

    # Ensure R is a numpy array
    R = np.asarray(R)

    trace = np.trace(R)
    if trace > 0:
        s = 0.5 / np.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (R[2, 1] - R[1, 2]) * s
        y = (R[0, 2] - R[2, 0]) * s
        z = (R[1, 0] - R[0, 1]) * s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s

    return {"w": float(w), "x": float(x), "y": float(y), "z": float(z)}


def evaluate_one(
    gt_path: str,
    cand_path: str,
    n_points: int = 100000,
    out_dir: str | None = None,
    timeout_s: int | None = None,
) -> dict:
    """
    Evaluate a single ground-truth vs candidate mesh pair.

    This is the simple API for archi3D integration. It performs:
    1. Mesh loading (with automatic FBX conversion if needed)
    2. Automatic alignment (centering, scaling, RANSAC/PCA, ICP)
    3. F-score computation with distance statistics
    4. Comparison visualization export

    Args:
        gt_path: Path to ground truth mesh file (.glb or .fbx)
        cand_path: Path to candidate/predicted mesh file (.glb or .fbx)
        n_points: Number of points for Poisson disk sampling (default: 100000)
        out_dir: Optional output directory for result.json and visualization
        timeout_s: Optional timeout in seconds (not currently enforced)

    Returns:
        dict: Canonical payload with metrics and metadata:
            {
                "fscore": float,
                "precision": float,
                "recall": float,
                "chamfer_l2": float,
                "n_points": int,
                "alignment": {
                    "scale": float,
                    "rotation_quat": {"w": float, "x": float, "y": float, "z": float},
                    "translation": {"x": float, "y": float, "z": float}
                },
                "dist_stats": {"mean": float, "median": float, "p95": float, "p99": float, "max": float},
                "mesh_meta": {
                    "gt_vertices": int, "gt_triangles": int,
                    "pred_vertices": int, "pred_triangles": int
                },
                "alignment_log": {
                    "prealign_method": str,
                    "scale_applied": float,
                    "ransac_fitness": float | None,
                    "icp_fitness": float,
                    "icp_inlier_rmse": float
                },
                "timing": {
                    "t_load_s": float,
                    "t_prealign_s": float,
                    "t_icp_s": float,
                    "t_fscore_s": float,
                    "t_total_s": float
                },
                "visualization_path": str | None,
                "version": str,
                "config_hash": str
            }

    Raises:
        FileNotFoundError: If mesh files don't exist or can't be converted
        ValueError: If meshes have no vertices
    """
    import hashlib
    import json
    import copy
    import time
    from pathlib import Path

    from . import __version__
    from .alignment import normalize_and_pre_align, align_meshes
    from .metrics import compute_fscore
    from .fbx_converter import FBXConverter, resolve_model_path
    from .utils import get_mesh_metadata
    from .visualization import save_visualization

    t_start = time.perf_counter()

    # Initialize FBX converter
    fbx_converter = FBXConverter()

    # Resolve and load ground truth mesh
    gt_resolved = resolve_model_path(Path(gt_path), auto_convert_fbx=True, fbx_converter=fbx_converter)
    if gt_resolved is None:
        raise FileNotFoundError(f"Ground truth file not found or conversion failed: {gt_path}")

    gt_mesh_orig = o3d.io.read_triangle_mesh(str(gt_resolved))
    if not gt_mesh_orig.has_vertices():
        raise ValueError(f"Ground truth mesh has no vertices: {gt_resolved}")

    # Resolve and load candidate mesh
    cand_resolved = resolve_model_path(Path(cand_path), auto_convert_fbx=True, fbx_converter=fbx_converter)
    if cand_resolved is None:
        raise FileNotFoundError(f"Candidate file not found or conversion failed: {cand_path}")

    cand_mesh_orig = o3d.io.read_triangle_mesh(str(cand_resolved))
    if not cand_mesh_orig.has_vertices():
        raise ValueError(f"Candidate mesh has no vertices: {cand_resolved}")

    logger.info(f"Loaded GT mesh: {gt_resolved.name} ({len(gt_mesh_orig.vertices)} vertices)")
    logger.info(f"Loaded candidate mesh: {cand_resolved.name} ({len(cand_mesh_orig.vertices)} vertices)")

    # Extract mesh metadata before alignment modifies them
    gt_meta = get_mesh_metadata(gt_mesh_orig)
    cand_meta = get_mesh_metadata(cand_mesh_orig)

    t_load = time.perf_counter()

    # Work on copies for alignment
    gt_work = copy.deepcopy(gt_mesh_orig)
    cand_work = copy.deepcopy(cand_mesh_orig)

    # Pre-alignment (centering, scaling, global registration)
    logger.info("Running pre-alignment (centering, scaling, RANSAC/PCA)...")
    aligned_cand, pre_log = normalize_and_pre_align(cand_work, gt_work, update_callback=None)
    t_prealign = time.perf_counter()

    # Fine alignment (ICP)
    logger.info("Running ICP refinement...")
    aligned_cand, icp_log = align_meshes(aligned_cand, gt_work, update_callback=None)
    t_icp = time.perf_counter()

    # Compute F-score metrics
    logger.info("Computing F-score metrics...")
    metrics = compute_fscore(gt_work, aligned_cand, update_callback=None)
    t_fscore = time.perf_counter()

    # Compose total transform
    T_prealign = np.array(pre_log["T_prealign"])
    T_icp = np.array(icp_log["T_icp"])
    T_total = T_icp @ T_prealign

    # Extract rotation and translation from total transform
    R = T_total[:3, :3]
    t = T_total[:3, 3]

    # Build canonical payload
    payload = {
        "fscore": metrics["fscore"],
        "precision": metrics["precision"],
        "recall": metrics["recall"],
        "chamfer_l2": metrics["chamfer_l2"],
        "n_points": metrics["eval_points"],
        "alignment": {
            "scale": pre_log["scale_applied"],
            "rotation_quat": _rotation_matrix_to_quaternion(R),
            "translation": {"x": float(t[0]), "y": float(t[1]), "z": float(t[2])},
        },
        "dist_stats": {
            "mean": metrics["gt2pred_mean"],
            "median": metrics["gt2pred_median"],
            "p95": metrics["gt2pred_p95"],
            "p99": metrics.get("gt2pred_p99", metrics["gt2pred_p95"]),  # p99 not in current metrics
            "max": metrics.get("gt2pred_max", metrics["gt2pred_p95"] * 1.5),  # estimate if not available
        },
        "mesh_meta": {
            "gt_vertices": gt_meta["vertices"],
            "gt_triangles": gt_meta["triangles"],
            "pred_vertices": cand_meta["vertices"],
            "pred_triangles": cand_meta["triangles"],
        },
        "alignment_log": {
            "prealign_method": pre_log["prealign_method"],
            "scale_applied": pre_log["scale_applied"],
            "ransac_fitness": pre_log.get("ransac_fitness"),
            "pca_best_fitness": pre_log.get("pca_best_fitness"),
            "icp_fitness": icp_log["icp_fitness"],
            "icp_inlier_rmse": icp_log["icp_inlier_rmse"],
        },
        "timing": {
            "t_load_s": t_load - t_start,
            "t_prealign_s": t_prealign - t_load,
            "t_icp_s": t_icp - t_prealign,
            "t_fscore_s": t_fscore - t_icp,
            "t_total_s": t_fscore - t_start,
        },
        "visualization_path": None,
        "version": __version__,
        "config_hash": hashlib.sha1(f"n_points={n_points}".encode()).hexdigest()[:8],
    }

    # Save comparison visualization if out_dir specified
    if out_dir:
        out_path = Path(out_dir)
        out_path.mkdir(parents=True, exist_ok=True)

        # Save visualization GLB (GT gray, aligned prediction red)
        job_id = Path(cand_path).stem  # Use candidate filename as item_id
        vis_path = save_visualization(
            item_id=job_id,
            gt_mesh=gt_mesh_orig,
            pred_mesh=aligned_cand,
            output_dir=out_path,
        )
        if vis_path:
            payload["visualization_path"] = str(vis_path)
            logger.info(f"Saved comparison visualization: {vis_path}")

        # Write result.json
        result_file = out_path / "result.json"
        with result_file.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        logger.info(f"Saved result.json: {result_file}")

    # Log summary
    logger.info(
        f"Evaluation complete: F-score={payload['fscore']:.3f}, "
        f"Precision={payload['precision']:.3f}, "
        f"Recall={payload['recall']:.3f}, "
        f"Total time={payload['timing']['t_total_s']:.1f}s"
    )

    return payload
