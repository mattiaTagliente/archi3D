"""
Mesh alignment functions including pre-alignment and ICP refinement.
"""

import numpy as np
import open3d as o3d
import copy
import logging
from itertools import permutations
from .utils import get_rigid_transform_estimation

logger = logging.getLogger(__name__)


def preprocess_point_cloud(pcd, voxel_size):
    """
    Downsample point cloud and compute FPFH features for registration.

    Args:
        pcd: Open3D PointCloud
        voxel_size: Voxel size for downsampling

    Returns:
        tuple: (downsampled_pcd, fpfh_features)
    """
    pcd_down = pcd.voxel_down_sample(voxel_size)
    radius_normal = voxel_size * 2
    pcd_down.estimate_normals(
        o3d.geometry.KDTreeSearchParamHybrid(radius=radius_normal, max_nn=30)
    )
    radius_feature = voxel_size * 5
    fpfh = o3d.pipelines.registration.compute_fpfh_feature(
        pcd_down,
        o3d.geometry.KDTreeSearchParamHybrid(radius=radius_feature, max_nn=100)
    )
    return pcd_down, fpfh


def pca_permutation_fallback(source_mesh, target_mesh, update_callback=None):
    """
    PCA-based alignment fallback when RANSAC fails.
    Tests 48 axis permutations/reflections and selects best ICP fitness.

    Args:
        source_mesh: Source Open3D TriangleMesh
        target_mesh: Target Open3D TriangleMesh
        update_callback: Optional callback for status updates

    Returns:
        tuple: (aligned_source_mesh, pca_log_dict)
    """
    if update_callback:
        update_callback("Executing PCA permutation fallback...")

    source_mesh_copy = copy.deepcopy(source_mesh)
    source_points = np.asarray(source_mesh_copy.vertices)
    target_points = np.asarray(target_mesh.vertices)

    if len(source_points) < 3 or len(target_points) < 3:
        logger.warning("Skipping PCA alignment due to insufficient points.")
        return source_mesh_copy, {"pca_best_fitness": 0.0, "pca_rotation": np.eye(3).tolist()}

    # Compute PCA eigenvectors
    cov_source = np.cov(source_points, rowvar=False)
    cov_target = np.cov(target_points, rowvar=False)
    _, evecs_source = np.linalg.eigh(cov_source)
    _, evecs_target = np.linalg.eigh(cov_target)

    best_fitness, best_rotation = -1.0, np.identity(3)

    # Sample for evaluation
    source_pcd_eval = source_mesh_copy.sample_points_poisson_disk(2000)
    target_pcd_eval = target_mesh.sample_points_poisson_disk(2000)
    target_bbox_diag = np.linalg.norm(target_mesh.get_axis_aligned_bounding_box().get_extent())
    eval_distance_threshold = target_bbox_diag * 0.1

    # Test all 48 permutations/reflections
    for p in permutations([0, 1, 2]):
        permuted_evecs_target = evecs_target[:, list(p)]
        for i in [-1, 1]:
            for j in [-1, 1]:
                for k in [-1, 1]:
                    reflection = np.diag([i, j, k])
                    current_rotation = permuted_evecs_target @ reflection @ evecs_source.T

                    temp_source_pcd = o3d.geometry.PointCloud(source_pcd_eval)
                    temp_source_pcd.rotate(current_rotation, center=(0, 0, 0))

                    eval_reg = o3d.pipelines.registration.registration_icp(
                        temp_source_pcd,
                        target_pcd_eval,
                        eval_distance_threshold,
                        np.identity(4),
                        o3d.pipelines.registration.TransformationEstimationPointToPoint(),
                        o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=20)
                    )

                    if eval_reg.fitness > best_fitness:
                        best_fitness, best_rotation = eval_reg.fitness, current_rotation

    logger.info(f"  - PCA fallback best fitness: {best_fitness:.4f}")
    source_mesh_copy.rotate(best_rotation, center=(0, 0, 0))

    pca_log = {
        "pca_best_fitness": float(best_fitness),
        "pca_rotation": best_rotation.tolist(),
    }

    return source_mesh_copy, pca_log


def normalize_and_pre_align(source_mesh, target_mesh, update_callback=None):
    """
    Pre-alignment stage: center, scale, and perform global registration.

    Args:
        source_mesh: Source Open3D TriangleMesh
        target_mesh: Target Open3D TriangleMesh
        update_callback: Optional callback for status updates

    Returns:
        tuple: (aligned_source_mesh, pre_align_log_dict)
    """
    if update_callback:
        update_callback("Running automatic pre-alignment...")

    # Center both meshes
    src_center = source_mesh.get_center()
    tgt_center = target_mesh.get_center()
    source_mesh.translate(-src_center, relative=True)
    target_mesh.translate(-tgt_center, relative=True)

    # Compute scale
    src_diag = np.linalg.norm(source_mesh.get_axis_aligned_bounding_box().get_extent())
    tgt_diag = np.linalg.norm(target_mesh.get_axis_aligned_bounding_box().get_extent())

    if src_diag == 0 or tgt_diag == 0:
        logger.warning("Warning: Degenerate bounding box; skipping scaling")
        scale = 1.0
    else:
        scale = tgt_diag / src_diag
        source_mesh.scale(scale, center=(0, 0, 0))
        logger.info(f"  - Applied isotropic scale factor {scale:.4f}")

    # Initialize log
    pre_log = {
        "src_center": tuple(map(float, src_center)),
        "tgt_center": tuple(map(float, tgt_center)),
        "scale_applied": float(scale),
        "prealign_method": None,
        "ransac_fitness": None,
        "ransac_inlier_rmse": None,
        "pca_best_fitness": None,
        "T_prealign": np.eye(4).tolist(),
    }

    # Build cumulative transform
    T = np.eye(4)

    # Center transform
    Tc = np.eye(4)
    Tc[:3, 3] = -src_center
    T = Tc @ T

    # Scale transform
    Ts = np.eye(4)
    Ts[0, 0] = Ts[1, 1] = Ts[2, 2] = scale
    T = Ts @ T

    # RANSAC global registration
    src_pcd = source_mesh.sample_points_uniformly(10000)
    tgt_pcd = target_mesh.sample_points_uniformly(10000)
    voxel_size = tgt_diag * 0.02

    src_down, src_fpfh = preprocess_point_cloud(src_pcd, voxel_size)
    tgt_down, tgt_fpfh = preprocess_point_cloud(tgt_pcd, voxel_size)

    distance_threshold = voxel_size * 1.5

    # Log feature extraction parameters
    pre_log["voxel_size"] = float(voxel_size)
    pre_log["feature_distance_thresh"] = float(distance_threshold)
    pre_log["normal_radius"] = float(voxel_size * 2)
    pre_log["fpfh_radius"] = float(voxel_size * 5)
    pre_log["down_src_pts"] = int(len(src_down.points))
    pre_log["down_tgt_pts"] = int(len(tgt_down.points))

    if update_callback:
        update_callback("Running RANSAC-based global registration...")

    result = o3d.pipelines.registration.registration_ransac_based_on_feature_matching(
        src_down, tgt_down, src_fpfh, tgt_fpfh,
        True,
        distance_threshold,
        get_rigid_transform_estimation(),
        4,
        [
            o3d.pipelines.registration.CorrespondenceCheckerBasedOnEdgeLength(0.9),
            o3d.pipelines.registration.CorrespondenceCheckerBasedOnDistance(distance_threshold)
        ],
        o3d.pipelines.registration.RANSACConvergenceCriteria(4000000, 500)
    )

    # Check RANSAC fitness and potentially fallback to PCA
    if result.fitness < 0.15:
        logger.warning(
            f"Warning: RANSAC fitness too low ({result.fitness:.3f}); "
            f"falling back to PCA permutation sweep."
        )
        source_mesh, pca_log = pca_permutation_fallback(source_mesh, target_mesh, update_callback)
        pre_log["prealign_method"] = "pca_fallback"
        pre_log["pca_best_fitness"] = pca_log["pca_best_fitness"]

        # PCA rotation
        R = np.array(pca_log["pca_rotation"])
        TR = np.eye(4)
        TR[:3, :3] = R
        T = TR @ T
    else:
        logger.info(f"  - Global registration success (fitness {result.fitness:.3f})")
        source_mesh.transform(result.transformation)
        pre_log["prealign_method"] = "ransac_fpfh"
        pre_log["ransac_fitness"] = float(result.fitness)
        pre_log["ransac_inlier_rmse"] = float(result.inlier_rmse)
        T = result.transformation @ T

    # Translate back to target center
    target_mesh.translate(tgt_center, relative=True)
    source_mesh.translate(tgt_center, relative=True)

    Tb = np.eye(4)
    Tb[:3, 3] = tgt_center
    T = Tb @ T

    pre_log["T_prealign"] = T.tolist()

    return source_mesh, pre_log


def align_meshes(source_mesh, target_mesh, update_callback=None):
    """
    Fine alignment using two-stage ICP: coarse point-to-point, then fine point-to-plane.

    Args:
        source_mesh: Source Open3D TriangleMesh (pre-aligned)
        target_mesh: Target Open3D TriangleMesh
        update_callback: Optional callback for status updates

    Returns:
        tuple: (aligned_source_mesh, icp_log_dict)
    """
    if update_callback:
        update_callback("Aligning meshes (coarse -> fine ICP)...")

    def to_pcd(mesh, n=8000):
        """Convert mesh to point cloud with normals."""
        pcd = mesh.sample_points_poisson_disk(n, init_factor=5)
        pcd.estimate_normals(
            o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30)
        )
        return pcd

    src_pcd = to_pcd(source_mesh)
    tgt_pcd = to_pcd(target_mesh)

    diag = np.linalg.norm(target_mesh.get_axis_aligned_bounding_box().get_extent())
    max_d_coarse = 0.10 * diag
    max_d_fine = 0.03 * diag

    # Coarse ICP: point-to-point
    coarse = o3d.pipelines.registration.registration_icp(
        src_pcd, tgt_pcd,
        max_d_coarse,
        np.identity(4),
        o3d.pipelines.registration.TransformationEstimationPointToPoint(),
        o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=40)
    )

    # Fine ICP: point-to-plane
    fine = o3d.pipelines.registration.registration_icp(
        src_pcd, tgt_pcd,
        max_d_fine,
        coarse.transformation,
        o3d.pipelines.registration.TransformationEstimationPointToPlane(),
        o3d.pipelines.registration.ICPConvergenceCriteria(
            relative_fitness=1e-6,
            relative_rmse=1e-6,
            max_iteration=60
        )
    )

    source_mesh.transform(fine.transformation)

    logger.info(f"  - ICP complete (fitness {fine.fitness:.3f}, RMSE {fine.inlier_rmse:.4f})")

    icp_log = {
        "diag": float(diag),
        "icp_sample_points": 8000,
        "icp_sample_method": "poisson",
        "poisson_init_factor": 5,
        "icp_max_d_coarse": float(max_d_coarse),
        "icp_max_d_fine": float(max_d_fine),
        "icp_fitness": float(fine.fitness),
        "icp_inlier_rmse": float(fine.inlier_rmse),
        "T_icp": fine.transformation.tolist(),
    }

    return source_mesh, icp_log
