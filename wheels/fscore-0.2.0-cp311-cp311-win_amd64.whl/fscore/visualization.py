"""
Visualization functions for 3D model comparison.
"""

import numpy as np
import copy
import trimesh
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def o3d_to_trimesh(o3d_mesh, rgb):
    """
    Convert Open3D mesh to trimesh with vertex colors.

    Args:
        o3d_mesh: Open3D TriangleMesh
        rgb: RGB color tuple (0-1 range)

    Returns:
        trimesh.Trimesh: Colored trimesh
    """
    m = copy.deepcopy(o3d_mesh)
    m.compute_vertex_normals()
    v = np.asarray(m.vertices)
    f = np.asarray(m.triangles)
    cols = (np.tile(np.array(list(rgb) + [1.0]), (len(v), 1)) * 255).astype(np.uint8)
    return trimesh.Trimesh(vertices=v, faces=f, vertex_colors=cols, process=False)


def save_visualization(item_id, gt_mesh, pred_mesh, output_dir=None, workspace=None):
    """
    Save side-by-side visualization of ground truth and predicted meshes.

    Args:
        item_id: Identifier for the test item
        gt_mesh: Ground truth Open3D TriangleMesh
        pred_mesh: Predicted Open3D TriangleMesh (aligned)
        output_dir: Output directory for visualization files (optional)
        workspace: Workspace root path (for archi3D integration)

    Returns:
        Path: Path to saved visualization file, or None if failed
    """
    try:
        # Determine output directory
        if output_dir is None:
            if workspace:
                vis_dir = workspace / "reports" / "visualizations"
            else:
                vis_dir = Path("results/visualizations")
        else:
            vis_dir = Path(output_dir)

        vis_dir.mkdir(parents=True, exist_ok=True)
        out_path = vis_dir / f"{item_id}_comparison.glb"

        # Convert to trimesh with colors
        gt_tm = o3d_to_trimesh(gt_mesh, [0.75, 0.75, 0.75])  # Gray
        pred_tm = o3d_to_trimesh(pred_mesh, [1.00, 0.20, 0.20])  # Red

        # Create scene
        scene = trimesh.Scene()
        scene.add_geometry(gt_tm, node_name="ground_truth")
        scene.add_geometry(pred_tm, node_name="prediction")

        # Export
        scene.export(out_path, file_type='glb')
        logger.info(f"  - Saved visualization: {out_path}")

        return out_path

    except Exception as exc:
        logger.warning(f"Warning: could not save visualization – {exc}")
        return None
