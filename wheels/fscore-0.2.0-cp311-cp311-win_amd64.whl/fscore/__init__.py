"""
FScore: 3D Model Evaluation Tool

This package provides tools for computing F-scores between AI-generated
3D models and ground truth reference models. It performs automatic mesh
alignment and evaluates geometric similarity using precision/recall metrics.
"""

__version__ = "0.2.0"

from .evaluator import FScoreEvaluator, evaluate_one
from .metrics import compute_fscore, compute_distance_statistics

__all__ = [
    "FScoreEvaluator",
    "evaluate_one",
    "compute_fscore",
    "compute_distance_statistics",
]
