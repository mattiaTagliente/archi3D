"""
Workspace configuration and path resolution for archi3D integration.
"""

import os
import logging
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

logger = logging.getLogger(__name__)


def resolve_workspace_path(cli_workspace: Optional[str] = None) -> Optional[Path]:
    """
    Resolve the workspace path from CLI argument or environment variables.

    Priority order:
    1. CLI argument (--workspace)
    2. ARCHI3D_WORKSPACE environment variable (from .env or system)
    3. None (fall back to legacy local directories)

    Args:
        cli_workspace: Workspace path from CLI argument

    Returns:
        Resolved workspace path, or None if not configured
    """
    # Try CLI argument first
    if cli_workspace:
        workspace = Path(cli_workspace)
        if workspace.exists():
            logger.info(f"Using workspace from CLI: {workspace}")
            return workspace
        else:
            logger.warning(f"Workspace from CLI not found: {workspace}")

    # Load .env file if it exists
    env_path = Path.cwd() / ".env"
    if env_path.exists():
        load_dotenv(env_path)
        logger.debug(f"Loaded .env from: {env_path}")

    # Try environment variable
    workspace_env = os.getenv("ARCHI3D_WORKSPACE")
    if workspace_env:
        workspace = Path(workspace_env)
        if workspace.exists():
            logger.info(f"Using workspace from ARCHI3D_WORKSPACE: {workspace}")
            return workspace
        else:
            logger.warning(f"Workspace from ARCHI3D_WORKSPACE not found: {workspace}")

    # No workspace configured
    logger.info("No workspace configured. Using local directory structure.")
    return None


def get_dataset_dir(workspace: Optional[Path]) -> Path:
    """
    Get the dataset directory path.

    Args:
        workspace: Workspace root path, or None for local structure

    Returns:
        Path to dataset directory
    """
    if workspace:
        dataset_dir = workspace / "dataset"
        dataset_dir.mkdir(parents=True, exist_ok=True)
        return dataset_dir
    else:
        # Legacy local structure
        return Path.cwd()


def get_results_dir(workspace: Optional[Path]) -> Path:
    """
    Get the results directory path.

    Args:
        workspace: Workspace root path, or None for local structure

    Returns:
        Path to results directory
    """
    if workspace:
        results_dir = workspace / "reports"
        results_dir.mkdir(parents=True, exist_ok=True)
        return results_dir
    else:
        # Legacy local structure
        results_dir = Path.cwd() / "results"
        results_dir.mkdir(parents=True, exist_ok=True)
        return results_dir


def resolve_model_path_in_workspace(
    relative_or_absolute_path: str, workspace: Optional[Path]
) -> Path:
    """
    Resolve a model path, handling both absolute and relative paths.

    If a workspace is configured:
    - Absolute paths are used as-is
    - Relative paths are resolved relative to workspace/dataset/

    If no workspace:
    - Paths are resolved relative to current directory (legacy behavior)

    Args:
        relative_or_absolute_path: Path from config file
        workspace: Workspace root path, or None for local structure

    Returns:
        Resolved absolute path
    """
    path = Path(relative_or_absolute_path)

    # If already absolute, use as-is
    if path.is_absolute():
        return path

    # Otherwise, resolve relative to dataset dir
    dataset_dir = get_dataset_dir(workspace)
    return dataset_dir / path


def get_conversion_log_path(workspace: Optional[Path]) -> Path:
    """
    Get the path for the FBX conversion log.

    Args:
        workspace: Workspace root path, or None for local structure

    Returns:
        Path to conversion log file
    """
    results_dir = get_results_dir(workspace)
    return results_dir / "fbx_conversion_log.json"
