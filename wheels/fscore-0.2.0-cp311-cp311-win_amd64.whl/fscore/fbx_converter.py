"""
FBX to GLB conversion utilities using FBX2glTF binary.
"""

import subprocess
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict

logger = logging.getLogger(__name__)

# Global conversion log to track all conversions in a session
_conversion_log = []


class FBXConverter:
    """Handles FBX to GLB conversion using the FBX2glTF binary."""

    def __init__(self, fbx2gltf_path: Optional[Path] = None):
        """
        Initialize the FBX converter.

        Args:
            fbx2gltf_path: Path to FBX2glTF executable. If None, looks in project root.
        """
        if fbx2gltf_path is None:
            # Look for FBX2glTF in the project root directory
            project_root = Path(__file__).parent.parent.parent
            fbx2gltf_path = project_root / "FBX2glTF-windows-x64.exe"

        self.fbx2gltf_path = Path(fbx2gltf_path)
        if not self.fbx2gltf_path.exists():
            logger.warning(
                f"FBX2glTF binary not found at {self.fbx2gltf_path}. "
                "FBX conversion will not be available."
            )

    def is_available(self) -> bool:
        """Check if the FBX2glTF binary is available."""
        return self.fbx2gltf_path.exists()

    def convert_fbx_to_glb(
        self, fbx_path: Path, output_glb_path: Optional[Path] = None, force: bool = False
    ) -> Optional[Path]:
        """
        Convert an FBX file to GLB format.

        Uses the flags recommended for F-score evaluation:
        - Uncompressed GLB (no Draco)
        - Preserve normals if they exist
        - Keep only position and normal attributes
        - Auto long indices

        Args:
            fbx_path: Path to input FBX file
            output_glb_path: Optional output path. If None, uses same dir as FBX
            force: If True, converts even if GLB already exists

        Returns:
            Path to converted GLB file, or None if conversion failed
        """
        fbx_path = Path(fbx_path)

        if not fbx_path.exists():
            logger.error(f"FBX file not found: {fbx_path}")
            return None

        if not self.is_available():
            logger.error(
                "FBX2glTF binary not available. Cannot convert FBX files. "
                f"Please ensure FBX2glTF-windows-x64.exe is in the project root."
            )
            return None

        # Determine output path
        if output_glb_path is None:
            output_glb_path = fbx_path.with_suffix(".glb")
        else:
            output_glb_path = Path(output_glb_path)

        # Check if conversion is needed
        if output_glb_path.exists() and not force:
            logger.info(f"GLB already exists, skipping conversion: {output_glb_path.name}")
            return output_glb_path

        # Build conversion command with recommended flags
        cmd = [
            str(self.fbx2gltf_path),
            "-b",  # Binary GLB output
            "--long-indices", "auto",
            "--compute-normals", "missing",  # Only compute if missing
            "-k", "position",  # Keep position attribute
            "-k", "normal",  # Keep normal attribute
            "-i", str(fbx_path),
            "-o", str(output_glb_path),
        ]

        logger.info(f"Converting FBX to GLB: {fbx_path.name} -> {output_glb_path.name}")

        try:
            # Run conversion
            result = subprocess.run(
                cmd, capture_output=True, text=True, check=False, timeout=60
            )

            # Log conversion details
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "fbx_path": str(fbx_path),
                "glb_path": str(output_glb_path),
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
            _conversion_log.append(log_entry)

            if result.returncode == 0:
                logger.info(f"✓ Conversion successful: {output_glb_path.name}")
                if result.stdout:
                    logger.debug(f"Conversion output: {result.stdout}")
                if result.stderr:
                    logger.warning(f"Conversion warnings: {result.stderr}")
                return output_glb_path
            else:
                logger.error(
                    f"✗ Conversion failed (exit code {result.returncode}): {fbx_path.name}"
                )
                if result.stderr:
                    logger.error(f"Error details: {result.stderr}")
                if result.stdout:
                    logger.debug(f"Output: {result.stdout}")
                return None

        except subprocess.TimeoutExpired:
            logger.error(f"Conversion timed out: {fbx_path.name}")
            _conversion_log.append(
                {
                    "timestamp": datetime.now().isoformat(),
                    "fbx_path": str(fbx_path),
                    "glb_path": str(output_glb_path),
                    "success": False,
                    "error": "Timeout after 60 seconds",
                }
            )
            return None
        except Exception as e:
            logger.error(f"Unexpected error during conversion: {e}")
            _conversion_log.append(
                {
                    "timestamp": datetime.now().isoformat(),
                    "fbx_path": str(fbx_path),
                    "glb_path": str(output_glb_path),
                    "success": False,
                    "error": str(e),
                }
            )
            return None


def get_conversion_log() -> list:
    """
    Get the global conversion log for all conversions in this session.

    Returns:
        List of conversion log entries
    """
    return _conversion_log.copy()


def save_conversion_log(output_path: Path):
    """
    Save the conversion log to a file.

    Args:
        output_path: Path to save the log file
    """
    if not _conversion_log:
        logger.info("No conversions to log.")
        return

    import json

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(_conversion_log, f, indent=2)

    logger.info(f"Conversion log saved to: {output_path}")


def resolve_model_path(
    model_path: Path, auto_convert_fbx: bool = True, fbx_converter: Optional[FBXConverter] = None
) -> Optional[Path]:
    """
    Resolve a model path, converting FBX to GLB if needed.

    Args:
        model_path: Path to model file (can be .fbx or .glb)
        auto_convert_fbx: If True, automatically convert FBX files
        fbx_converter: FBXConverter instance. If None and conversion needed, creates one.

    Returns:
        Path to GLB file, or None if file doesn't exist or conversion failed
    """
    model_path = Path(model_path)

    # If it's already a GLB, return it if it exists
    if model_path.suffix.lower() == ".glb":
        return model_path if model_path.exists() else None

    # If it's an FBX, try to convert
    if model_path.suffix.lower() == ".fbx":
        if not model_path.exists():
            return None

        if not auto_convert_fbx:
            logger.warning(f"FBX file found but auto-conversion disabled: {model_path}")
            return None

        # Check if GLB already exists
        glb_path = model_path.with_suffix(".glb")
        if glb_path.exists():
            logger.info(f"Using existing GLB: {glb_path.name}")
            return glb_path

        # Convert FBX to GLB
        if fbx_converter is None:
            fbx_converter = FBXConverter()

        return fbx_converter.convert_fbx_to_glb(model_path)

    # Unknown format
    logger.warning(f"Unsupported file format: {model_path.suffix}")
    return None
