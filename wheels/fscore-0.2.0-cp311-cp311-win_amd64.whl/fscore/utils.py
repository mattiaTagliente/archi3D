"""
Utility functions for FScore evaluation.
"""

import numpy as np
import sys
import open3d as o3d
import trimesh
import pandas as pd
from functools import lru_cache


@lru_cache(maxsize=1)
def get_rigid_transform_estimation():
    """
    Cached TransformationEstimationPointToPoint instance.
    """
    return o3d.pipelines.registration.TransformationEstimationPointToPoint(False)


def euler_xyz_from_rotation_matrix(R):
    """
    Extract Euler angles (in degrees) from a 3x3 rotation matrix using XYZ convention.

    Args:
        R: 3x3 rotation matrix

    Returns:
        tuple: (x, y, z) Euler angles in degrees
    """
    sy = np.sqrt(R[0, 0]**2 + R[1, 0]**2)
    x = np.degrees(np.arctan2(R[2, 1], R[2, 2]))
    y = np.degrees(np.arctan2(-R[2, 0], sy))
    z = np.degrees(np.arctan2(R[1, 0], R[0, 0]))
    return (float(x), float(y), float(z))


def get_environment_info():
    """
    Get library versions and environment information for reproducibility.

    Returns:
        dict: Environment metadata
    """
    return {
        "python_version": sys.version.split()[0],
        "open3d_version": o3d.__version__,
        "numpy_version": np.__version__,
        "trimesh_version": trimesh.__version__,
        "pandas_version": pd.__version__,
        "platform": sys.platform,
    }


def get_mesh_metadata(mesh):
    """
    Extract metadata from a mesh.

    Args:
        mesh: Open3D TriangleMesh

    Returns:
        dict: Mesh metadata (vertices, triangles, bbox volume/area)
    """
    vertices = np.asarray(mesh.vertices)
    triangles = np.asarray(mesh.triangles)
    bbox = mesh.get_axis_aligned_bounding_box()
    extent = bbox.get_extent()

    return {
        "vertices": int(len(vertices)),
        "triangles": int(len(triangles)),
        "bbox_volume": float(np.prod(extent)),
        "bbox_surface_area": float(2 * (extent[0]*extent[1] + extent[1]*extent[2] + extent[2]*extent[0])),
        "bbox_extent": tuple(map(float, extent)),
    }
