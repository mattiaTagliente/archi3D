"""
Main entry point for FScore CLI.
"""

import sys
import argparse
import logging
import time
import multiprocessing as mp
from itertools import cycle

import colorama
import open3d as o3d

# Try to import yaspin for spinner
try:
    from yaspin import yaspin
    from yaspin.spinners import Spinners
except ImportError:
    yaspin = Spinners = None

from .evaluator import FScoreEvaluator


def spinner_worker_proc(state):
    """
    Runs in a separate process to display a spinner and status text.

    Args:
        state: Shared multiprocessing dict with 'text' and 'running' keys
    """
    invert, reset = "\033[7m", "\033[0m"

    if yaspin is not None:
        with yaspin(
            Spinners.line,
            text=f"{invert}{state.get('text', '')}{reset}",
            color="white",
            timer=False,
        ) as spin:
            while state.get('running', False):
                new_txt = state.get('text', '')
                if spin.text != f"{invert}{new_txt}{reset}":
                    spin.text = f"{invert}{new_txt}{reset}"
                time.sleep(0.08)
    else:
        # Fallback spinner without yaspin
        frames = cycle(['|', '/', '-', '\\'])
        while state.get('running', False):
            status = state.get('text', '')
            sys.stdout.write(f"\0337\033[999B\r\033[K{invert}{next(frames)} {status}{reset}\0338")
            sys.stdout.flush()
            time.sleep(0.08)
        sys.stdout.write("\0337\033[999B\r\033[K\0338")
        sys.stdout.flush()


def main():
    """
    Main function to orchestrate the test lifecycle.
    """
    # Setup
    colorama.init()
    logging.basicConfig(
        level=logging.INFO,
        stream=sys.stderr,
        format='%(message)s'
    )
    o3d.utility.set_verbosity_level(o3d.utility.VerbosityLevel.Error)

    # Parse arguments
    parser = argparse.ArgumentParser(
        description='F-Score evaluation for 3D models',
        prog='fscore'
    )
    parser.add_argument(
        '--config',
        type=str,
        required=True,
        help='Path to configuration YAML file'
    )
    parser.add_argument(
        '--workspace',
        type=str,
        default=None,
        help='Workspace root directory (overrides ARCHI3D_WORKSPACE env var)'
    )
    args = parser.parse_args()

    # Spinner setup
    mp_manager = mp.Manager()
    spinner_state = mp_manager.dict(text='Initializing test engine...', running=True)
    spinner_proc = mp.Process(
        target=spinner_worker_proc,
        args=(spinner_state,),
    )
    spinner_proc.start()

    try:
        # Run Evaluation
        evaluator = FScoreEvaluator(args.config, spinner_state, workspace_path=args.workspace)
        evaluator.run_evaluation()

    except Exception as e:
        spinner_state['running'] = False
        spinner_proc.join()
        sys.stdout.write('\r\033[K')
        sys.stdout.flush()
        logging.error(f"\n\nFATAL ERROR in test engine: {e}")
        sys.exit(1)

    finally:
        # Shutdown
        if spinner_proc.is_alive():
            spinner_state['text'] = 'Evaluation complete!'
            time.sleep(1)
            spinner_state['running'] = False
            spinner_proc.join()
        colorama.deinit()


if __name__ == "__main__":
    main()
