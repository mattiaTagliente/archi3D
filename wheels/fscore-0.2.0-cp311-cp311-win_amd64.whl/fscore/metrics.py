"""
F-score computation and distance statistics.
"""

import numpy as np
import logging

logger = logging.getLogger(__name__)


def compute_distance_statistics(distances):
    """
    Compute robust statistics for distance array.

    Args:
        distances: numpy array of distances

    Returns:
        dict: Statistics including mean, median, std, p95
    """
    return {
        "mean": float(np.mean(distances)),
        "median": float(np.median(distances)),
        "std": float(np.std(distances)),
        "p95": float(np.percentile(distances, 95)),
    }


def compute_fscore(gt_mesh, pred_mesh, threshold_percent=1.0, update_callback=None):
    """
    Compute F-score between ground truth and predicted meshes.

    Args:
        gt_mesh: Ground truth Open3D TriangleMesh
        pred_mesh: Predicted Open3D TriangleMesh (aligned)
        threshold_percent: Threshold as percentage of GT bbox diagonal
        update_callback: Optional callback for status updates

    Returns:
        dict: Metrics including precision, recall, F-score, and distance statistics
    """
    if update_callback:
        update_callback(f"Preparing F-score calculation (threshold={threshold_percent}%)...")

    n_points = 100000
    gt_bbox = gt_mesh.get_axis_aligned_bounding_box()
    bbox_diagonal = np.linalg.norm(gt_bbox.get_extent())
    bbox_extent = gt_bbox.get_extent()
    threshold = (threshold_percent / 100.0) * bbox_diagonal

    if update_callback:
        update_callback(f"Sampling GT mesh ({n_points:,} pts) – phase 1/3…")

    gt_pcd = gt_mesh.sample_points_poisson_disk(n_points, init_factor=5)

    if update_callback:
        update_callback("GT sample ready – phase 2/3 (pred mesh)…")

    pred_pcd = pred_mesh.sample_points_poisson_disk(n_points, init_factor=5)

    if update_callback:
        update_callback("Phase 3/3 – computing distances…")

    # Compute bidirectional distances
    gt_to_pred_distances = np.asarray(gt_pcd.compute_point_cloud_distance(pred_pcd))
    pred_to_gt_distances = np.asarray(pred_pcd.compute_point_cloud_distance(gt_pcd))

    # Precision and Recall
    recall = np.sum(gt_to_pred_distances < threshold) / len(gt_to_pred_distances)
    precision = np.sum(pred_to_gt_distances < threshold) / len(pred_to_gt_distances)
    fscore = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

    # Distance statistics
    gt2pred_stats = compute_distance_statistics(gt_to_pred_distances)
    pred2gt_stats = compute_distance_statistics(pred_to_gt_distances)

    # Chamfer distances
    chamfer_l2 = float(np.mean(gt_to_pred_distances**2) + np.mean(pred_to_gt_distances**2))
    chamfer_l1 = float(np.mean(np.abs(gt_to_pred_distances)) + np.mean(np.abs(pred_to_gt_distances)))

    logger.info(f"F-score calculation complete.")
    logger.info(f"  - Distance threshold: {threshold:.4f}")
    logger.info(f"  - Recall: {recall:.3f}, Precision: {precision:.3f}, F-score: {fscore:.3f}")

    result = {
        "precision": float(precision),
        "recall": float(recall),
        "fscore": float(fscore),
        "threshold": float(threshold),
        "threshold_percent": float(threshold_percent),
        "bbox_diagonal": float(bbox_diagonal),
        "bbox_extent": tuple(map(float, bbox_extent)),
        "eval_points": int(n_points),
        "eval_sample_method": "poisson",
        "gt2pred_mean": gt2pred_stats["mean"],
        "gt2pred_median": gt2pred_stats["median"],
        "gt2pred_std": gt2pred_stats["std"],
        "gt2pred_p95": gt2pred_stats["p95"],
        "pred2gt_mean": pred2gt_stats["mean"],
        "pred2gt_median": pred2gt_stats["median"],
        "pred2gt_std": pred2gt_stats["std"],
        "pred2gt_p95": pred2gt_stats["p95"],
        "chamfer_l2": chamfer_l2,
        "chamfer_l1": chamfer_l1,
    }

    return result
