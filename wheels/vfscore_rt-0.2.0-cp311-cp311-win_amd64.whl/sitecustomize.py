"""Interpreter customizations for VFScore_RT.

Python automatically imports ``sitecustomize`` (if available) after the standard
``site`` module finishes loading. That happens before any project modules are imported,
which gives us the earliest possible hook to disable bytecode generation.
"""

from __future__ import annotations

import os
import sys

# Prevent the interpreter from writing .pyc files or __pycache__ directories.
sys.dont_write_bytecode = True
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")

# Windows DLL loading fix for PyTorch
# Must run BEFORE any modules that import torch (like vfscore's compiled modules)
if sys.platform == "win32":
    import pathlib
    torch_lib_path = pathlib.Path(sys.prefix) / "Lib" / "site-packages" / "torch" / "lib"

    if torch_lib_path.exists():
        # Method 1: Add to PATH environment variable
        torch_lib_str = str(torch_lib_path)
        if torch_lib_str not in os.environ.get("PATH", ""):
            os.environ["PATH"] = torch_lib_str + os.pathsep + os.environ.get("PATH", "")

        # Method 2: Use os.add_dll_directory (Python 3.8+)
        try:
            os.add_dll_directory(torch_lib_str)
        except (OSError, AttributeError):
            pass  # Ignore if add_dll_directory not available or fails

        # Method 3: Pre-import torch to force DLL loading NOW
        # This ensures all torch DLLs are loaded with the correct search path
        # BEFORE any compiled vfscore modules try to import torch
        try:
            import torch  # noqa: F401
            # Force initialization
            _ = torch.__version__
        except Exception:
            # If torch import fails here, let it fail later with better error context
            pass
