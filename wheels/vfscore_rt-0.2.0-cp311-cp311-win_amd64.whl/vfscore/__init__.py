"""VFScore - Visual Fidelity Scoring for 3D Generated Objects."""

# CRITICAL: Windows DLL loading fix for PyTorch
# Strategy: Add DLL directory AND pre-import torch before any compiled vfscore modules
import sys
import os

if sys.platform == "win32":
    # Step 1: Add torch DLL directory to search path
    import pathlib
    torch_lib_path = pathlib.Path(sys.prefix) / "Lib" / "site-packages" / "torch" / "lib"
    if torch_lib_path.exists():
        os.add_dll_directory(str(torch_lib_path))

    # Step 2: Pre-import torch to force DLL loading BEFORE vfscore's compiled modules
    # This ensures c10.dll and other torch DLLs are loaded with the correct search path
    try:
        import torch  # noqa: F401
        # Force torch to initialize (loads all DLLs)
        _ = torch.__version__
    except Exception:
        # If torch import fails, let it fail later with better error context
        pass

# Disable .pyc/__pycache__ creation whenever the package is imported
sys.dont_write_bytecode = True
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")

__version__ = "0.2.0"
__author__ = "Mattia"

# Export evaluator function for archi3D integration
# Import happens AFTER torch is pre-loaded
from vfscore.evaluator import evaluate_visual_fidelity  # noqa: F401, E402

__all__ = ["evaluate_visual_fidelity", "__version__"]
