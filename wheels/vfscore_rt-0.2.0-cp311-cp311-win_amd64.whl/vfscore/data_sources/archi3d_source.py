"""
Archi3D data source for VFScore.

Reads from archi3D's Single Source of Truth database:
  - tables/items.csv (catalog of items with metadata)
  - tables/generations.csv (generation records)

All paths are workspace-relative as per archi3D conventions.
"""

import csv
from pathlib import Path
from typing import Iterator, List, Dict, Tuple, Set
from .base import ItemRecord
from ..utils import make_item_id


class Archi3DSource:
    """
    Data source for archi3D integration pipeline.

    Reads items and generations from archi3D's workspace database tables.
    Expects workspace-relative paths as per archi3D conventions.

    Args:
        workspace: Path to archi3D workspace root
        run_id: Optional run_id to filter generations (e.g., "2025-08-17_v1")
        items_csv: Optional override for items CSV path (defaults to tables/items.csv)
        generations_csv: Optional override for generations CSV path (defaults to tables/generations.csv)
        refs_source: Which image set to use for references:
            - "used" (default): used_image_* columns from generations.csv
            - "source": source_image_* columns from generations.csv
            - "folder": source_folder from items.csv (legacy fallback)
    """

    def __init__(
        self,
        workspace: Path,
        run_id: str | None = None,
        items_csv: Path | None = None,
        generations_csv: Path | None = None,
        refs_source: str = "used",
    ):
        self.workspace = Path(workspace)
        self.run_id = run_id
        self.refs_source = refs_source

        # Default table paths
        self.items_csv = Path(items_csv) if items_csv else self.workspace / "tables" / "items.csv"
        self.generations_csv = Path(generations_csv) if generations_csv else self.workspace / "tables" / "generations.csv"

        # Validate inputs
        if not self.workspace.exists():
            raise FileNotFoundError(f"Workspace not found: {self.workspace}")

        if not self.items_csv.exists():
            raise FileNotFoundError(f"Items CSV not found: {self.items_csv}")

        if not self.generations_csv.exists():
            raise FileNotFoundError(f"Generations CSV not found: {self.generations_csv}")

        if refs_source not in ("used", "source", "folder"):
            raise ValueError(f"Invalid refs_source: '{refs_source}'. Must be 'used', 'source', or 'folder'")

    def load_items(self) -> Iterator[ItemRecord]:
        """
        Load items from archi3D data source.

        Steps:
        1. Read tables/items.csv to get item catalog with metadata
        2. Read tables/generations.csv to get generation records
        3. Filter generations by run_id if specified
        4. Match generations to items by (product_id, variant)
        5. Resolve reference image paths based on refs_source preference:
           - "used": from used_image_* columns in generations.csv
           - "source": from source_image_* columns in generations.csv
           - "folder": from source_folder in items.csv (legacy)
        6. Yield ItemRecord for each generation

        Yields:
            ItemRecord: Individual generation records with metadata
        """
        # Step 1: Read items catalog
        print(f"[Archi3DSource] Reading items catalog: {self.items_csv}")
        items_catalog = self._read_items_csv()
        print(f"[Archi3DSource] Found {len(items_catalog)} items in catalog")

        # Step 2: Read generations
        print(f"[Archi3DSource] Reading generations: {self.generations_csv}")
        generation_records = self._read_generations_csv()
        print(f"[Archi3DSource] Found {len(generation_records)} generation records")

        # Step 3: Filter by run_id if specified
        if self.run_id:
            print(f"[Archi3DSource] Filtering by run_id: {self.run_id}")
            generation_records = [
                rec for rec in generation_records
                if rec['run_id'] == self.run_id
            ]
            print(f"[Archi3DSource] After filtering: {len(generation_records)} records")

        # Step 4-6: Match, resolve paths, and yield ItemRecords
        print(f"[Archi3DSource] Creating ItemRecords (refs_source={self.refs_source})...")
        yielded_count = 0
        skipped_no_item = 0
        skipped_no_refs = 0
        skipped_no_glb = 0

        for gen_rec in generation_records:
            product_id = gen_rec['product_id']
            variant = gen_rec['variant']
            item_key = (product_id, variant)

            # Get item metadata from catalog
            item_metadata = items_catalog.get(item_key)
            if not item_metadata:
                skipped_no_item += 1
                print(f"[WARNING] Item not found in catalog: {product_id} + variant '{variant}'")
                continue

            # Get reference images based on refs_source preference
            ref_image_paths = self._resolve_ref_images(gen_rec, item_metadata)
            if not ref_image_paths:
                skipped_no_refs += 1
                print(f"[WARNING] No reference images found for {product_id} + variant '{variant}'")
                continue

            # Resolve GLB path (workspace-relative)
            glb_path = self._resolve_glb_path(gen_rec['output_glb_relpath'])
            if not glb_path or not glb_path.exists():
                skipped_no_glb += 1
                print(f"[WARNING] GLB file not found: {gen_rec['output_glb_relpath']}")
                continue

            # Create item_id using utility function (includes algorithm and job_id to prevent collisions)
            item_id = make_item_id(product_id, variant, gen_rec['algorithm'], gen_rec['job_id'])

            # Create ItemRecord
            record = ItemRecord(
                product_id=product_id,
                variant=variant,
                item_id=item_id,
                ref_image_paths=ref_image_paths,
                glb_path=glb_path,
                algorithm=gen_rec['algorithm'],
                job_id=gen_rec['job_id'],
                product_name=item_metadata.get('product_name'),
                manufacturer=item_metadata.get('manufacturer'),
                category_l1=item_metadata.get('category_l1'),
                category_l2=item_metadata.get('category_l2'),
                category_l3=item_metadata.get('category_l3'),
                source_type="archi3d",
            )

            yield record
            yielded_count += 1

        print(f"[Archi3DSource] Yielded {yielded_count} ItemRecords")
        if skipped_no_item > 0:
            print(f"[Archi3DSource] Skipped {skipped_no_item} records (item not in catalog)")
        if skipped_no_refs > 0:
            print(f"[Archi3DSource] Skipped {skipped_no_refs} records (no reference images)")
        if skipped_no_glb > 0:
            print(f"[Archi3DSource] Skipped {skipped_no_glb} records (GLB file not found)")

    def _resolve_ref_images(
        self, gen_rec: Dict[str, str], item_metadata: Dict[str, str]
    ) -> List[Path]:
        """
        Resolve reference images based on refs_source preference.

        Args:
            gen_rec: Generation record from generations.csv
            item_metadata: Item metadata from items.csv

        Returns:
            List of absolute paths to reference images
        """
        # Priority 1: Use refs_source preference
        if self.refs_source == "used":
            used_images = gen_rec.get('used_images', [])
            if used_images:
                return self._resolve_image_paths(used_images)
            # Fallback to source_images if used_images empty
            source_images = gen_rec.get('source_images', [])
            if source_images:
                return self._resolve_image_paths(source_images)
            # Final fallback to source_folder
            return self._get_reference_images(item_metadata.get('source_folder', ''))

        elif self.refs_source == "source":
            source_images = gen_rec.get('source_images', [])
            if source_images:
                return self._resolve_image_paths(source_images)
            # Fallback to used_images if source_images empty
            used_images = gen_rec.get('used_images', [])
            if used_images:
                return self._resolve_image_paths(used_images)
            # Final fallback to source_folder
            return self._get_reference_images(item_metadata.get('source_folder', ''))

        else:  # "folder"
            return self._get_reference_images(item_metadata.get('source_folder', ''))

    def _resolve_image_paths(self, image_paths: List[str]) -> List[Path]:
        """
        Resolve workspace-relative image paths to absolute paths.

        Args:
            image_paths: List of workspace-relative paths

        Returns:
            List of absolute paths (only existing files)
        """
        resolved = []
        for img_path in image_paths:
            if not img_path:
                continue
            abs_path = self.workspace / img_path
            if abs_path.exists() and abs_path.is_file():
                resolved.append(abs_path)
        return resolved

    def _read_items_csv(self) -> Dict[Tuple[str, str], Dict[str, str]]:
        """
        Read tables/items.csv and return dict mapping (product_id, variant) to metadata.

        Expected columns:
            product_id, variant, product_name, manufacturer, category_l1, category_l2,
            category_l3, source_folder

        Returns:
            Dict mapping (product_id, variant) to item metadata dict
        """
        items = {}
        with open(self.items_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                product_id = row['product_id'].strip()
                variant = row['variant'].strip()
                items[(product_id, variant)] = {
                    'product_name': row.get('product_name', '').strip(),
                    'manufacturer': row.get('manufacturer', '').strip(),
                    'category_l1': row.get('category_l1', '').strip(),
                    'category_l2': row.get('category_l2', '').strip(),
                    'category_l3': row.get('category_l3', '').strip(),
                    'source_folder': row.get('source_folder', '').strip(),
                }
        return items

    def _read_generations_csv(self) -> List[Dict[str, str]]:
        """
        Read tables/generations.csv and return list of generation records.

        Expected columns:
            run_id, job_id, product_id, variant, algorithm, n_images, duration_s,
            output_glb_relpath, worker, unit_price_usd, status

        Also collects used_image_* and source_image_* columns if present.

        Returns:
            List of generation record dicts
        """
        records = []
        with open(self.generations_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            fieldnames = reader.fieldnames or []

            # Identify used_image_* and source_image_* columns
            used_image_cols = sorted([c for c in fieldnames if c.startswith('used_image_')])
            source_image_cols = sorted([c for c in fieldnames if c.startswith('source_image_')])

            for row in reader:
                # Only include completed generations
                status = row.get('status', '').strip().lower()
                if status != 'completed':
                    continue

                record = {
                    'run_id': row['run_id'].strip(),
                    'job_id': row['job_id'].strip(),
                    'product_id': row['product_id'].strip(),
                    'variant': row['variant'].strip(),
                    'algorithm': row['algorithm'].strip(),
                    'n_images': row.get('n_images', ''),
                    'duration_s': row.get('duration_s', ''),
                    'output_glb_relpath': row['output_glb_relpath'].strip(),
                    'worker': row.get('worker', ''),
                    'unit_price_usd': row.get('unit_price_usd', ''),
                }

                # Collect used_image_* paths (non-empty only)
                used_images = []
                for col in used_image_cols:
                    val = row.get(col, '').strip()
                    if val:
                        used_images.append(val)
                record['used_images'] = used_images

                # Collect source_image_* paths (non-empty only)
                source_images = []
                for col in source_image_cols:
                    val = row.get(col, '').strip()
                    if val:
                        source_images.append(val)
                record['source_images'] = source_images

                records.append(record)
        return records

    def _get_reference_images(self, source_folder: str) -> List[Path]:
        """
        Get reference images from item source_folder.

        The source_folder is workspace-relative and contains reference images
        for this item.

        Args:
            source_folder: Workspace-relative path to source folder (e.g., "sources/335888_variant")

        Returns:
            List of absolute paths to reference images
        """
        if not source_folder:
            return []

        # Resolve workspace-relative path
        folder_path = self.workspace / source_folder

        if not folder_path.exists() or not folder_path.is_dir():
            return []

        # Find all image files
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}
        image_paths = [
            img_path for img_path in folder_path.iterdir()
            if img_path.is_file() and img_path.suffix.lower() in image_extensions
        ]

        return sorted(image_paths)

    def _resolve_glb_path(self, glb_relpath: str) -> Path | None:
        """
        Resolve GLB file path from workspace-relative path.

        Args:
            glb_relpath: Workspace-relative path (e.g., "generations/2025-08-17_v1/335888_variant/model.glb")

        Returns:
            Absolute Path to GLB file, or None if cannot be resolved
        """
        if not glb_relpath:
            return None

        # Resolve workspace-relative path
        glb_path = self.workspace / glb_relpath

        return glb_path if glb_path.exists() else None

    def get_source_info(self) -> dict:
        """Return metadata about this data source."""
        return {
            "type": "archi3d",
            "workspace": str(self.workspace),
            "run_id": self.run_id,
            "refs_source": self.refs_source,
            "items_csv": str(self.items_csv),
            "generations_csv": str(self.generations_csv),
        }
