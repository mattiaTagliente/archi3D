"""Silhouette IoU utilities for pose search."""

from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def extract_mask(
    image_path: Path, threshold: int = 16, erode_dilate_px: int = 1
) -> np.ndarray:
    """Extract binary mask from image.

    For GT images (preprocessed PNGs), prefer alpha channel.
    For render images, threshold alpha channel.
    Fallback: threshold on black background if no alpha.

    Args:
        image_path: Path to image file
        threshold: Binarization threshold (0-255)
        erode_dilate_px: Morphological operation kernel size for robustness

    Returns:
        Binary mask as uint8 array (0 or 255)
    """
    img = Image.open(image_path)

    # Try to use alpha channel first
    if img.mode in ("RGBA", "LA"):
        alpha = np.array(img.split()[-1])
        mask = (alpha > threshold).astype(np.uint8) * 255
    else:
        # Fallback: threshold on grayscale (assumes black background)
        gray = np.array(img.convert("L"))
        mask = (gray > threshold).astype(np.uint8) * 255

    # Apply morphological operations for robustness (remove noise, fill holes)
    if erode_dilate_px > 0:
        kernel = np.ones((erode_dilate_px, erode_dilate_px), np.uint8)
        # Erode then dilate (opening) to remove noise
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        # Dilate then erode (closing) to fill holes
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    return mask


def iou(mask_a: np.ndarray, mask_b: np.ndarray) -> float:
    """Compute Intersection over Union (IoU) between two binary masks.

    Args:
        mask_a: First binary mask (uint8, 0 or 255)
        mask_b: Second binary mask (uint8, 0 or 255)

    Returns:
        IoU score in [0, 1]
    """
    # Ensure same size
    if mask_a.shape != mask_b.shape:
        # Resize mask_b to match mask_a
        mask_b = cv2.resize(mask_b, (mask_a.shape[1], mask_a.shape[0]))

    # Binarize to 0/1
    a = (mask_a > 0).astype(np.uint8)
    b = (mask_b > 0).astype(np.uint8)

    # Compute intersection and union
    intersection = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()

    # Handle edge case: both masks empty
    if union == 0:
        return 1.0 if intersection == 0 else 0.0

    return float(intersection) / float(union)


def compute_mask_error(mask_a: np.ndarray, mask_b: np.ndarray) -> float:
    """Compute mask error between GT and rendered masks.

    Uses IoU-based error: error = 1 - IoU.
    This gives an error metric in [0, 1] where:
    - 0 = perfect match (IoU = 1)
    - 1 = complete mismatch (IoU = 0)

    Args:
        mask_a: Ground truth binary mask (uint8, 0 or 255)
        mask_b: Rendered binary mask (uint8, 0 or 255)

    Returns:
        Error score in [0, 1]
    """
    iou_score = iou(mask_a, mask_b)
    return 1.0 - iou_score


def extract_edges(image: np.ndarray, low_threshold: int = 50, high_threshold: int = 150) -> np.ndarray:
    """Extract edges from image using Canny edge detection.

    Args:
        image: Input image (grayscale or RGB)
        low_threshold: Lower threshold for Canny
        high_threshold: Upper threshold for Canny

    Returns:
        Binary edge map (uint8, 0 or 255)
    """
    # Convert to grayscale if needed
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image

    # Apply Canny edge detection
    edges = cv2.Canny(gray, low_threshold, high_threshold)

    return edges


def compute_distance_transform(mask: np.ndarray) -> np.ndarray:
    """Compute distance transform of binary mask.

    For each pixel, computes the distance to the nearest edge pixel.
    This is used for efficient chamfer distance computation.

    Args:
        mask: Binary mask (uint8, 0 or 255)

    Returns:
        Distance transform as float32 array
    """
    # Binarize mask
    binary = (mask > 0).astype(np.uint8)

    # Compute distance transform
    dist_transform = cv2.distanceTransform(binary, cv2.DIST_L2, 5)

    return dist_transform.astype(np.float32)


def directional_chamfer(
    edge_gt: np.ndarray,
    edge_pred: np.ndarray,
    dt_gt: np.ndarray | None = None
) -> float:
    """Compute directional chamfer distance from predicted edges to GT edges.

    This measures how far predicted edge pixels are from the nearest GT edge pixel.
    Uses pre-computed distance transform for efficiency.

    Args:
        edge_gt: Ground truth edge map (uint8, 0 or 255)
        edge_pred: Predicted edge map (uint8, 0 or 255)
        dt_gt: Pre-computed distance transform of GT edges (optional)

    Returns:
        Mean chamfer distance (normalized by image diagonal)
    """
    # Ensure same size
    if edge_gt.shape != edge_pred.shape:
        edge_pred = cv2.resize(edge_pred, (edge_gt.shape[1], edge_gt.shape[0]))

    # Compute distance transform if not provided
    if dt_gt is None:
        dt_gt = compute_distance_transform(edge_gt)

    # Find predicted edge pixels
    pred_pixels = np.where(edge_pred > 0)

    # Handle edge case: no predicted edges
    if len(pred_pixels[0]) == 0:
        return 1.0  # Maximum error

    # Look up distances for all predicted edge pixels
    distances = dt_gt[pred_pixels]

    # Normalize by image diagonal
    diagonal = np.sqrt(edge_gt.shape[0]**2 + edge_gt.shape[1]**2)
    mean_distance = np.mean(distances) / diagonal

    return float(mean_distance)


def symmetric_chamfer(edge_a: np.ndarray, edge_b: np.ndarray) -> float:
    """Compute symmetric chamfer distance between two edge maps.

    This is the average of directional chamfer distances in both directions.

    Args:
        edge_a: First edge map (uint8, 0 or 255)
        edge_b: Second edge map (uint8, 0 or 255)

    Returns:
        Symmetric chamfer distance (normalized)
    """
    # Compute distance transforms
    dt_a = compute_distance_transform(edge_a)
    dt_b = compute_distance_transform(edge_b)

    # Directional chamfer in both directions
    chamfer_ab = directional_chamfer(edge_a, edge_b, dt_a)
    chamfer_ba = directional_chamfer(edge_b, edge_a, dt_b)

    # Return average
    return (chamfer_ab + chamfer_ba) / 2.0


def prepare_edges_and_dt(rgb_image: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Prepare edges and distance transform from RGB image for efficient chamfer computation.

    This is the recommended way to precompute GT edges once at the start of optimization.

    Args:
        rgb_image: RGB image [H, W, 3] as uint8

    Returns:
        Tuple of (edges, distance_transform) where:
        - edges: Binary edge map [H, W] from Canny detection on RGB
        - distance_transform: Precomputed distance transform for chamfer
    """
    edges = extract_edges(rgb_image)
    dt = compute_distance_transform(edges)
    return edges, dt


def compute_chamfer(pred_edges: np.ndarray, gt_dist: np.ndarray) -> float:
    """Compute directional chamfer distance from predicted edges to GT.

    Uses precomputed distance transform for efficiency. This is the standard
    literature approach for edge-based pose optimization.

    Args:
        pred_edges: Predicted edge map [H, W] (binary, 0 or 255)
        gt_dist: Precomputed distance transform of GT edges

    Returns:
        Mean chamfer distance (normalized by image diagonal)
    """
    # Find predicted edge pixels
    pred_pixels = np.where(pred_edges > 0)

    # Handle edge case: no predicted edges
    if len(pred_pixels[0]) == 0:
        return 1.0  # Maximum error

    # Look up distances for all predicted edge pixels
    distances = gt_dist[pred_pixels]

    # Normalize by image diagonal
    diagonal = np.sqrt(gt_dist.shape[0]**2 + gt_dist.shape[1]**2)
    mean_distance = np.mean(distances) / diagonal

    return float(mean_distance)


def compute_global_objective(
    mask_gt: np.ndarray,
    mask_pred: np.ndarray,
    edge_gt: np.ndarray | None = None,
    edge_pred: np.ndarray | None = None,
    iou_weight: float = 1.0,
    edge_weight: float = 1.0,
    gt_dt: np.ndarray | None = None
) -> float:
    """Compute global search objective combining IoU and edge alignment.

    Objective: E_global = (1 - IoU) * iou_weight + Chamfer * edge_weight

    CRITICAL FIX (2025-11-10): Now uses directional chamfer with precomputed DT
    for efficiency and consistency with coarse search. This ensures the edge term
    contributes meaningfully to the objective (was near-zero with symmetric chamfer).

    IMPORTANT: For best results:
    1. Extract edges from RGB images (not masks) using extract_edges()
    2. Precompute GT distance transform once using prepare_edges_and_dt()
    3. Pass gt_dt to this function to avoid recomputing it every iteration

    Args:
        mask_gt: Ground truth mask
        mask_pred: Predicted mask
        edge_gt: Ground truth edges (optional, will compute if None)
        edge_pred: Predicted edges (optional, will compute if None)
        iou_weight: Weight for IoU term
        edge_weight: Weight for edge term
        gt_dt: Precomputed distance transform of GT edges (optional but recommended)

    Returns:
        Combined objective value (lower is better)
    """
    # IoU term
    iou_score = iou(mask_gt, mask_pred)
    iou_error = 1.0 - iou_score

    # Edge term (if edge weights are provided)
    if edge_weight > 0 and edge_pred is not None:
        # CRITICAL FIX: Use directional chamfer with precomputed DT for efficiency
        # This is the standard approach in pose estimation literature
        if gt_dt is not None:
            # Fast path: Use precomputed DT (recommended)
            chamfer = compute_chamfer(edge_pred, gt_dt)
        else:
            # Slow path: Compute symmetric chamfer (fallback)
            if edge_gt is None:
                edge_gt = extract_edges(mask_gt)
            chamfer = symmetric_chamfer(edge_gt, edge_pred)
    else:
        chamfer = 0.0

    # Combined objective
    objective = iou_weight * iou_error + edge_weight * chamfer

    return float(objective)
