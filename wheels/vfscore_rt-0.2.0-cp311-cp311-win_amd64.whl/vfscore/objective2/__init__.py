"""VFScore Objective2 Pipeline - Multi-GT Pre-rendered Library Approach.

This pipeline uses a pre-rendered library of candidate poses compared against
ALL ground truth images for better initialization before refinement.

Key differences from objective (realtime):
1. Multi-GT support: compares ALL reference photos (not just first)
2. Pre-rendered library: 128px lightless renders at 5 degree increments
3. Systematic pose coverage: standard axes (x,y,z) + intermediate (xy,xz,yz)
4. Better initialization: starts from best GT-candidate match pair
"""

__all__ = [
    "Objective2Pipeline",
    "run_objective2_pipeline",
]

from vfscore.objective2.pipeline_objective2 import (
    Objective2Pipeline,
    run_objective2_pipeline,
)
