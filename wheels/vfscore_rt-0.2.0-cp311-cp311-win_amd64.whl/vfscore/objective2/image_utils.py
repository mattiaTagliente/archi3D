"""Image utilities for tri-criterion pipeline.

This module provides image processing utilities for the tri-criterion pose
estimation pipeline, including exact cropping and padding operations.
"""

from pathlib import Path
from typing import Optional, Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageFont


def exact_crop_to_bbox(
    rgb: np.ndarray,
    mask: np.ndarray,
    edge_threshold: int = 64,
    border_px: int = 0
) -> Tuple[np.ndarray, np.ndarray, Tuple[int, int, int, int]]:
    """Crop RGB and mask to tight bounding box around opaque pixels.

    This matches the GT preprocessing logic: find opaque pixels, compute tight
    bounding box, optionally add border margin.

    Args:
        rgb: RGB image as numpy array [H, W, 3] uint8
        mask: Mask image as numpy array [H, W] uint8 (0-255)
        edge_threshold: Threshold for opaque pixels (0-255)
        border_px: Border margin in pixels (added to all sides)

    Returns:
        Tuple of (cropped_rgb, cropped_mask, bbox) where:
        - cropped_rgb: Cropped RGB image [h, w, 3]
        - cropped_mask: Cropped mask image [h, w]
        - bbox: (x_min, y_min, x_max, y_max) in original image coordinates
    """
    # Find opaque pixels (using edge_threshold to ignore anti-aliased edges)
    opaque_coords = np.argwhere(mask > edge_threshold)

    if len(opaque_coords) == 0:
        # No object - return empty crop
        return (
            np.zeros((1, 1, 3), dtype=np.uint8),
            np.zeros((1, 1), dtype=np.uint8),
            (0, 0, 1, 1)
        )

    # Get tight bounding box around opaque pixels
    y_min, x_min = opaque_coords.min(axis=0)
    y_max, x_max = opaque_coords.max(axis=0)

    # Add border margin
    h, w = mask.shape
    y_min = max(0, y_min - border_px)
    x_min = max(0, x_min - border_px)
    y_max = min(h, y_max + border_px + 1)  # +1 to include the last pixel
    x_max = min(w, x_max + border_px + 1)

    # Crop to bbox
    rgb_cropped = rgb[y_min:y_max, x_min:x_max]
    mask_cropped = mask[y_min:y_max, x_min:x_max]

    return rgb_cropped, mask_cropped, (x_min, y_min, x_max, y_max)


def pad_to_dimensions(
    rgb: np.ndarray,
    target_w: int,
    target_h: int,
    background_rgb: Optional[Tuple[int, int, int]] = None
) -> np.ndarray:
    """Center-pad RGB image to target dimensions.

    Args:
        rgb: RGB image as numpy array [H, W, 3] uint8
        target_w: Target width in pixels
        target_h: Target height in pixels
        background_rgb: Background color (R, G, B) uint8. Defaults to black.

    Returns:
        Padded RGB image as numpy array [target_h, target_w, 3] uint8
    """
    h, w = rgb.shape[:2]

    if w == target_w and h == target_h:
        return rgb

    # Use provided background or default to black
    bg_color = background_rgb if background_rgb is not None else (0, 0, 0)

    # Create canvas with background color
    canvas = np.full((target_h, target_w, 3), bg_color, dtype=np.uint8)

    # Calculate paste position (center)
    paste_x = (target_w - w) // 2
    paste_y = (target_h - h) // 2

    # Paste image
    canvas[paste_y:paste_y+h, paste_x:paste_x+w] = rgb

    return canvas


def scale_to_max_dimension(
    rgb: np.ndarray,
    max_dimension: int
) -> np.ndarray:
    """Scale image so longest side equals max_dimension (preserving aspect ratio).

    Args:
        rgb: RGB image as numpy array [H, W, 3] uint8
        max_dimension: Maximum dimension for longest side

    Returns:
        Scaled RGB image as numpy array [h, w, 3] uint8
    """
    h, w = rgb.shape[:2]

    if max(h, w) <= max_dimension:
        return rgb

    # Calculate scale factor
    scale = max_dimension / max(h, w)
    new_w = int(w * scale)
    new_h = int(h * scale)

    # Use PIL for high-quality scaling
    pil_img = Image.fromarray(rgb)
    pil_img = pil_img.resize((new_w, new_h), Image.Resampling.LANCZOS)

    return np.array(pil_img)


def scale_to_target_dimension(
    img: np.ndarray,
    target_dimension: int,
    use_nearest: bool = False
) -> np.ndarray:
    """Scale image so longest side equals exactly target_dimension (up or down).

    Unlike scale_to_max_dimension, this function scales both up AND down to ensure
    the longest side is exactly target_dimension. This is useful for Step 4 crop
    where we want consistent comparison resolution.

    Args:
        img: Image as numpy array [H, W] or [H, W, 3] uint8
        target_dimension: Target dimension for longest side
        use_nearest: If True, use nearest-neighbor interpolation (for masks).
                     If False, use Lanczos (for RGB/grayscale).

    Returns:
        Scaled image as numpy array with same number of channels
    """
    h, w = img.shape[:2]

    if max(h, w) == target_dimension:
        return img

    # Calculate scale factor
    scale = target_dimension / max(h, w)
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))

    # Determine mode and resampling based on input
    if len(img.shape) == 2:
        # Grayscale/mask
        pil_img = Image.fromarray(img, mode='L')
    else:
        # RGB
        pil_img = Image.fromarray(img)

    # Choose resampling method
    resample = Image.Resampling.NEAREST if use_nearest else Image.Resampling.LANCZOS
    pil_img = pil_img.resize((new_w, new_h), resample)

    return np.array(pil_img)


def pad_mask_to_square(
    mask: np.ndarray,
    target_size: int
) -> np.ndarray:
    """Center-pad a grayscale mask to square dimensions.

    Args:
        mask: Grayscale mask as numpy array [H, W] uint8
        target_size: Target square size (both width and height)

    Returns:
        Padded mask as numpy array [target_size, target_size] uint8
    """
    h, w = mask.shape[:2]

    if h == target_size and w == target_size:
        return mask

    # Create square canvas with black background
    canvas = np.zeros((target_size, target_size), dtype=np.uint8)

    # Calculate paste position (center)
    paste_x = (target_size - w) // 2
    paste_y = (target_size - h) // 2

    # Ensure we don't exceed canvas bounds
    paste_x = max(0, paste_x)
    paste_y = max(0, paste_y)
    end_x = min(target_size, paste_x + w)
    end_y = min(target_size, paste_y + h)
    src_w = end_x - paste_x
    src_h = end_y - paste_y

    # Paste mask
    canvas[paste_y:end_y, paste_x:end_x] = mask[:src_h, :src_w]

    return canvas


def exact_crop_and_pad_to_gt(
    rgb: np.ndarray,
    mask: np.ndarray,
    gt_w: int,
    gt_h: int,
    edge_threshold: int = 64,
    border_px: int = 0,
    background_rgb: Optional[Tuple[int, int, int]] = None
) -> np.ndarray:
    """Exact crop to bbox + center pad to match GT dimensions (all-in-one).

    This is a convenience function combining exact_crop_to_bbox() and
    pad_to_dimensions() for the tri-criterion pipeline.

    Args:
        rgb: RGB image as numpy array [H, W, 3] uint8
        mask: Mask image as numpy array [H, W] uint8
        gt_w: Target GT width
        gt_h: Target GT height
        edge_threshold: Threshold for opaque pixels (0-255)
        border_px: Border margin in pixels
        background_rgb: Background color (R, G, B) uint8

    Returns:
        Cropped and padded RGB image as numpy array [gt_h, gt_w, 3] uint8
    """
    # Step 1: Exact crop to tight bbox
    rgb_cropped, _, _ = exact_crop_to_bbox(rgb, mask, edge_threshold, border_px)

    # Step 2: Center pad to GT dimensions
    rgb_padded = pad_to_dimensions(rgb_cropped, gt_w, gt_h, background_rgb)

    return rgb_padded


def save_gt_with_bbox_visualization(
    gt_image_path: Path,
    gt_mask_path: Path,
    output_path: Path,
    edge_threshold: int = 64,
    border_px: int = 0,
    bbox_color: str = "red",
    bbox_width: int = 3
) -> bool:
    """Save GT image with bounding box visualization for debugging.

    This function visualizes the bounding box that will be used for exact
    cropping, helping verify that the crop parameters are correct.

    Args:
        gt_image_path: Path to GT RGB image
        gt_mask_path: Path to GT mask image
        output_path: Path to save visualization
        edge_threshold: Threshold for opaque pixels (0-255)
        border_px: Border margin in pixels
        bbox_color: Color for bbox rectangle (e.g., "red", "green", "blue")
        bbox_width: Line width for bbox rectangle

    Returns:
        True if successful, False otherwise
    """
    try:
        # Load GT image and mask
        gt_img = Image.open(gt_image_path).convert("RGB")
        gt_mask = np.array(Image.open(gt_mask_path).convert("L"))

        # Find opaque pixels
        opaque_coords = np.argwhere(gt_mask > edge_threshold)

        if len(opaque_coords) == 0:
            # No object - save original image
            gt_img.save(output_path)
            return True

        # Get tight bounding box
        y_min, x_min = opaque_coords.min(axis=0)
        y_max, x_max = opaque_coords.max(axis=0)

        # Add border margin
        h, w = gt_mask.shape
        y_min_border = max(0, y_min - border_px)
        x_min_border = max(0, x_min - border_px)
        y_max_border = min(h, y_max + border_px + 1)
        x_max_border = min(w, x_max + border_px + 1)

        # Draw bounding boxes
        draw = ImageDraw.Draw(gt_img)

        # Draw tight bbox (without border) in lighter color
        draw.rectangle(
            [(x_min, y_min), (x_max, y_max)],
            outline="yellow",
            width=max(1, bbox_width - 1)
        )

        # Draw bbox with border in main color
        draw.rectangle(
            [(x_min_border, y_min_border), (x_max_border - 1, y_max_border - 1)],
            outline=bbox_color,
            width=bbox_width
        )

        # Add text annotation
        try:
            # Try to use a larger font
            font = ImageFont.truetype("arial.ttf", 20)
        except Exception:
            # Fall back to default font
            font = ImageFont.load_default()

        # Calculate bbox dimensions
        tight_w = x_max - x_min + 1
        tight_h = y_max - y_min + 1
        border_w = x_max_border - x_min_border
        border_h = y_max_border - y_min_border

        # Add text at top-left
        text = f"Tight: {tight_w}x{tight_h} | With border ({border_px}px): {border_w}x{border_h}"
        draw.text((10, 10), text, fill=bbox_color, font=font)

        # Save visualization
        output_path.parent.mkdir(parents=True, exist_ok=True)
        gt_img.save(output_path)
        return True

    except Exception as e:
        print(f"[ERROR] save_gt_with_bbox_visualization: {e}")
        return False


def save_render_with_bbox_visualization(
    render_mask: np.ndarray,
    output_path: Path,
    edge_threshold: int = 64,
    bbox_color: str = "red",
    bbox_width: int = 2,
    yaw: Optional[float] = None,
    elev: Optional[float] = None,
    iou: Optional[float] = None,
    area: Optional[float] = None,
    ar_error: Optional[float] = None,
    gt_mask: Optional[np.ndarray] = None
) -> bool:
    """Save rendered mask with bounding box visualization and metrics.

    This function visualizes the bounding box computed from a rendered mask,
    along with optional metrics like IoU, area, and aspect ratio error.
    If gt_mask is provided, shows GT mask side-by-side with render mask.

    Args:
        render_mask: Rendered mask as numpy array [H, W] uint8 (0-255)
        output_path: Path to save visualization
        edge_threshold: Threshold for opaque pixels (0-255)
        bbox_color: Color for bbox rectangle
        bbox_width: Line width for bbox rectangle
        yaw: Optional yaw angle in degrees
        elev: Optional elevation angle in degrees
        iou: Optional IoU value
        area: Optional mask area in pixels
        ar_error: Optional aspect ratio error
        gt_mask: Optional GT mask to show side-by-side [H, W] uint8 (0-255)

    Returns:
        True if successful, False otherwise
    """
    try:
        # If GT mask is provided, create side-by-side comparison
        if gt_mask is not None:
            # Ensure masks have the same dimensions
            h, w = render_mask.shape
            if gt_mask.shape != (h, w):
                # Resize GT to match render mask
                gt_mask_resized = np.array(Image.fromarray(gt_mask).resize((w, h), Image.Resampling.LANCZOS))
            else:
                gt_mask_resized = gt_mask

            # Create side-by-side layout: GT (left) | Render (right)
            gt_rgb = np.stack([gt_mask_resized] * 3, axis=-1)
            render_rgb = np.stack([render_mask] * 3, axis=-1)

            # Concatenate horizontally
            combined_rgb = np.concatenate([gt_rgb, render_rgb], axis=1)
            pil_img = Image.fromarray(combined_rgb)

            # Draw bounding boxes on both GT and render
            draw = ImageDraw.Draw(pil_img)

            # GT bbox (left side)
            gt_opaque = np.argwhere(gt_mask_resized > edge_threshold)
            if len(gt_opaque) > 0:
                y_min, x_min = gt_opaque.min(axis=0)
                y_max, x_max = gt_opaque.max(axis=0)
                draw.rectangle(
                    [(x_min, y_min), (x_max, y_max)],
                    outline="cyan",  # GT in cyan
                    width=bbox_width
                )

            # Render bbox (right side, offset by width)
            render_opaque = np.argwhere(render_mask > edge_threshold)
            if len(render_opaque) > 0:
                y_min, x_min = render_opaque.min(axis=0)
                y_max, x_max = render_opaque.max(axis=0)
                draw.rectangle(
                    [(x_min + w, y_min), (x_max + w, y_max)],
                    outline=bbox_color,
                    width=bbox_width
                )

            # Add labels and metrics
            try:
                font = ImageFont.truetype("arial.ttf", 16)
            except Exception:
                font = ImageFont.load_default()

            # Label GT side
            draw.text((10, 10), "GT", fill="cyan", font=font)

            # Label render side with metrics
            text_lines = ["Render"]
            if yaw is not None and elev is not None:
                text_lines.append(f"yaw={yaw:.1f}, elev={elev:.1f}")
            if iou is not None:
                text_lines.append(f"IoU={iou:.3f}")
            if area is not None:
                text_lines.append(f"Area={area:.0f}px")
            if ar_error is not None:
                text_lines.append(f"AR_err={ar_error:.4f}")

            y_offset = 10
            for line in text_lines:
                draw.text((w + 10, y_offset), line, fill=bbox_color, font=font)
                y_offset += 20
        else:
            # Original single-image visualization
            mask_rgb = np.stack([render_mask] * 3, axis=-1)
            pil_img = Image.fromarray(mask_rgb)

            # Find opaque pixels
            opaque_coords = np.argwhere(render_mask > edge_threshold)

            if len(opaque_coords) > 0:
                # Get tight bounding box
                y_min, x_min = opaque_coords.min(axis=0)
                y_max, x_max = opaque_coords.max(axis=0)

                # Draw bounding box
                draw = ImageDraw.Draw(pil_img)
                draw.rectangle(
                    [(x_min, y_min), (x_max, y_max)],
                    outline=bbox_color,
                    width=bbox_width
                )

                # Add metrics text
                try:
                    font = ImageFont.truetype("arial.ttf", 16)
                except Exception:
                    font = ImageFont.load_default()

                # Build text with available metrics
                text_lines = []
                if yaw is not None and elev is not None:
                    text_lines.append(f"Pose: yaw={yaw:.1f}deg, elev={elev:.1f}deg")
                if iou is not None:
                    text_lines.append(f"IoU: {iou:.3f}")
                if area is not None:
                    text_lines.append(f"Area: {area:.0f}px")
                if ar_error is not None:
                    text_lines.append(f"AR_err: {ar_error:.4f}")

                # Draw text lines
                y_offset = 10
                for line in text_lines:
                    draw.text((10, y_offset), line, fill=bbox_color, font=font)
                    y_offset += 20

        # Save visualization
        output_path.parent.mkdir(parents=True, exist_ok=True)
        pil_img.save(output_path)
        return True

    except Exception as e:
        print(f"[ERROR] save_render_with_bbox_visualization: {e}")
        return False
