"""Pre-render library generation for objective2 pipeline.

Generates a library of candidate renders at systematic 5° increments around
standard photographic viewpoints for fast matching against multiple GT images.
"""

from __future__ import annotations

import json
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple
from dataclasses import dataclass, asdict
from PIL import Image

from vfscore.objective2.render_realtime import RealtimeRenderer
from vfscore.objective2.silhouette import iou


@dataclass
class PrerenderPose:
    """Parameters for a pre-rendered pose."""
    azimuth_deg: float
    elevation_deg: float
    radius: float
    fov_deg: float
    obj_yaw_deg: float

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict) -> PrerenderPose:
        """Create from dictionary."""
        return cls(**d)


class PrerenderLibrary:
    """Generates and manages pre-rendered pose library."""

    def __init__(
        self,
        resolution: int = 128,
        angular_step_deg: float = 5.0,
        fov_values: List[float] = None,
        radius_multipliers: List[float] = None,
        elevation_values: List[float] = None
    ):
        """Initialize pre-render library generator.

        Args:
            resolution: Render resolution (default 128px for speed)
            angular_step_deg: Angular step size in degrees (default 5°)
            fov_values: List of FOV values in degrees (default [50.0, 70.0])
            radius_multipliers: List of radius multipliers (default [0.9, 1.0, 1.1])
            elevation_values: List of elevation angles (default [0.0, 15.0, 30.0])
        """
        self.resolution = resolution
        self.angular_step_deg = angular_step_deg
        self.fov_values = fov_values if fov_values is not None else [50.0, 70.0]
        self.radius_multipliers = radius_multipliers if radius_multipliers is not None else [0.9, 1.0, 1.1]
        self.elevation_values = elevation_values if elevation_values is not None else [0.0, 15.0, 30.0]
        self.renderer = RealtimeRenderer(resolution=resolution)

    def _get_bbox_from_mask(self, mask: np.ndarray) -> tuple[int, int, int, int]:
        """Get bounding box from binary mask.

        Args:
            mask: Binary mask array

        Returns:
            (x_min, y_min, x_max, y_max) or None if mask is empty
        """
        coords = np.column_stack(np.where(mask > 0))
        if len(coords) == 0:
            return None
        y_min, x_min = coords.min(axis=0)
        y_max, x_max = coords.max(axis=0)
        return int(x_min), int(y_min), int(x_max), int(y_max)

    def _compute_aspect_ratio(self, mask: np.ndarray) -> float:
        """Compute bounding box aspect ratio (width/height) from mask.

        Args:
            mask: Binary mask array

        Returns:
            Aspect ratio (width/height), or 1.0 if bbox not found
        """
        bbox = self._get_bbox_from_mask(mask)
        if bbox is None:
            return 1.0
        x_min, y_min, x_max, y_max = bbox
        width = x_max - x_min + 1
        height = y_max - y_min + 1
        return width / height if height > 0 else 1.0

    def _check_border_safety(self, mask: np.ndarray, safety_margin_fraction: float, edge_threshold: int = 64) -> tuple[bool, int, str]:
        """Check if mask has sufficient transparent border around object.

        Args:
            mask: Binary mask array (H, W)
            safety_margin_fraction: Required border as fraction of image size (e.g., 0.01 = 1%)
            edge_threshold: Threshold for considering pixel opaque (0-255)

        Returns:
            (is_safe, required_border_px, description)
        """
        h, w = mask.shape
        # Calculate required border in pixels (ceiling to ensure at least 1px at small resolutions)
        required_border_px = int(np.ceil(min(h, w) * safety_margin_fraction))

        # Check all four borders for opaque pixels
        # Special handling for 0px border: check actual image edges (first/last row/column)
        # to detect clipping, but still allow bidirectional radius adjustment
        if required_border_px == 0:
            # Check only the actual edge pixels (first/last row/column)
            top_border = mask[0:1, :]  # First row
            bottom_border = mask[-1:, :]  # Last row
            left_border = mask[:, 0:1]  # First column
            right_border = mask[:, -1:]  # Last column
        else:
            # Check the required border region
            top_border = mask[:required_border_px, :]
            bottom_border = mask[-required_border_px:, :]
            left_border = mask[:, :required_border_px]
            right_border = mask[:, -required_border_px:]

        # Count opaque pixels in each border
        top_opaque = np.count_nonzero(top_border > edge_threshold)
        bottom_opaque = np.count_nonzero(bottom_border > edge_threshold)
        left_opaque = np.count_nonzero(left_border > edge_threshold)
        right_opaque = np.count_nonzero(right_border > edge_threshold)

        total_opaque = top_opaque + bottom_opaque + left_opaque + right_opaque

        if total_opaque > 0:
            borders_hit = []
            if top_opaque > 0: borders_hit.append(f"top({top_opaque}px)")
            if bottom_opaque > 0: borders_hit.append(f"bottom({bottom_opaque}px)")
            if left_opaque > 0: borders_hit.append(f"left({left_opaque}px)")
            if right_opaque > 0: borders_hit.append(f"right({right_opaque}px)")
            description = f"Object touches border: {', '.join(borders_hit)}"
            return False, required_border_px, description
        else:
            description = f"Safe {required_border_px}px border confirmed"
            return True, required_border_px, description

    def _compute_bbox_coverage(self, mask: np.ndarray) -> float:
        """Compute what fraction of the image the object's bounding box covers.

        Args:
            mask: Binary mask array

        Returns:
            Coverage fraction (0.0 to 1.0)
        """
        bbox = self._get_bbox_from_mask(mask)
        if bbox is None:
            return 0.0
        x_min, y_min, x_max, y_max = bbox
        bbox_area = (x_max - x_min + 1) * (y_max - y_min + 1)
        image_area = mask.shape[0] * mask.shape[1]
        return bbox_area / image_area if image_area > 0 else 0.0

    def _ensure_radius_has_border(
        self,
        glb_path: Path,
        initial_radius: float,
        yaw: float,
        elevation: float,
        fov: float,
        calib_config,
        calib_renderer,
        label: str = "",
        margin_fraction: float | None = None,
        debug_dir: Path | None = None
    ) -> tuple[float, int]:
        """Adjust radius to maximize object size while maintaining safe border.

        Uses single criterion: border safety margin (stage-specific).
        - Decrease radius if object is inside safe border (maximize object size)
        - Increase radius if object touches border (restore safety)
        - Stop when boundary crossed multiple times (oscillation detected)
        - Return nearest safe value (under border limit)

        Args:
            glb_path: Path to GLB model
            initial_radius: Starting radius value
            yaw, elevation, fov: Render parameters
            calib_config: Calibration configuration
            calib_renderer: Renderer instance
            label: Label for logging
            margin_fraction: Optional override for border safety margin (if None, uses config default)
            debug_dir: Optional directory to save debug images showing border detection

        Returns:
            (adjusted_radius, iterations_needed)
        """
        radius = initial_radius
        if margin_fraction is None:
            # Fallback to initial margin for backward compatibility
            margin_fraction = calib_config.initial_border_safety_margin_fraction
        step = calib_config.radius_adjustment_step
        max_iters = calib_config.max_radius_adjustment_iterations

        # Track oscillation (boundary crossings)
        last_action = None  # 'increase' or 'decrease'
        direction_changes = 0
        best_safe_radius = None

        for iteration in range(max_iters):
            # Render mask at current radius
            mask = calib_renderer.render_mask(
                glb_path,
                azimuth_deg=0.0,
                elevation_deg=elevation,
                radius=radius,
                fov_deg=fov,
                obj_yaw_deg=yaw,
                coarse=False
            )

            # Check border safety (single criterion)
            is_safe, border_px, description = self._check_border_safety(
                mask, margin_fraction, calib_config.edge_threshold
            )

            if iteration == 0:
                print(f"    {label}Initial: radius={radius:.4f}, {description}")

                # Save debug image for initial state if debug_dir provided
                if debug_dir is not None:
                    debug_dir.mkdir(parents=True, exist_ok=True)
                    from PIL import Image as PILImage, ImageDraw
                    # Create RGB visualization showing border regions
                    h, w = mask.shape
                    vis_rgb = np.stack([mask] * 3, axis=-1).copy()
                    # Highlight border regions in red if object touches them
                    if not is_safe:
                        # Mark border pixels in red
                        vis_rgb[:border_px, :] = [255, 0, 0]  # top
                        vis_rgb[-border_px:, :] = [255, 0, 0]  # bottom
                        vis_rgb[:, :border_px] = [255, 0, 0]  # left
                        vis_rgb[:, -border_px:] = [255, 0, 0]  # right
                    else:
                        # Mark safe border in green
                        vis_rgb[:border_px, :] = [0, 255, 0]  # top
                        vis_rgb[-border_px:, :] = [0, 255, 0]  # bottom
                        vis_rgb[:, :border_px] = [0, 255, 0]  # left
                        vis_rgb[:, -border_px:] = [0, 255, 0]  # right
                    debug_img = PILImage.fromarray(vis_rgb.astype(np.uint8))
                    debug_path = debug_dir / f"{label}_initial_r{radius:.4f}_border{border_px}px.png"
                    debug_img.save(debug_path)

            # Track best safe radius encountered
            if is_safe:
                best_safe_radius = radius

            # Determine action based on single criterion: border safety
            if is_safe:
                # Object is inside safe border - try to get closer (decrease radius)
                action = 'decrease'
                new_radius = radius * (1.0 - step)
                if iteration == 0:
                    print(f"    {label}Safe border detected, decreasing radius to maximize size (step={step*100:.1f}%)...")
            else:
                # Object touches border - move away (increase radius)
                action = 'increase'
                new_radius = radius * (1.0 + step)
                if iteration == 0:
                    print(f"    {label}{description}")
                    print(f"    {label}Increasing radius (step={step*100:.1f}%, required_border={border_px}px)...")

            # Detect direction change (crossed boundary)
            if last_action is not None and action != last_action:
                direction_changes += 1

                # Stop after 2 direction changes (oscillation around boundary)
                if direction_changes >= 2:
                    if best_safe_radius is not None:
                        print(f"    {label}Converged (boundary crossed {direction_changes}x): "
                              f"radius {initial_radius:.4f} → {best_safe_radius:.4f}")

                        # Save final debug image
                        if debug_dir is not None:
                            final_mask = calib_renderer.render_mask(
                                glb_path, azimuth_deg=0.0, elevation_deg=elevation,
                                radius=best_safe_radius, fov_deg=fov, obj_yaw_deg=yaw, coarse=False
                            )
                            final_is_safe, final_border_px, final_desc = self._check_border_safety(
                                final_mask, margin_fraction, calib_config.edge_threshold
                            )
                            from PIL import Image as PILImage
                            h, w = final_mask.shape
                            vis_rgb = np.stack([final_mask] * 3, axis=-1).copy()
                            # Highlight border in green (should be safe)
                            vis_rgb[:final_border_px, :] = [0, 255, 0]
                            vis_rgb[-final_border_px:, :] = [0, 255, 0]
                            vis_rgb[:, :final_border_px] = [0, 255, 0]
                            vis_rgb[:, -final_border_px:] = [0, 255, 0]
                            debug_img = PILImage.fromarray(vis_rgb.astype(np.uint8))
                            debug_path = debug_dir / f"{label}_final_r{best_safe_radius:.4f}_border{final_border_px}px.png"
                            debug_img.save(debug_path)

                        return best_safe_radius, iteration
                    else:
                        print(f"    {label}WARNING: Converged but no safe radius found, using {radius:.4f}")
                        return radius, iteration

            # Update for next iteration
            last_action = action
            radius = new_radius

        # Max iterations reached - use best safe radius found
        if best_safe_radius is not None:
            print(f"    {label}Max iterations ({max_iters}), using best safe radius: "
                  f"{initial_radius:.4f} → {best_safe_radius:.4f}")
            return best_safe_radius, max_iters
        else:
            print(f"    {label}WARNING: Max iterations ({max_iters}), no safe radius found, using {radius:.4f}")
            return radius, max_iters

    def _calibrate_radius_binary_search(
        self,
        glb_path: Path,
        gt_mask: np.ndarray,
        initial_radius: float,
        azimuth: float,
        elevation: float,
        yaw: float,
        fov: float,
        calib_config,
        calib_renderer,
        output_dir: Path = None,
        label: str = ""
    ) -> tuple[float, list]:
        """Perform binary search to calibrate radius at a specific pose.

        This is a reusable component that performs ONLY the binary search,
        assuming orientation is already known.

        Args:
            glb_path: Path to GLB file
            gt_mask: Ground truth mask (already resized to calibration resolution)
            initial_radius: Starting radius for binary search
            azimuth: Camera azimuth (degrees)
            elevation: Camera elevation (degrees)
            yaw: Object yaw rotation (degrees)
            fov: Field of view (degrees)
            calib_config: Calibration configuration
            calib_renderer: Renderer instance
            output_dir: Optional directory for visualizations
            label: Label prefix for logging

        Returns:
            (calibrated_radius, calibration_steps)
        """
        from PIL import Image

        calib_res = calib_config.resolution
        gt_area = np.count_nonzero(gt_mask > calib_config.edge_threshold)

        # Binary search bounds
        radius_min = initial_radius * 0.5
        radius_max = initial_radius * 2.0
        radius = initial_radius

        # Track calibration steps for visualization
        calibration_steps = []

        print(f"{label}Binary search for optimal radius (target_bias={calib_config.target_bias:.3f}, "
              f"tolerance={calib_config.tolerance*100:.2f}%, max_iter={calib_config.max_iterations})")
        print(f"{label}  Pose: azimuth={azimuth:.1f}deg, elevation={elevation:.1f}deg, yaw={yaw:.1f}deg, fov={fov:.1f}deg")

        for iteration in range(calib_config.max_iterations):
            # Render mask at current radius (only mask needed for calibration)
            pred_mask = calib_renderer.render_mask(
                glb_path,
                azimuth_deg=azimuth,
                elevation_deg=elevation,
                radius=radius,
                fov_deg=fov,
                obj_yaw_deg=yaw,
                coarse=False
            )

            # Compute area ratio
            pred_area = np.count_nonzero(pred_mask > calib_config.edge_threshold)
            area_ratio = pred_area / gt_area if gt_area > 0 else 1.0

            # Store calibration step (mask only - RGB not needed)
            calibration_steps.append({
                'iteration': iteration,
                'radius': radius,
                'area_ratio': area_ratio,
                'pred_mask': pred_mask.copy()
            })

            # Print progress
            print(f"{label}  Iter {iteration:2d}: radius={radius:.4f}, area_ratio={area_ratio:.4f} "
                  f"(pred={pred_area:5d}, gt={gt_area:5d})")

            # Check convergence
            target_ratio = calib_config.target_bias
            tolerance = calib_config.tolerance

            if abs(area_ratio - target_ratio) < tolerance:
                print(f"{label}  ✓ Converged: area_ratio={area_ratio:.4f} within {tolerance*100:.2f}% of target {target_ratio:.3f}")
                break
            elif area_ratio > target_ratio:  # Too close, increase radius
                radius_min = radius
                radius = (radius + radius_max) / 2
            else:  # Too far, decrease radius
                radius_max = radius
                radius = (radius_min + radius) / 2

        # Final summary
        final_area_ratio = calibration_steps[-1]['area_ratio'] if calibration_steps else 1.0
        print(f"{label}  Result: radius={radius:.4f} (from {initial_radius:.4f}), area_ratio={final_area_ratio:.4f}")

        # Save visualizations if requested
        if output_dir is not None:
            calib_viz_dir = output_dir / "calibration_viz"
            calib_viz_dir.mkdir(parents=True, exist_ok=True)

            # Save GT mask
            Image.fromarray(gt_mask).save(calib_viz_dir / "gt_mask.png")

            # Save all calibration steps (mask only)
            for idx, step in enumerate(calibration_steps):
                if step['pred_mask'] is not None:
                    Image.fromarray(step['pred_mask']).save(
                        calib_viz_dir / f"step_{idx:02d}_mask_r{step['radius']:.3f}.png"
                    )

        return radius, calibration_steps

    def calibrate_radius(
        self,
        glb_path: Path,
        gt_mask: np.ndarray,
        initial_radius: float,
        calib_config,  # RadiusCalibrationConfig
        output_dir: Path = None
    ) -> Tuple[float, dict]:
        """Calibrate radius to match GT mask area using 2D orientation search + binary search.

        TWO-STAGE 2D SEARCH (YAW + ELEVATION):
        1. Coarse grid search over yaw and elevation ranges
        2. Fine refinement around best coarse match

        ORIENTATION MATCHING METHODS:
        - "aspect_ratio": Find orientation that matches GT's bounding box aspect ratio
          (Best for matching GT's actual viewpoint, recommended)
        - "max_area": Find orientation that maximizes projected area
          (Legacy method, assumes frontal view)

        ROBUSTNESS IMPROVEMENTS:
        - Dedicated 256px calibration renderer (higher quality than 128px library)
        - LANCZOS resizing for better edge preservation
        - Configurable edge threshold (default 64) to include anti-aliased edges
        - Configurable target bias (default 1.02 = 2% larger for robust matching)
        - Tighter tolerance (default 0.2%) for precise calibration
        - More iterations (default 50) for better convergence
        - All parameters user-configurable via config.yaml

        Args:
            glb_path: Path to GLB file
            gt_mask: Ground truth mask (binary, 0-255)
            initial_radius: Starting radius guess
            calib_config: RadiusCalibrationConfig with all calibration parameters
            output_dir: Optional directory to save calibration visualizations

        Returns:
            Calibrated radius value
        """
        # Create dedicated calibration renderer at higher resolution for accuracy
        from PIL import Image
        calib_res = calib_config.resolution
        calib_renderer = RealtimeRenderer(resolution=calib_res)

        # Resize GT mask to calibration resolution for fair comparison
        # Use LANCZOS for better quality (preserves edges better than NEAREST)
        gt_mask_resized = np.array(
            Image.fromarray(gt_mask).resize((calib_res, calib_res), Image.Resampling.LANCZOS)
        )
        gt_area = np.count_nonzero(gt_mask_resized > calib_config.edge_threshold)

        # Compute GT characteristics based on matching method
        method = calib_config.orientation_method
        calib_fov = calib_config.fov_deg  # Use dedicated calibration FOV

        if method == "aspect_ratio":
            gt_aspect = self._compute_aspect_ratio(gt_mask_resized)
            gt_aspect_inv = 1.0 / gt_aspect if gt_aspect > 0 else 1.0
            print(f"\n  [Radius Calibration] PHASE 1: Orientation matching using aspect ratio criterion")
            print(f"  Calibration FOV: {calib_fov:.1f} degrees")
            print(f"  GT bbox aspect ratio: {gt_aspect:.3f} (width/height), inverse: {gt_aspect_inv:.3f} (height/width)")
            print(f"  GT mask area: {gt_area} pixels @ {calib_res}px resolution (threshold={calib_config.edge_threshold})")
            print(f"  Will match using MINIMUM of (|model - gt|, |model - 1/gt|) to handle coordinate flips")
        else:  # max_area
            print(f"\n  [Radius Calibration] PHASE 1: Orientation matching using projected area criterion")
            print(f"  Calibration FOV: {calib_fov:.1f} degrees")
            print(f"  GT mask area: {gt_area} pixels @ {calib_res}px resolution (threshold={calib_config.edge_threshold})")

        # STEP 1: Initial radius adjustment at configured orientation
        # This ensures we start with a reasonable radius before orientation search
        initial_yaw = calib_config.initial_adjustment_yaw
        initial_elev = calib_config.initial_adjustment_elevation
        initial_margin = calib_config.initial_border_safety_margin_fraction
        print(f"\n  Step 1: Initial radius adjustment at configured orientation (yaw={initial_yaw:.1f}deg, elev={initial_elev:.1f}deg, margin={initial_margin*100:.1f}%)")
        orientation_search_radius, _ = self._ensure_radius_has_border(
            glb_path, initial_radius, yaw=initial_yaw, elevation=initial_elev, fov=calib_fov,
            calib_config=calib_config, calib_renderer=calib_renderer, label="  ",
            margin_fraction=initial_margin
        )

        # DEBUG: Save image after initial radius adjustment
        if output_dir and method == "aspect_ratio":
            debug_mask = calib_renderer.render_mask(
                glb_path, azimuth_deg=0.0, elevation_deg=initial_elev,
                radius=orientation_search_radius, fov_deg=calib_fov,
                obj_yaw_deg=initial_yaw, coarse=False
            )
            debug_aspect = self._compute_aspect_ratio(debug_mask)
            debug_error_direct = abs(debug_aspect - gt_aspect)
            debug_error_inverted = abs(debug_aspect - gt_aspect_inv)
            debug_error = min(debug_error_direct, debug_error_inverted)
            Image.fromarray(debug_mask).save(output_dir / f"debug_step1_initial_radius_adj.png")
            print(f"  [DEBUG] After Step 1: radius={orientation_search_radius:.4f}, aspect={debug_aspect:.3f}, AR_error={debug_error:.4f}")

        # Determine elevation search range
        if calib_config.elevation_search_enabled:
            elev_start = calib_config.elevation_search_start
            elev_stop = calib_config.elevation_search_stop
            elev_coarse_step = calib_config.elevation_search_coarse_step
        else:
            # Single elevation value
            elev_start = 0.0
            elev_stop = 0.0
            elev_coarse_step = 1.0  # Dummy value

        # STAGE 1: Iterative coarse 2D grid search (yaw × elevation) with intermediate radius adjustments
        yaw_coarse_step = calib_config.yaw_search_coarse_step
        coarse_yaws = np.arange(0, 360, yaw_coarse_step)
        coarse_elevs = np.arange(elev_start, elev_stop + elev_coarse_step, elev_coarse_step) if calib_config.elevation_search_enabled else [0.0]

        # Number of coarse iterations (configurable: 1-5, default: 2)
        num_coarse_iters = max(1, min(5, calib_config.coarse_iterations))
        print(f"\n  Stage 1 (Coarse): Running {num_coarse_iters} iteration(s) of coarse search + radius adjustment")

        best_coarse_yaw = 0.0
        best_coarse_elev = 0.0
        best_coarse_score = float('inf') if method == "aspect_ratio" else 0.0

        # Iterate: coarse search → radius adjustment → coarse search → ...
        for iter_idx in range(num_coarse_iters):
            stage_label = chr(ord('a') + iter_idx)  # 'a', 'b', 'c', 'd', 'e'

            print(f"\n  Stage 1{stage_label} (Coarse iteration {iter_idx+1}/{num_coarse_iters}): Testing {len(coarse_yaws)} yaw × {len(coarse_elevs)} elevation = {len(coarse_yaws) * len(coarse_elevs)} orientations...")

            # Reset best score for this iteration
            best_coarse_score = float('inf') if method == "aspect_ratio" else 0.0
            coarse_candidates = []

            for test_elev in coarse_elevs:
                for test_yaw in coarse_yaws:
                    test_mask = calib_renderer.render_mask(
                        glb_path,
                        azimuth_deg=0.0,
                        elevation_deg=test_elev,
                        radius=orientation_search_radius,
                        fov_deg=calib_fov,
                        obj_yaw_deg=test_yaw,
                        coarse=False  # Use full calibration resolution
                    )

                    if method == "aspect_ratio":
                        # Minimize aspect ratio difference (check both orientations to handle coord flips)
                        test_aspect = self._compute_aspect_ratio(test_mask)
                        error_direct = abs(test_aspect - gt_aspect)
                        error_inverted = abs(test_aspect - gt_aspect_inv)
                        score = min(error_direct, error_inverted)
                        # Store: (yaw, elev, ar_error, aspect, mask)
                        coarse_candidates.append((test_yaw, test_elev, score, test_aspect, test_mask))
                        if score < best_coarse_score:
                            best_coarse_score = score
                            best_coarse_yaw = test_yaw
                            best_coarse_elev = test_elev
                    else:  # max_area
                        # Maximize projected area
                        score = np.count_nonzero(test_mask > calib_config.edge_threshold)
                        coarse_candidates.append((test_yaw, test_elev, score, None, test_mask))
                        if score > best_coarse_score:
                            best_coarse_score = score
                            best_coarse_yaw = test_yaw
                            best_coarse_elev = test_elev

            if method == "aspect_ratio":
                # Sort by AR error (ascending)
                coarse_candidates.sort(key=lambda x: x[2])

                # AR+IoU hybrid scoring: filter top AR matches by IoU to resolve ambiguity
                best_coarse_iou = None
                if calib_config.ar_iou_filtering_enabled:
                    top_fraction = calib_config.ar_iou_filtering_top_fraction
                    num_to_check = max(1, int(len(coarse_candidates) * top_fraction))

                    print(f"  AR+IoU filtering: Scoring top {num_to_check} AR candidates ({top_fraction*100:.0f}%) by IoU...")

                    # Score top AR candidates by IoU
                    iou_candidates = []
                    for yaw, elev, ar_error, aspect, mask in coarse_candidates[:num_to_check]:
                        candidate_iou = iou(gt_mask_resized, mask)
                        iou_candidates.append((yaw, elev, ar_error, aspect, mask, candidate_iou))

                    # Sort by IoU (descending) and pick best
                    iou_candidates.sort(key=lambda x: x[5], reverse=True)
                    best_yaw, best_elev, best_ar_error, best_aspect, best_mask, best_iou = iou_candidates[0]

                    # Update best coarse match
                    best_coarse_yaw = best_yaw
                    best_coarse_elev = best_elev
                    best_coarse_score = best_ar_error  # Keep AR error for consistency
                    best_coarse_iou = best_iou

                    # Show top 5 IoU matches
                    print(f"  Top 5 IoU matches (from top {num_to_check} AR candidates):")
                    for i, (yaw, elev, ar_error, aspect, mask, candidate_iou) in enumerate(iou_candidates[:5]):
                        marker = " <- SELECTED" if i == 0 else ""
                        print(f"    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, AR_err={ar_error:.4f}, IoU={candidate_iou:.3f}{marker}")
                    print(f"  Stage 1{stage_label} result: yaw={best_coarse_yaw:.0f}deg, elev={best_coarse_elev:.0f}deg, AR_error={best_coarse_score:.4f}, IoU={best_coarse_iou:.3f}")
                else:
                    # Pure AR matching (original behavior)
                    print(f"  Top 5 coarse matches (by aspect ratio error):")
                    for i, (yaw, elev, error, aspect, _) in enumerate(coarse_candidates[:5]):
                        marker = " <- SELECTED" if i == 0 else ""
                        print(f"    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, aspect={aspect:.3f}, error={error:.4f}{marker}")
                    print(f"  Stage 1{stage_label} result: yaw={best_coarse_yaw:.0f}deg, elev={best_coarse_elev:.0f}deg, aspect_error={best_coarse_score:.4f}")

                # DEBUG: Save top 5 coarse candidate images
                if output_dir:
                    if calib_config.ar_iou_filtering_enabled:
                        # Save from IoU-ranked candidates (post-filtering)
                        for i, (yaw, elev, ar_error, aspect, mask, candidate_iou) in enumerate(iou_candidates[:5]):
                            selected_marker = "_SELECTED" if i == 0 else ""
                            Image.fromarray(mask).save(
                                output_dir / f"debug_stage1{stage_label}_coarse_rank{i+1}_yaw{yaw:.0f}_elev{elev:.0f}_ARerr{ar_error:.4f}_IoU{candidate_iou:.3f}{selected_marker}.png"
                            )
                    else:
                        # Save from AR-ranked candidates (original behavior)
                        for i, (yaw, elev, error, aspect, mask) in enumerate(coarse_candidates[:5]):
                            selected_marker = "_SELECTED" if i == 0 else ""
                            Image.fromarray(mask).save(
                                output_dir / f"debug_stage1{stage_label}_coarse_rank{i+1}_yaw{yaw:.0f}_elev{elev:.0f}_err{error:.4f}{selected_marker}.png"
                            )
            else:
                # max_area method - no IoU filtering needed
                coarse_candidates.sort(key=lambda x: x[2], reverse=True)  # Sort by area (descending)
                print(f"  Top 5 coarse matches (by projected area):")
                for i, (yaw, elev, area, _, __) in enumerate(coarse_candidates[:5]):
                    marker = " <- SELECTED" if i == 0 else ""
                    print(f"    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, area={area:.0f} pixels{marker}")
                print(f"  Stage 1{stage_label} result: yaw={best_coarse_yaw:.0f}deg, elev={best_coarse_elev:.0f}deg, area={best_coarse_score:.0f} pixels")
                best_coarse_iou = None

            # INTERMEDIATE: Radius adjustment after EVERY coarse orientation search
            # This is ESSENTIAL because the coarse match changed the orientation,
            # so we must recalibrate radius for the new orientation before fine search
            intermediate_margin = calib_config.intermediate_border_safety_margin_fraction
            print(f"\n  Intermediate radius adjustment {stage_label} at coarse-matched orientation (yaw={best_coarse_yaw:.0f}deg, elev={best_coarse_elev:.0f}deg, margin={intermediate_margin*100:.1f}%)...")
            radius_before_intermediate = orientation_search_radius
            orientation_search_radius, _ = self._ensure_radius_has_border(
                glb_path=glb_path,
                initial_radius=orientation_search_radius,
                yaw=best_coarse_yaw,
                elevation=best_coarse_elev,
                fov=calib_fov,
                calib_config=calib_config,
                calib_renderer=calib_renderer,
                label="  ",
                margin_fraction=intermediate_margin
            )
            print(f"  Radius after intermediate adjustment {stage_label}: {orientation_search_radius:.4f}")

            # DEBUG: Save image and show AR error BEFORE and AFTER intermediate radius adjustment
            if output_dir and method == "aspect_ratio":
                # Before intermediate adjustment
                mask_before = calib_renderer.render_mask(
                    glb_path, azimuth_deg=0.0, elevation_deg=best_coarse_elev,
                    radius=radius_before_intermediate, fov_deg=calib_fov,
                    obj_yaw_deg=best_coarse_yaw, coarse=False
                )
                aspect_before = self._compute_aspect_ratio(mask_before)
                error_before_direct = abs(aspect_before - gt_aspect)
                error_before_inverted = abs(aspect_before - gt_aspect_inv)
                error_before = min(error_before_direct, error_before_inverted)
                Image.fromarray(mask_before).save(output_dir / f"debug_intermediate{stage_label}_BEFORE_radius{radius_before_intermediate:.4f}_err{error_before:.4f}.png")

                # After intermediate adjustment
                mask_after = calib_renderer.render_mask(
                    glb_path, azimuth_deg=0.0, elevation_deg=best_coarse_elev,
                    radius=orientation_search_radius, fov_deg=calib_fov,
                    obj_yaw_deg=best_coarse_yaw, coarse=False
                )
                aspect_after = self._compute_aspect_ratio(mask_after)
                error_after_direct = abs(aspect_after - gt_aspect)
                error_after_inverted = abs(aspect_after - gt_aspect_inv)
                error_after = min(error_after_direct, error_after_inverted)
                Image.fromarray(mask_after).save(output_dir / f"debug_intermediate{stage_label}_AFTER_radius{orientation_search_radius:.4f}_err{error_after:.4f}.png")

                print(f"  [DEBUG] Intermediate radius adjustment {stage_label} impact:")
                print(f"    BEFORE: radius={radius_before_intermediate:.4f}, aspect={aspect_before:.3f}, AR_error={error_before:.4f}")
                print(f"    AFTER:  radius={orientation_search_radius:.4f}, aspect={aspect_after:.3f}, AR_error={error_after:.4f}")
                print(f"    CHANGE: radius {'+' if orientation_search_radius > radius_before_intermediate else ''}{(orientation_search_radius - radius_before_intermediate):.4f}, "
                      f"AR_error {'+' if error_after > error_before else ''}{(error_after - error_before):.4f}")

        # STAGE 2: Fine refinement around best coarse match
        yaw_fine_step = calib_config.yaw_search_fine_step
        yaw_fine_range = calib_config.yaw_search_fine_range
        fine_yaw_start = best_coarse_yaw - yaw_fine_range / 2
        fine_yaw_end = best_coarse_yaw + yaw_fine_range / 2
        fine_yaws = np.arange(fine_yaw_start, fine_yaw_end + yaw_fine_step, yaw_fine_step) % 360

        if calib_config.elevation_search_enabled:
            elev_fine_step = calib_config.elevation_search_fine_step
            elev_fine_range = calib_config.elevation_search_fine_range
            fine_elev_start = max(elev_start, best_coarse_elev - elev_fine_range / 2)
            fine_elev_end = min(elev_stop, best_coarse_elev + elev_fine_range / 2)
            fine_elevs = np.arange(fine_elev_start, fine_elev_end + elev_fine_step, elev_fine_step)
        else:
            fine_elevs = [0.0]

        print(f"  Stage 2 (Fine): Testing {len(fine_yaws)} yaw × {len(fine_elevs)} elevation = {len(fine_yaws) * len(fine_elevs)} orientations...")

        best_yaw = best_coarse_yaw
        best_elev = best_coarse_elev
        best_score = best_coarse_score
        best_iou = best_coarse_iou  # Carry forward IoU from coarse match

        # Track fine candidates for diagnostics
        fine_candidates = []

        for test_elev in fine_elevs:
            for test_yaw in fine_yaws:
                test_mask = calib_renderer.render_mask(
                    glb_path,
                    azimuth_deg=0.0,
                    elevation_deg=test_elev,
                    radius=orientation_search_radius,
                    fov_deg=calib_fov,
                    obj_yaw_deg=test_yaw,
                    coarse=False  # Use full calibration resolution
                )

                if method == "aspect_ratio":
                    # Minimize aspect ratio difference (check both orientations to handle coord flips)
                    test_aspect = self._compute_aspect_ratio(test_mask)
                    error_direct = abs(test_aspect - gt_aspect)
                    error_inverted = abs(test_aspect - gt_aspect_inv)
                    score = min(error_direct, error_inverted)
                    # Store: (yaw, elev, ar_error, aspect, mask)
                    fine_candidates.append((test_yaw, test_elev, score, test_aspect, test_mask))
                    if score < best_score:
                        best_score = score
                        best_yaw = test_yaw
                        best_elev = test_elev
                else:  # max_area
                    score = np.count_nonzero(test_mask > calib_config.edge_threshold)
                    fine_candidates.append((test_yaw, test_elev, score, None, test_mask))
                    if score > best_score:
                        best_score = score
                        best_yaw = test_yaw
                        best_elev = test_elev

        if method == "aspect_ratio":
            # Sort by AR error (ascending)
            fine_candidates.sort(key=lambda x: x[2])

            # AR+IoU hybrid scoring: filter top AR matches by IoU to resolve ambiguity
            if calib_config.ar_iou_filtering_enabled:
                top_fraction = calib_config.ar_iou_filtering_top_fraction
                num_to_check = max(1, int(len(fine_candidates) * top_fraction))

                print(f"  AR+IoU filtering: Scoring top {num_to_check} AR candidates ({top_fraction*100:.0f}%) by IoU...")

                # Score top AR candidates by IoU
                iou_candidates = []
                for yaw, elev, ar_error, aspect, mask in fine_candidates[:num_to_check]:
                    candidate_iou = iou(gt_mask_resized, mask)
                    iou_candidates.append((yaw, elev, ar_error, aspect, mask, candidate_iou))

                # Sort by IoU (descending) and pick best
                iou_candidates.sort(key=lambda x: x[5], reverse=True)
                best_yaw, best_elev, best_ar_error, best_aspect, best_mask, best_iou = iou_candidates[0]
                best_score = best_ar_error  # Keep AR error for consistency

                # Show top 5 IoU matches
                print(f"  Top 5 IoU matches (from top {num_to_check} AR candidates):")
                for i, (yaw, elev, ar_error, aspect, mask, candidate_iou) in enumerate(iou_candidates[:5]):
                    marker = " <- SELECTED" if i == 0 else ""
                    print(f"    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, AR_err={ar_error:.4f}, IoU={candidate_iou:.3f}{marker}")
                print(f"  Stage 2 result: yaw={best_yaw:.1f}deg, elev={best_elev:.1f}deg, AR_error={best_score:.4f}, IoU={best_iou:.3f}")
            else:
                # Pure AR matching (original behavior)
                print(f"  Top 5 fine matches (by aspect ratio error):")
                for i, (yaw, elev, error, aspect, _) in enumerate(fine_candidates[:5]):
                    marker = " <- SELECTED" if yaw == best_yaw and elev == best_elev else ""
                    print(f"    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, aspect={aspect:.3f}, error={error:.4f}{marker}")

                final_aspect = self._compute_aspect_ratio(calib_renderer.render_mask(
                    glb_path, azimuth_deg=0.0, elevation_deg=best_elev, radius=orientation_search_radius,
                    fov_deg=calib_fov, obj_yaw_deg=best_yaw, coarse=False
                ))
                # Determine which orientation matched better
                error_direct = abs(final_aspect - gt_aspect)
                error_inverted = abs(final_aspect - gt_aspect_inv)
                matched_orientation = "direct" if error_direct < error_inverted else "inverted"
                matched_gt = gt_aspect if error_direct < error_inverted else gt_aspect_inv

                print(f"  Stage 2 result: yaw={best_yaw:.1f}deg, elev={best_elev:.1f}deg")
                print(f"  Final orientation: yaw={best_yaw:.1f}deg, elev={best_elev:.1f}deg")
                print(f"  Aspect ratio match ({matched_orientation}): GT={matched_gt:.3f}, Model={final_aspect:.3f}, error={best_score:.4f}")

            # DEBUG: Save top 5 fine candidate images
            if output_dir:
                if calib_config.ar_iou_filtering_enabled:
                    # Save from IoU-ranked candidates (post-filtering)
                    for i, (yaw, elev, ar_error, aspect, mask, candidate_iou) in enumerate(iou_candidates[:5]):
                        selected_marker = "_SELECTED" if i == 0 else ""
                        Image.fromarray(mask).save(
                            output_dir / f"debug_stage2_fine_rank{i+1}_yaw{yaw:.1f}_elev{elev:.1f}_ARerr{ar_error:.4f}_IoU{candidate_iou:.3f}{selected_marker}.png"
                        )
                else:
                    # Save from AR-ranked candidates (original behavior)
                    for i, (yaw, elev, error, aspect, mask) in enumerate(fine_candidates[:5]):
                        selected_marker = "_SELECTED" if i == 0 else ""
                        Image.fromarray(mask).save(
                            output_dir / f"debug_stage2_fine_rank{i+1}_yaw{yaw:.1f}_elev{elev:.1f}_err{error:.4f}{selected_marker}.png"
                        )
        else:
            # max_area method - no IoU filtering needed
            fine_candidates.sort(key=lambda x: x[2], reverse=True)  # Sort by area (descending)
            print(f"  Top 5 fine matches (by projected area):")
            for i, (yaw, elev, area, _, __) in enumerate(fine_candidates[:5]):
                marker = " <- SELECTED" if yaw == best_yaw and elev == best_elev else ""
                print(f"    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, area={area:.0f} pixels{marker}")

            print(f"  Stage 2 result: yaw={best_yaw:.1f}deg, elev={best_elev:.1f}deg, area={best_score:.0f} pixels")
            print(f"  Final orientation: yaw={best_yaw:.1f}deg, elev={best_elev:.1f}deg (maximum projected area)")

        # STEP 2: Post-orientation radius adjustment at best matched orientation
        # Now that we found the orientation, re-check and adjust radius for this specific pose
        final_margin = calib_config.final_border_safety_margin_fraction
        print(f"\n  Step 2: Post-orientation radius adjustment at matched orientation (yaw={best_yaw:.1f}deg, elev={best_elev:.1f}deg, margin={final_margin*100:.1f}%)")
        radius_before_post = orientation_search_radius
        orientation_search_radius, _ = self._ensure_radius_has_border(
            glb_path, orientation_search_radius, yaw=best_yaw, elevation=best_elev, fov=calib_fov,
            calib_config=calib_config, calib_renderer=calib_renderer, label="  ",
            margin_fraction=final_margin
        )

        # DEBUG: Save image and show AR error BEFORE and AFTER post-orientation radius adjustment
        if output_dir and method == "aspect_ratio":
            # Before post-orientation adjustment
            mask_before_post = calib_renderer.render_mask(
                glb_path, azimuth_deg=0.0, elevation_deg=best_elev,
                radius=radius_before_post, fov_deg=calib_fov,
                obj_yaw_deg=best_yaw, coarse=False
            )
            aspect_before_post = self._compute_aspect_ratio(mask_before_post)
            error_before_post_direct = abs(aspect_before_post - gt_aspect)
            error_before_post_inverted = abs(aspect_before_post - gt_aspect_inv)
            error_before_post = min(error_before_post_direct, error_before_post_inverted)
            Image.fromarray(mask_before_post).save(output_dir / f"debug_step2_post_BEFORE_radius{radius_before_post:.4f}_err{error_before_post:.4f}.png")

            # After post-orientation adjustment
            mask_after_post = calib_renderer.render_mask(
                glb_path, azimuth_deg=0.0, elevation_deg=best_elev,
                radius=orientation_search_radius, fov_deg=calib_fov,
                obj_yaw_deg=best_yaw, coarse=False
            )
            aspect_after_post = self._compute_aspect_ratio(mask_after_post)
            error_after_post_direct = abs(aspect_after_post - gt_aspect)
            error_after_post_inverted = abs(aspect_after_post - gt_aspect_inv)
            error_after_post = min(error_after_post_direct, error_after_post_inverted)
            Image.fromarray(mask_after_post).save(output_dir / f"debug_step2_post_AFTER_radius{orientation_search_radius:.4f}_err{error_after_post:.4f}.png")

            print(f"  [DEBUG] Post-orientation radius adjustment impact:")
            print(f"    BEFORE: radius={radius_before_post:.4f}, aspect={aspect_before_post:.3f}, AR_error={error_before_post:.4f}")
            print(f"    AFTER:  radius={orientation_search_radius:.4f}, aspect={aspect_after_post:.3f}, AR_error={error_after_post:.4f}")
            print(f"    CHANGE: radius {'+' if orientation_search_radius > radius_before_post else ''}{(orientation_search_radius - radius_before_post):.4f}, "
                  f"AR_error {'+' if error_after_post > error_before_post else ''}{(error_after_post - error_before_post):.4f}")

        # STEP 3: Binary search for precise radius calibration (optional, disabled by default)
        if calib_config.binary_search_enabled:
            print(f"\n  Step 3: [Radius Calibration] PHASE 2: Precise radius calibration at matched orientation")
            radius, calibration_steps = self._calibrate_radius_binary_search(
                glb_path=glb_path,
                gt_mask=gt_mask_resized,
                initial_radius=orientation_search_radius,
                azimuth=0.0,
                elevation=best_elev,
                yaw=best_yaw,
                fov=calib_fov,
                calib_config=calib_config,
                calib_renderer=calib_renderer,
                output_dir=output_dir,
                label="  "
            )
            print(f"\n  Final calibrated radius: {radius:.4f} (from initial {initial_radius:.4f})")
        else:
            radius = orientation_search_radius
            print(f"\n  Step 3: Binary search disabled - using border-adjusted radius: {radius:.4f}")
            print(f"\n  Final calibrated radius: {radius:.4f} (from initial {initial_radius:.4f})")

        # Note: Visualization saving is handled inside _calibrate_radius_binary_search

        # Return calibrated pose (radius + orientation) for AR-based pipeline
        calibrated_pose = {
            'radius': radius,
            'yaw_deg': best_yaw,
            'elevation_deg': best_elev,
            'fov_deg': calib_fov,
            'azimuth_deg': 0.0,  # Always 0 for calibration
            'ar_error': best_score if method == "aspect_ratio" else None,
            'iou': best_iou if method == "aspect_ratio" else None,  # IoU from AR+IoU hybrid scoring
            'method': method
        }

        # For backward compatibility, also return just radius
        return radius, calibrated_pose

    def recalibrate_radius_at_pose(
        self,
        glb_path: Path,
        gt_mask: np.ndarray,
        pose_dict: dict,
        calib_config,
        output_dir: Path = None
    ) -> float:
        """Recalibrate radius at a final estimated pose (after refinement).

        This performs ONLY radius calibration, assuming all other pose parameters
        (azimuth, elevation, yaw, fov) are already known from pose estimation.

        Args:
            glb_path: Path to GLB file
            gt_mask: Ground truth mask (original resolution)
            pose_dict: Dictionary with keys: azimuth_deg, elevation_deg, obj_yaw_deg, fov_deg, radius
            calib_config: Calibration configuration
            output_dir: Optional directory for visualizations

        Returns:
            Recalibrated radius value
        """
        from PIL import Image

        print(f"\n[Final Radius Recalibration] Recalibrating radius at final estimated pose")

        # Create calibration renderer
        calib_res = calib_config.resolution
        calib_renderer = RealtimeRenderer(resolution=calib_res)

        # Resize GT mask to calibration resolution
        gt_mask_resized = np.array(
            Image.fromarray(gt_mask).resize((calib_res, calib_res), Image.Resampling.LANCZOS)
        )

        # Extract pose parameters
        azimuth = pose_dict.get('azimuth_deg', 0.0)
        elevation = pose_dict.get('elevation_deg', 0.0)
        yaw = pose_dict.get('obj_yaw_deg', 0.0)
        fov = pose_dict.get('fov_deg', calib_config.fov_deg)
        initial_radius = pose_dict.get('radius', 2.2)

        # STEP 1: Border safety check at final pose
        final_margin = calib_config.final_border_safety_margin_fraction
        print(f"  Step 1: Border safety check at final pose (margin={final_margin*100:.1f}%)")
        adjusted_radius, _ = self._ensure_radius_has_border(
            glb_path, initial_radius, yaw=yaw, elevation=elevation, fov=fov,
            calib_config=calib_config, calib_renderer=calib_renderer, label="    ",
            margin_fraction=final_margin
        )

        # STEP 2: Binary search for precise radius (optional, disabled by default)
        if calib_config.binary_search_enabled:
            print(f"  Step 2: Binary search for precise radius calibration")
            final_radius, _ = self._calibrate_radius_binary_search(
                glb_path=glb_path,
                gt_mask=gt_mask_resized,
                initial_radius=adjusted_radius,
                azimuth=azimuth,
                elevation=elevation,
                yaw=yaw,
                fov=fov,
                calib_config=calib_config,
                calib_renderer=calib_renderer,
                output_dir=output_dir,
                label="    "
            )
        else:
            final_radius = adjusted_radius
            print(f"  Step 2: Binary search disabled - using border-adjusted radius")

        print(f"  Final recalibrated radius: {final_radius:.4f} (from {initial_radius:.4f})")

        return final_radius

    def generate_spherical_sweep_poses(
        self,
        calibrated_radius: float
    ) -> List[PrerenderPose]:
        """Generate poses using spherical coordinate sweeps.

        Strategy:
        1. For each FOV value (from config):
           2. For each radius multiplier (from config):
              3. For each elevation level (from config):
                 4. Full 360° yaw sweep in configurable steps

        This provides systematic coverage of the viewing sphere around the object.

        Args:
            calibrated_radius: Radius from calibration step

        Returns:
            List of PrerenderPose instances
        """
        poses = []
        step = self.angular_step_deg

        # Use configurable radius multipliers (e.g., [0.75, 1.0, 1.75])
        radii = [calibrated_radius * mult for mult in self.radius_multipliers]

        # Use configurable elevation values (e.g., [0.0, 15.0, 30.0])
        elevations = self.elevation_values

        # Calculate total poses
        num_yaw_steps = int(360 / step)
        total_poses = len(radii) * len(elevations) * len(self.fov_values) * num_yaw_steps

        print(f"\n  [Library Generation]")
        print(f"    Radii multipliers: {self.radius_multipliers}")
        print(f"    Actual radii: {[f'{r:.3f}' for r in radii]}")
        print(f"    Elevations: {elevations} deg")
        print(f"    FOVs: {self.fov_values} deg")
        print(f"    Yaw: 360deg in {step}deg steps ({num_yaw_steps} steps)")
        print(f"    Total: {len(radii)}R x {len(elevations)}E x {len(self.fov_values)}FOV x {num_yaw_steps}Y = {total_poses} poses")

        # For each FOV value
        for fov in self.fov_values:
            # For each radius
            for radius in radii:
                # For each elevation
                for elevation in elevations:
                    # Full 360° yaw sweep in configured steps
                    for yaw in np.arange(0, 360, step):
                        poses.append(PrerenderPose(
                            azimuth_deg=0.0,  # Keep camera fixed, rotate object
                            elevation_deg=float(elevation),
                            radius=float(radius),
                            fov_deg=float(fov),
                            obj_yaw_deg=float(yaw)
                        ))

        return poses

    def render_library(
        self,
        glb_path: Path,
        poses: List[PrerenderPose],
        output_dir: Path
    ) -> List[Tuple[int, Path, PrerenderPose]]:
        """Render full library of poses using pyrender (fast, GPU-accelerated).

        CRITICAL OPTIMIZATION: Only renders masks (no RGB) for faster library generation.
        Edges are extracted from mask boundaries for matching.

        IMPORTANT: Uses RealtimeRenderer (pyrender), NOT Blender.
        Blender is only used for the final HQ render after pose estimation.

        Args:
            glb_path: Path to GLB file
            poses: List of poses to render
            output_dir: Output directory for renders

        Returns:
            List of (index, mask_path, pose) tuples
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        metadata_path = output_dir / "library_metadata.json"

        # Warmup render to compile OpenGL shaders BEFORE main loop
        print(f"  Warming up OpenGL renderer (compiling shaders)...", end=" ", flush=True)
        import time
        warmup_start = time.time()
        if poses:
            _ = self.renderer.render_mask(
                glb_path,
                azimuth_deg=poses[0].azimuth_deg,
                elevation_deg=poses[0].elevation_deg,
                radius=poses[0].radius,
                fov_deg=poses[0].fov_deg,
                obj_yaw_deg=poses[0].obj_yaw_deg,
                coarse=True
            )
        warmup_time = time.time() - warmup_start
        print(f"done ({warmup_time:.1f}s)")

        results = []
        metadata = []

        for idx, pose in enumerate(poses):
            # CRITICAL OPTIMIZATION: Render ONLY mask (no RGB for speed)
            mask = self.renderer.render_mask(
                glb_path,
                azimuth_deg=pose.azimuth_deg,
                elevation_deg=pose.elevation_deg,
                radius=pose.radius,
                fov_deg=pose.fov_deg,
                obj_yaw_deg=pose.obj_yaw_deg,
                coarse=True  # 128px, fast
            )

            # Save mask with minimal compression for speed
            mask_path = output_dir / f"lib_{idx:04d}_mask.png"
            Image.fromarray(mask).save(mask_path, compress_level=1, optimize=False)

            # OPTIONAL: Precompute edges for faster matching
            # Edges extracted from mask boundaries (not RGB)
            from vfscore.objective2.silhouette import extract_edges
            edges = extract_edges(mask)
            silh_path = output_dir / f"lib_{idx:04d}_silh.npz"
            np.savez_compressed(silh_path, mask=mask, edges=edges)

            results.append((idx, mask_path, pose))
            metadata.append({
                "index": idx,
                "mask_path": str(mask_path.name),
                "silh_path": str(silh_path.name),
                "pose": pose.to_dict()
            })

        # Save metadata
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)

        return results

    def generate_full_library(
        self,
        glb_path: Path,
        gt_mask: np.ndarray,
        output_dir: Path,
        initial_radius: float,
        calib_config  # RadiusCalibrationConfig
    ) -> Tuple[float, List[Tuple[int, Path, Path, PrerenderPose]]]:
        """Generate complete pre-render library.

        Pipeline:
        1. Calibrate radius to match GT area (with configurable precision)
        2. Generate systematic pose coverage
        3. Render all poses at 128px lightless
        4. Save metadata

        Args:
            glb_path: Path to GLB file
            gt_mask: Ground truth mask for radius calibration
            output_dir: Output directory
            initial_radius: Initial radius guess
            calib_config: RadiusCalibrationConfig with all calibration parameters

        Returns:
            (calibrated_radius, library_results)
        """
        # Stage 0: Radius calibration with improved accuracy
        calibrated_radius, calibrated_pose = self.calibrate_radius(
            glb_path, gt_mask,
            initial_radius=initial_radius,
            calib_config=calib_config,
            output_dir=output_dir  # Save calibration visualizations
        )

        # Stage 1: Generate poses (spherical sweep)
        poses = self.generate_spherical_sweep_poses(calibrated_radius)

        # Stage 2: Render library
        results = self.render_library(glb_path, poses, output_dir)

        # Save calibration info
        calib_info = {
            "calibrated_radius": float(calibrated_radius),
            "initial_radius": float(initial_radius),
            "num_poses": len(poses),
            "resolution": self.resolution,
            "angular_step_deg": self.angular_step_deg,
            "fov_values": self.fov_values
        }

        with open(output_dir / "calibration.json", 'w', encoding='utf-8') as f:
            json.dump(calib_info, f, indent=2)

        return calibrated_radius, results

    def select_poses_by_criterion(
        self,
        candidates: List[Tuple[float, float, float, float, float, np.ndarray]],  # (yaw, elev, iou, area, ar_error, mask)
        num_candidates: int,
        criterion: str,
        initial_top_fraction: float,
        step_fraction: float,
        gt_aspect: float,
        iou_ar_top_fraction: float = 0.20,
        label: str = ""
    ) -> List[Tuple[float, float, float, float, float, np.ndarray]]:
        """Select poses using specified criterion.

        Supports five selection modes:
        - "iou": Select by IoU (Intersection over Union) only
        - "area": Select by projected area only
        - "ar": Select by aspect ratio match only
        - "iou_ar": IoU + AR hybrid (best IoU in top N% with AR constraint)
        - "tri_criterion": Combined IoU + Area + AR (iterative intersection)

        Args:
            candidates: List of (yaw, elev, iou, area, ar_error, mask) tuples
            num_candidates: Number of candidates to select
            criterion: Selection criterion ("iou", "area", "ar", "iou_ar", "tri_criterion")
            initial_top_fraction: Initial top fraction for tri-criterion (e.g., 0.001 = 0.1%)
            step_fraction: Step to expand by for tri-criterion (e.g., 0.001)
            gt_aspect: GT aspect ratio for AR error calculation
            iou_ar_top_fraction: Top fraction for IoU+AR hybrid (e.g., 0.20 = top 20%)
            label: Label for logging

        Returns:
            List of selected candidate tuples, sorted by the criterion
        """
        if not candidates:
            return []

        # Single-criterion selection modes
        if criterion == "iou":
            print(f"{label}IoU-only selection: finding {num_candidates} candidates from {len(candidates)} poses")
            # Sort by IoU (higher is better)
            selected = sorted(candidates, key=lambda x: x[2], reverse=True)[:num_candidates]

        elif criterion == "area":
            print(f"{label}Area-only selection: finding {num_candidates} candidates from {len(candidates)} poses")
            # Sort by area (higher is better)
            selected = sorted(candidates, key=lambda x: x[3], reverse=True)[:num_candidates]

        elif criterion == "ar":
            print(f"{label}AR-only selection: finding {num_candidates} candidates from {len(candidates)} poses")
            # Sort by AR error (lower is better)
            selected = sorted(candidates, key=lambda x: x[4])[:num_candidates]

        elif criterion == "iou_ar":
            print(f"{label}IoU+AR hybrid selection: finding {num_candidates} candidates from {len(candidates)} poses")
            print(f"{label}  Using top {iou_ar_top_fraction*100:.1f}% fraction for both IoU and AR constraints")
            import sys
            sys.stdout.flush()

            # Sort candidates - WORKAROUND: Extract scalar values first to avoid numpy array corruption
            print(f"{label}  [DEBUG] Extracting scalar metrics from candidates (workaround for heap corruption)...")
            sys.stdout.flush()
            import gc

            # CRITICAL: Extract ALL data we need from candidates NOW, before any operations
            # Store both lightweight tuples for sorting AND full tuples for final result
            # This completely isolates us from the corrupted original candidates list
            candidates_light = []  # For sorting: (idx, yaw, elev, iou_val, area, ar_err)
            candidates_full = []   # For final result: (yaw, elev, iou_val, area, ar_err, mask)

            for idx, candidate_tuple in enumerate(candidates):
                yaw, elev, iou_val, area, ar_err, mask = candidate_tuple
                # Store lightweight version for sorting
                candidates_light.append((idx, yaw, elev, iou_val, area, ar_err))
                # Store full tuple (make defensive copy)
                candidates_full.append((yaw, elev, iou_val, area, ar_err, mask))

            # Immediately free the original candidates list to avoid any future access
            del candidates

            print(f"{label}  [DEBUG] Extracted {len(candidates_light)} candidates, freed original list")
            sys.stdout.flush()

            print(f"{label}  [DEBUG] Sorting by IoU...")
            sys.stdout.flush()
            by_iou = sorted(candidates_light, key=lambda x: x[3], reverse=True)  # x[3] = iou_val
            print(f"{label}  [DEBUG] Sorting by AR...")
            sys.stdout.flush()
            by_ar = sorted(candidates_light, key=lambda x: x[5])  # x[5] = ar_err

            # Get top N% from each metric
            num_top = max(1, int(len(candidates_light) * iou_ar_top_fraction))
            print(f"{label}  [DEBUG] Extracting top {num_top} candidates...")
            sys.stdout.flush()
            top_iou_indices = [x[0] for x in by_iou[:num_top]]
            top_ar_indices = [x[0] for x in by_ar[:num_top]]

            # Store AR values for threshold computation
            # Extract AR threshold IMMEDIATELY to avoid Cython memory corruption
            # Do NOT store in a list or do any operations before extracting the final value
            if len(by_ar) >= num_top and num_top > 0:
                # Get the worst AR in top N (last element after sorting ascending)
                ar_threshold_tuple = by_ar[num_top - 1]
                ar_threshold = float(ar_threshold_tuple[5])  # Extract immediately
                print(f"{label}  AR threshold (worst in top {num_top}): {ar_threshold:.4f}")
            else:
                ar_threshold = 999.0
                print(f"{label}  AR threshold (no candidates): {ar_threshold:.4f}")
            sys.stdout.flush()

            # Free lightweight lists AFTER we've extracted the threshold
            del by_iou, by_ar, candidates_light

            # Find best IoU candidates that have AR <= threshold
            # Use pre-extracted values from candidates_full
            print(f"{label}  [DEBUG] Filtering qualified candidates...")
            sys.stdout.flush()
            qualified_indices = []
            for idx in top_iou_indices:
                # Access AR error from safe copy (candidates_full[idx][4])
                if candidates_full[idx][4] <= ar_threshold:
                    qualified_indices.append(idx)

            print(f"{label}  Found {len(qualified_indices)} qualified candidates (IoU in top {num_top} AND AR <= {ar_threshold:.4f})")
            sys.stdout.flush()

            # Build final selected list from safe copies
            if qualified_indices:
                # Success: select best by IoU from qualified candidates
                # Sort qualified indices by IoU (descending)
                qualified_with_iou = [(idx, candidates_full[idx][2]) for idx in qualified_indices]  # (idx, iou)
                qualified_with_iou.sort(key=lambda x: x[1], reverse=True)
                selected_indices = [x[0] for x in qualified_with_iou[:num_candidates]]
                selected = [candidates_full[idx] for idx in selected_indices]
            else:
                # Fallback: no IoU candidate has good enough AR, pick best AR from top IoU candidates
                print(f"{label}  FALLBACK: No top IoU candidates qualified, selecting best AR from top {num_top} IoU candidates")
                sys.stdout.flush()
                # Sort top IoU indices by AR error (ascending)
                iou_with_ar = [(idx, candidates_full[idx][4]) for idx in top_iou_indices]  # (idx, ar_err)
                iou_with_ar.sort(key=lambda x: x[1])
                selected_indices = [x[0] for x in iou_with_ar[:num_candidates]]
                selected = [candidates_full[idx] for idx in selected_indices]

        elif criterion == "tri_criterion":
            print(f"{label}Tri-criterion selection: finding {num_candidates} candidates from {len(candidates)} poses")

            # Start with initial top fraction and expand until we find enough
            current_fraction = initial_top_fraction
            selected = []

            while len(selected) < num_candidates and current_fraction <= 1.0:
                # Calculate how many to take from each list
                num_to_check = max(1, int(len(candidates) * current_fraction))

                # Sort by each criterion
                by_iou = sorted(candidates, key=lambda x: x[2], reverse=True)  # Higher IoU is better
                by_area = sorted(candidates, key=lambda x: x[3], reverse=True)  # Higher area is better
                by_ar = sorted(candidates, key=lambda x: x[4])  # Lower AR error is better

                # Get sets of candidates in top N for each criterion
                top_iou_set = set((c[0], c[1]) for c in by_iou[:num_to_check])  # (yaw, elev) tuples
                top_area_set = set((c[0], c[1]) for c in by_area[:num_to_check])
                top_ar_set = set((c[0], c[1]) for c in by_ar[:num_to_check])

                # Find intersection: candidates that appear in all three top lists
                intersection = top_iou_set & top_area_set & top_ar_set

                if intersection:
                    # Get full candidate tuples for intersection
                    selected = [c for c in candidates if (c[0], c[1]) in intersection]

                    # Sort by priority: IoU (desc), then Area (desc), then AR (asc)
                    selected.sort(key=lambda x: (-x[2], -x[3], x[4]))

                    if len(selected) >= num_candidates:
                        break

                # Expand search
                current_fraction += step_fraction

            # Trim to requested number
            selected = selected[:num_candidates]

        else:
            raise ValueError(f"Unknown selection criterion: {criterion}. "
                           f"Must be 'iou', 'area', 'ar', 'iou_ar', or 'tri_criterion'")

        # Log final selection
        if selected:
            print(f"{label}  Selected {len(selected)} candidates:")
            for i, (yaw, elev, iou_val, area, ar_err, _) in enumerate(selected[:5]):  # Show top 5
                marker = " <- BEST" if i == 0 else ""
                print(f"{label}    {i+1}. yaw={yaw:5.1f}deg, elev={elev:4.1f}deg, "
                      f"IoU={iou_val:.3f}, area={area:.0f}px, AR_err={ar_err:.4f}{marker}")
            if len(selected) > 5:
                print(f"{label}    ... and {len(selected) - 5} more")
        else:
            if criterion == "tri_criterion":
                print(f"{label}  WARNING: Could not find any candidates satisfying all 3 criteria!")
            else:
                print(f"{label}  WARNING: No candidates found!")

        return selected
