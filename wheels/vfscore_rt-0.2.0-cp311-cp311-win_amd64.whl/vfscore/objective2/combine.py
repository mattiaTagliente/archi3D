"""Score combiner for pose-compensated LPIPS scoring."""


def _clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp value to [min_val, max_val] range."""
    if value < min_val:
        return min_val
    if value > max_val:
        return max_val
    return value


def combine_score(
    lpips_distance: float, pose_confidence: float, gamma: float, pose_compensation_c: float
) -> float:
    """Combine LPIPS distance and pose confidence into final 0-1 score.

    Uses pose-compensated distance formula that credits back appearance penalty
    when pose is uncertain, without allowing scores to exceed 1.

    Formula:
        slack = pose_compensation_c * (1 - pose_confidence**gamma)
        D_eff = max(0, lpips_distance - slack)
        final_score = 1 - D_eff

    Rationale:
    - When pose is perfect (confidence=1): slack=0, score = 1 - lpips (pure appearance)
    - When pose is poor: we allow up to pose_compensation_c of distance slack,
      recovering penalty likely due to pose error
    - Monotone and bounded to [0,1]
    - Avoids double punishment while staying conservative

    Args:
        lpips_distance: LPIPS perceptual distance in [0, 1] (0=identical, 1=very different)
        pose_confidence: Pose confidence (best IoU) in [0, 1] (1=perfect alignment)
        gamma: Pose confidence exponent (gamma > 0, typically 1.0)
        pose_compensation_c: Maximum slack allowed in [0, 1] (typically 0.5)

    Returns:
        Final score in [0, 1] (1=perfect match, 0=complete mismatch)
    """
    # Validate inputs using explicit clamp function
    lpips_dist = _clamp(lpips_distance, 0.0, 1.0)
    pose_conf = _clamp(pose_confidence, 0.0, 1.0)

    # Compute pose-related slack using pow() to avoid complex type inference
    import math
    pose_term = math.pow(pose_conf, gamma)
    slack = pose_compensation_c * (1.0 - pose_term)

    # Effective appearance distance after pose compensation
    temp_val = lpips_dist - slack
    if temp_val >= 0.0:
        d_eff = temp_val
    else:
        d_eff = 0.0

    # Final score (invert distance to get similarity score)
    final_score = 1.0 - d_eff

    # Clamp to [0, 1] for safety
    return _clamp(final_score, 0.0, 1.0)
