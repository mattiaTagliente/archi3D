"""Smart caching system for objective pipeline with dependency tracking."""

import hashlib
import json
import threading
from pathlib import Path
from typing import Any, Dict, Optional
from datetime import datetime


class CacheManager:
    """Manages cached artifacts with dependency tracking for objective pipeline.

    Provides intelligent caching with content-based validation:
    - Tracks input dependencies (files, parameters)
    - Validates caches using file hashes
    - Supports cache invalidation and forced regeneration
    - Thread-safe for future parallelization

    Cache entries include:
    - Artifact path and hash
    - Input dependencies (files with hashes, parameters)
    - Timestamp and config version
    """

    def __init__(self, output_dir: Path, enabled: bool = True):
        """Initialize cache manager.

        Args:
            output_dir: Item-specific output directory (e.g., outputs/objective/558736)
            enabled: Whether caching is enabled (False = always regenerate)
        """
        self.output_dir = Path(output_dir)
        self.enabled = enabled
        self.cache_metadata_path = self.output_dir / "cache_metadata.json"
        self._lock = threading.Lock()  # Thread-safe locking for metadata operations
        self._metadata = self._load_metadata()

    def _load_metadata(self) -> Dict:
        """Load cache metadata from disk.

        Returns:
            Cache metadata dictionary or empty dict if not found
        """
        if not self.enabled or not self.cache_metadata_path.exists():
            return {}

        try:
            with open(self.cache_metadata_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            # Corrupted metadata - start fresh
            return {}

    def _save_metadata(self):
        """Save cache metadata to disk (thread-safe)."""
        if not self.enabled:
            return

        with self._lock:  # Protect metadata writes from concurrent access
            self.output_dir.mkdir(parents=True, exist_ok=True)
            with open(self.cache_metadata_path, "w", encoding="utf-8") as f:
                json.dump(self._metadata, f, indent=2)

    @staticmethod
    def _compute_file_hash(file_path: Path) -> str:
        """Compute SHA256 hash of file.

        Args:
            file_path: Path to file

        Returns:
            Hex-encoded SHA256 hash
        """
        sha256 = hashlib.sha256()

        try:
            with open(file_path, "rb") as f:
                # Read in chunks to handle large files
                for chunk in iter(lambda: f.read(8192), b""):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except OSError:
            # File doesn't exist or can't be read
            return ""

    @staticmethod
    def _compute_dict_hash(data: Dict) -> str:
        """Compute deterministic hash of dictionary.

        Args:
            data: Dictionary to hash

        Returns:
            Hex-encoded SHA256 hash
        """
        # Sort keys for deterministic serialization
        json_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def is_cached(
        self,
        artifact_name: str,
        artifact_path: Optional[Path] = None,
        input_files: Optional[Dict[str, Path]] = None,
        input_params: Optional[Dict] = None,
        check_file_hashes: bool = True,
    ) -> bool:
        """Check if artifact is cached and valid.

        Validates cache by checking:
        1. Metadata exists for artifact
        2. Artifact file exists (if artifact_path provided)
        3. Input files exist and hashes match (if check_file_hashes=True)
        4. Input parameters match exactly

        Args:
            artifact_name: Unique name for this artifact (e.g., "hq_render", "lpips")
            artifact_path: Path to artifact file (for existence check)
            input_files: Dict of input files {name: path} to validate
            input_params: Dict of parameters to validate
            check_file_hashes: Whether to validate file hashes (slower but safer)

        Returns:
            True if cache is valid, False otherwise
        """
        if not self.enabled:
            return False

        # Check if metadata exists
        if artifact_name not in self._metadata:
            return False

        entry = self._metadata[artifact_name]

        # Check if artifact file exists
        if artifact_path is not None:
            if not artifact_path.exists():
                return False

            # Optionally validate artifact hash
            if check_file_hashes and "artifact_hash" in entry:
                current_hash = self._compute_file_hash(artifact_path)
                if current_hash != entry["artifact_hash"]:
                    return False

        # Validate input files
        if input_files is not None and "input_files" in entry:
            for name, path in input_files.items():
                if name not in entry["input_files"]:
                    return False

                # Check file exists
                if not path.exists():
                    return False

                # Check hash if enabled
                if check_file_hashes:
                    cached_hash = entry["input_files"][name].get("hash", "")
                    current_hash = self._compute_file_hash(path)
                    if current_hash != cached_hash:
                        return False

        # Validate input parameters (exact match)
        if input_params is not None and "input_params" in entry:
            cached_params = entry["input_params"]
            if self._compute_dict_hash(input_params) != self._compute_dict_hash(cached_params):
                return False

        return True

    def get_cached_path(self, artifact_name: str) -> Optional[Path]:
        """Get path to cached artifact.

        Args:
            artifact_name: Unique name for artifact

        Returns:
            Path to artifact or None if not cached
        """
        if not self.enabled or artifact_name not in self._metadata:
            return None

        entry = self._metadata[artifact_name]
        if "artifact_path" not in entry:
            return None

        path = self.output_dir / entry["artifact_path"]
        return path if path.exists() else None

    def get_cached_data(self, artifact_name: str) -> Optional[Any]:
        """Get cached data value (for non-file artifacts like LPIPS scores).

        Args:
            artifact_name: Unique name for artifact

        Returns:
            Cached data or None if not cached
        """
        if not self.enabled or artifact_name not in self._metadata:
            return None

        entry = self._metadata[artifact_name]
        return entry.get("data")

    def save_cache(
        self,
        artifact_name: str,
        artifact_path: Optional[Path] = None,
        artifact_data: Optional[Any] = None,
        input_files: Optional[Dict[str, Path]] = None,
        input_params: Optional[Dict] = None,
        compute_artifact_hash: bool = True,
    ):
        """Save artifact to cache with dependency metadata.

        Args:
            artifact_name: Unique name for this artifact
            artifact_path: Path to artifact file (will compute hash)
            artifact_data: Data to cache directly (for non-file artifacts)
            input_files: Dict of input files {name: path} to track
            input_params: Dict of parameters to track
            compute_artifact_hash: Whether to compute artifact file hash
        """
        if not self.enabled:
            return

        entry = {
            "timestamp": datetime.now().isoformat(),
        }

        # Store artifact info
        if artifact_path is not None:
            # Make path relative to output_dir for portability
            try:
                rel_path = artifact_path.relative_to(self.output_dir)
            except ValueError:
                # Path is outside output_dir, store absolute
                rel_path = artifact_path

            entry["artifact_path"] = str(rel_path)

            if compute_artifact_hash and artifact_path.exists():
                entry["artifact_hash"] = self._compute_file_hash(artifact_path)

        if artifact_data is not None:
            entry["data"] = artifact_data

        # Store input files with hashes
        if input_files is not None:
            entry["input_files"] = {}
            for name, path in input_files.items():
                entry["input_files"][name] = {
                    "path": str(path),
                    "hash": self._compute_file_hash(path) if path.exists() else "",
                }

        # Store input parameters
        if input_params is not None:
            entry["input_params"] = input_params

        # Update metadata
        self._metadata[artifact_name] = entry
        self._save_metadata()

    def invalidate(self, artifact_name: str):
        """Invalidate specific cache entry.

        Args:
            artifact_name: Name of artifact to invalidate
        """
        if artifact_name in self._metadata:
            del self._metadata[artifact_name]
            self._save_metadata()

    def invalidate_all(self):
        """Clear all cache entries (force regeneration)."""
        self._metadata = {}
        self._save_metadata()

    def get_stats(self) -> Dict[str, int]:
        """Get cache statistics.

        Returns:
            Dictionary with cache stats
        """
        return {
            "total_entries": len(self._metadata),
            "artifacts": list(self._metadata.keys()),
        }
