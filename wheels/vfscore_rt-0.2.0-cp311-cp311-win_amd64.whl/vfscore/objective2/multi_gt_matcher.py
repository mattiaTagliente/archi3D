"""Multi-GT matching against pre-rendered library.

Compares ALL ground truth images against ALL pre-rendered candidates to find
the best GT-candidate match pairs for initialization.
"""

from __future__ import annotations

import json
import numpy as np
import cv2
from pathlib import Path
from typing import List, Tuple, Dict
from dataclasses import dataclass
from PIL import Image

from vfscore.objective2.silhouette import iou, extract_mask, prepare_edges_and_dt, compute_chamfer


@dataclass
class MatchResult:
    """Result of matching a GT image against a library candidate."""
    gt_index: int  # Which GT image (0-based)
    lib_index: int  # Which library candidate
    iou: float  # Silhouette IoU
    edge_chamfer: float  # Mask edge chamfer distance
    combined_error: float  # Combined objective (lower is better)
    gt_path: Path
    lib_mask_path: Path

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "gt_index": self.gt_index,
            "lib_index": self.lib_index,
            "iou": float(self.iou),
            "edge_chamfer": float(self.edge_chamfer),
            "combined_error": float(self.combined_error),
            "gt_path": str(self.gt_path),
            "lib_mask_path": str(self.lib_mask_path)
        }


class MultiGTMatcher:
    """Matches multiple GT images against pre-rendered library."""

    def __init__(
        self,
        iou_weight: float = 1.0,
        edge_weight: float = 1.0,
        binarize_threshold: int = 16,
        erode_dilate_px: int = 1
    ):
        """Initialize matcher.

        Args:
            iou_weight: Weight for IoU term in objective
            edge_weight: Weight for edge chamfer term
            binarize_threshold: Threshold for mask binarization (0-255)
            erode_dilate_px: Morphological operation kernel size
        """
        self.iou_weight = iou_weight
        self.edge_weight = edge_weight
        self.binarize_threshold = binarize_threshold
        self.erode_dilate_px = erode_dilate_px

    def load_gt_images(
        self,
        gt_dir: Path
    ) -> List[Tuple[int, Path, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
        """Load all GT images with masks and edges.

        Args:
            gt_dir: Directory containing gt_1.png, gt_2.png, etc.

        Returns:
            List of (index, path, rgb, mask, edges, dt) tuples
        """
        gt_images = []
        idx = 1

        while True:
            gt_path = gt_dir / f"gt_{idx}.png"
            if not gt_path.exists():
                break

            # Load RGB
            gt_rgb = np.array(Image.open(gt_path).convert('RGB'))

            # Extract mask
            gt_mask = extract_mask(
                gt_path,
                threshold=self.binarize_threshold,
                erode_dilate_px=self.erode_dilate_px
            )

            # Prepare edges and distance transform
            gt_edges, gt_dt = prepare_edges_and_dt(gt_rgb)

            gt_images.append((idx - 1, gt_path, gt_rgb, gt_mask, gt_edges, gt_dt))
            idx += 1

        return gt_images

    def load_gt_images_from_metadata(
        self,
        gt_dir: Path,
        mode: str = "square",
        selected_only: bool = True
    ) -> List[Tuple[int, Path, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
        """Load GT images from preprocessing metadata.

        Args:
            gt_dir: Directory containing metadata.json and GT images
            mode: "square" (for pose estimation) or "exact" (for final scoring)
            selected_only: If True, load only the selected GT (if available)

        Returns:
            List of (index, path, rgb, mask, edges, dt) tuples
        """
        metadata_path = gt_dir / "metadata.json"
        if not metadata_path.exists():
            # Fallback to legacy mode
            return self.load_gt_images(gt_dir)

        with open(metadata_path, 'r', encoding='utf-8') as f:
            metadata = json.load(f)

        gt_images = []

        for gt_meta in metadata["gts"]:
            # Skip if selected_only and this GT is not selected
            if selected_only and not gt_meta.get("is_selected", False):
                continue

            idx = gt_meta["gt_index"]

            # Determine which version to load
            if mode == "square":
                rgb_path = gt_dir / gt_meta["square_path"]
                mask_path = gt_dir / gt_meta["mask_square_path"]
            elif mode == "exact":
                if "exact_path" not in gt_meta:
                    # Fallback to square if exact not available
                    rgb_path = gt_dir / gt_meta["square_path"]
                    mask_path = gt_dir / gt_meta["mask_square_path"]
                else:
                    rgb_path = gt_dir / gt_meta["exact_path"]
                    mask_path = gt_dir / gt_meta["mask_exact_path"]
            else:
                raise ValueError(f"Invalid mode: {mode}")

            if not rgb_path.exists():
                continue

            # Load RGB
            gt_rgb = np.array(Image.open(rgb_path).convert('RGB'))

            # Load mask (precomputed)
            if mask_path.exists():
                gt_mask = np.array(Image.open(mask_path).convert('L'))
            else:
                # Fallback: extract mask from RGB
                gt_mask = extract_mask(
                    rgb_path,
                    threshold=self.binarize_threshold,
                    erode_dilate_px=self.erode_dilate_px
                )

            # Prepare edges and distance transform
            gt_edges, gt_dt = prepare_edges_and_dt(gt_rgb)

            gt_images.append((idx, rgb_path, gt_rgb, gt_mask, gt_edges, gt_dt))

        return gt_images

    def load_library(
        self,
        library_dir: Path
    ) -> List[Tuple[int, Path, np.ndarray, np.ndarray, Dict]]:
        """Load pre-rendered library with masks and edges.

        CRITICAL OPTIMIZATION: Uses precomputed silhouettes (mask + edges)
        instead of loading RGB. Edges extracted from mask boundaries.

        Args:
            library_dir: Directory containing library renders and metadata

        Returns:
            List of (index, mask_path, mask, edges, pose_dict) tuples
        """
        metadata_path = library_dir / "library_metadata.json"
        with open(metadata_path, 'r', encoding='utf-8') as f:
            metadata = json.load(f)

        library = []

        for entry in metadata:
            idx = entry["index"]
            mask_path = library_dir / entry["mask_path"]
            silh_path_name = entry.get("silh_path")  # May not exist in old libraries
            pose_dict = entry["pose"]

            # CRITICAL OPTIMIZATION: Load precomputed silhouette if available
            if silh_path_name:
                silh_path = library_dir / silh_path_name
                if silh_path.exists():
                    # Fast path: Load precomputed mask + edges
                    silh_data = np.load(silh_path)
                    mask = silh_data['mask']
                    edges = silh_data['edges']
                else:
                    # Fallback: Load mask and extract edges
                    mask = np.array(Image.open(mask_path).convert('L'))
                    from vfscore.objective2.silhouette import extract_edges
                    edges = extract_edges(mask)
            else:
                # Old library format: Load mask and extract edges
                mask = np.array(Image.open(mask_path).convert('L'))
                from vfscore.objective2.silhouette import extract_edges
                edges = extract_edges(mask)

            # Note: GT is downsampled to 128x128 (library resolution) in match_all_pairs()

            library.append((idx, mask_path, mask, edges, pose_dict))

        return library

    def compute_match_score(
        self,
        gt_mask: np.ndarray,
        gt_edges: np.ndarray,
        gt_dt: np.ndarray,
        lib_mask: np.ndarray,
        lib_edges: np.ndarray
    ) -> Tuple[float, float, float]:
        """Compute match score between GT and library candidate.

        Args:
            gt_mask: GT mask (binary)
            gt_edges: GT edge map
            gt_dt: GT distance transform
            lib_mask: Library mask (binary)
            lib_edges: Library edge map

        Returns:
            (iou, edge_chamfer, combined_error)
        """
        # Ensure same size (downsample GT to library resolution for speed)
        if gt_mask.shape != lib_mask.shape:
            h, w = lib_mask.shape
            gt_mask_resized = cv2.resize(gt_mask, (w, h), interpolation=cv2.INTER_NEAREST)
            gt_edges_resized = cv2.resize(gt_edges, (w, h), interpolation=cv2.INTER_LINEAR)
            gt_dt_resized = cv2.resize(gt_dt, (w, h), interpolation=cv2.INTER_LINEAR)
        else:
            gt_mask_resized = gt_mask
            gt_edges_resized = gt_edges
            gt_dt_resized = gt_dt

        # Compute IoU
        iou_score = iou(gt_mask_resized, lib_mask)

        # Compute directional chamfer (GT edges to library edges)
        # Use precomputed DT from GT
        edge_chamfer = compute_chamfer(lib_edges, gt_dt_resized)

        # Combined error (lower is better)
        # IoU: higher is better → (1 - IoU) for error
        # Chamfer: already an error metric
        combined_error = self.iou_weight * (1.0 - iou_score) + self.edge_weight * edge_chamfer

        return iou_score, edge_chamfer, combined_error

    def match_all_pairs(
        self,
        gt_images: List[Tuple[int, Path, np.ndarray, np.ndarray, np.ndarray, np.ndarray]],
        library: List[Tuple[int, Path, np.ndarray, np.ndarray, Dict]],
        output_dir: Path,
        top_k: int = 10
    ) -> List[MatchResult]:
        """Match all GT images against all library candidates.

        Args:
            gt_images: List of GT images with masks and edges
            library: List of library renders with masks and edges
            output_dir: Output directory for results
            top_k: Number of top matches to return

        Returns:
            List of top_k MatchResult instances sorted by combined_error
        """
        all_matches = []

        for gt_idx, gt_path, gt_rgb, gt_mask, gt_edges, gt_dt in gt_images:
            for lib_idx, lib_mask_path, lib_mask, lib_edges, pose_dict in library:
                # Compute match score
                iou, edge_chamfer, combined_error = self.compute_match_score(
                    gt_mask, gt_edges, gt_dt, lib_mask, lib_edges
                )

                # Create match result
                match = MatchResult(
                    gt_index=gt_idx,
                    lib_index=lib_idx,
                    iou=iou,
                    edge_chamfer=edge_chamfer,
                    combined_error=combined_error,
                    gt_path=gt_path,
                    lib_mask_path=lib_mask_path
                )

                all_matches.append(match)

        # Sort by combined error (lower is better)
        all_matches.sort(key=lambda m: m.combined_error)

        # Keep top-k
        top_matches = all_matches[:top_k]

        # Save results
        matches_data = [m.to_dict() for m in top_matches]
        with open(output_dir / "top_matches.json", 'w', encoding='utf-8') as f:
            json.dump(matches_data, f, indent=2)

        # Save visualization for top 3
        self._visualize_top_matches(top_matches[:3], gt_images, library, output_dir)

        return top_matches

    def _visualize_top_matches(
        self,
        top_matches: List[MatchResult],
        gt_images: List[Tuple[int, Path, np.ndarray, np.ndarray, np.ndarray, np.ndarray]],
        library: List[Tuple[int, Path, np.ndarray, np.ndarray, Dict]],
        output_dir: Path
    ) -> None:
        """Create visualization of top matches.

        CRITICAL OPTIMIZATION: Visualizes mask overlays only (no RGB comparison).

        Args:
            top_matches: Top match results to visualize
            gt_images: GT images list
            library: Library list
            output_dir: Output directory
        """
        viz_dir = output_dir / "match_visualizations"
        viz_dir.mkdir(parents=True, exist_ok=True)

        for rank, match in enumerate(top_matches, 1):
            # Get GT and library images
            gt_data = [g for g in gt_images if g[0] == match.gt_index][0]
            lib_data = [l for l in library if l[0] == match.lib_index][0]

            _, _, gt_rgb, gt_mask, _, _ = gt_data
            _, _, lib_mask, _, pose_dict = lib_data

            # Resize library mask to GT resolution for visualization
            h, w = gt_rgb.shape[:2]
            lib_mask_resized = cv2.resize(lib_mask, (w, h), interpolation=cv2.INTER_NEAREST)

            # Create side-by-side: GT RGB vs mask overlay
            overlay = np.zeros((h, w, 3), dtype=np.uint8)
            overlay[:, :, 1] = gt_mask  # Green = GT
            overlay[:, :, 2] = lib_mask_resized  # Red = predicted
            # Overlap = Yellow (green + red)

            combined = np.hstack([gt_rgb, overlay])

            # Save combined visualization
            Image.fromarray(combined).save(viz_dir / f"rank{rank:02d}_comparison.png")

            # Save metadata
            with open(viz_dir / f"rank{rank:02d}_info.txt", 'w', encoding='utf-8') as f:
                f.write(f"Rank: {rank}\n")
                f.write(f"GT Index: {match.gt_index}\n")
                f.write(f"Library Index: {match.lib_index}\n")
                f.write(f"IoU: {match.iou:.4f}\n")
                f.write(f"Edge Chamfer: {match.edge_chamfer:.4f}\n")
                f.write(f"Combined Error: {match.combined_error:.4f}\n")
                f.write(f"\nPose:\n")
                for key, value in pose_dict.items():
                    f.write(f"  {key}: {value}\n")
