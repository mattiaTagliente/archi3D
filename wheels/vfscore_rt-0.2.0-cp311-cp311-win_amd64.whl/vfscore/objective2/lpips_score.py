"""LPIPS perceptual distance computation."""

import warnings
from pathlib import Path
from typing import List, Optional, Union

import lpips
import numpy as np
import torch
from PIL import Image
from torchvision import transforms

from vfscore.objective2.cache import CacheManager


def compute_lpips(
    img_a_path: Path,
    img_b_path: Path,
    model: str = "vgg",
    device: str = "auto",
    normalize: bool = True,
    background_rgb: Optional[list[int]] = None,
    debug_dir: Optional[Path] = None,
) -> float:
    """Compute LPIPS perceptual distance between two images.

    Uses lpips==0.1.4 with torch. Images are normalized to [0,1] before comparison.

    Args:
        img_a_path: Path to first image (e.g., GT image)
        img_b_path: Path to second image (e.g., HQ render)
        model: LPIPS model name ("vgg", "alex", or "squeeze")
        device: Device to use ("auto", "cuda", or "cpu")
        normalize: Whether to normalize inputs to [0,1]
        background_rgb: Optional background color [R, G, B] for compositing transparent images.
                       Defaults to black [0, 0, 0] if None.
        debug_dir: Optional directory to save the actual images used for comparison.

    Returns:
        LPIPS distance in [0, 1] (lower is better, 0=identical)
    """
    # Determine device
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load LPIPS model
    # Suppress torchvision deprecation warnings from lpips library internals
    # (lpips 0.1.4 uses old torchvision API - warnings are harmless)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*pretrained.*deprecated.*")
        warnings.filterwarnings("ignore", message=".*Arguments other than.*weights.*")

        try:
            loss_fn = lpips.LPIPS(net=model).to(device)
        except Exception as e:
            # Fallback to CPU if CUDA fails
            if device == "cuda":
                print(f"Warning: CUDA failed ({e}), falling back to CPU")
                device = "cpu"
                loss_fn = lpips.LPIPS(net=model).to(device)
            else:
                raise

    # Load images
    # CRITICAL: Load as RGBA first to check for transparency
    img_a = Image.open(img_a_path).convert("RGBA")
    img_b = Image.open(img_b_path).convert("RGBA")

    # Helper to composite over background
    def composite_over_bg(img: Image.Image, bg_color: list[int]) -> Image.Image:
        if img.mode != "RGBA":
            return img.convert("RGB")
        
        # Create background image
        bg = Image.new("RGB", img.size, tuple(bg_color))
        # Composite
        bg.paste(img, mask=img.split()[3])
        return bg

    # Use provided background or default to black
    bg_rgb = background_rgb if background_rgb is not None else [0, 0, 0]

    # Composite both images (GT should already be opaque, but safe to run)
    img_a = composite_over_bg(img_a, bg_rgb)
    img_b = composite_over_bg(img_b, bg_rgb)

    # Dimension matching: pad smaller image to match larger one
    # Both images should have longest side = 1024px after preprocessing/rendering
    # If dimensions differ, pad the smaller one with background color
    if img_a.size != img_b.size:
        # Find target dimensions (max width, max height)
        target_w = max(img_a.width, img_b.width)
        target_h = max(img_a.height, img_b.height)

        # Helper to pad image to target size
        def pad_to_size(img: Image.Image, target_size: tuple[int, int], bg_color: list[int]) -> Image.Image:
            if img.size == target_size:
                return img

            # Create canvas with background color
            canvas = Image.new("RGB", target_size, tuple(bg_color))

            # Calculate paste position (center)
            paste_x = (target_size[0] - img.width) // 2
            paste_y = (target_size[1] - img.height) // 2

            # Paste image
            canvas.paste(img, (paste_x, paste_y))
            return canvas

        # Pad images if needed
        if img_a.size != (target_w, target_h):
            print(f"  Padding GT image from {img_a.size} to ({target_w}, {target_h})")
            img_a = pad_to_size(img_a, (target_w, target_h), bg_rgb)
        if img_b.size != (target_w, target_h):
            print(f"  Padding HQ render from {img_b.size} to ({target_w}, {target_h})")
            img_b = pad_to_size(img_b, (target_w, target_h), bg_rgb)

    # Save debug images if requested
    if debug_dir is not None:
        try:
            debug_dir.mkdir(parents=True, exist_ok=True)
            img_a.save(debug_dir / "lpips_input_a_gt.png")
            img_b.save(debug_dir / "lpips_input_b_render.png")
        except Exception as e:
            print(f"[WARNING] Failed to save LPIPS debug images: {e}")

    # Convert to tensors and normalize to [-1, 1] (LPIPS expects this range)
    transform = transforms.Compose(
        [
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
        ]
    )

    tensor_a = transform(img_a).unsqueeze(0).to(device)
    tensor_b = transform(img_b).unsqueeze(0).to(device)

    # Compute LPIPS distance
    with torch.no_grad():
        distance = loss_fn(tensor_a, tensor_b)

    # Convert to float and clamp to [0, 1]
    distance_value = float(distance.item())
    return max(0.0, min(1.0, distance_value))


def compute_lpips_batch(
    gt_image: Union[Path, Image.Image, np.ndarray],
    candidate_images: List[Union[Path, Image.Image, np.ndarray]],
    model: str = "alex",
    device: str = "auto",
    background_rgb: Optional[list[int]] = None,
) -> List[float]:
    """Compute LPIPS perceptual distance between GT and multiple candidates in a single batch.

    This is more efficient than calling compute_lpips() repeatedly when scoring multiple
    candidate poses, as it processes all candidates in a single forward pass through the
    LPIPS network.

    Args:
        gt_image: Ground truth image (Path, PIL Image, or numpy array [H, W, 3] RGB uint8)
        candidate_images: List of N candidate images (same format as gt_image)
        model: LPIPS model name ("alex", "vgg", or "squeeze"). Default "alex" for speed.
        device: Device to use ("auto", "cuda", or "cpu")
        background_rgb: Optional background color [R, G, B] for compositing transparent images.
                       Defaults to black [0, 0, 0] if None.

    Returns:
        List of N LPIPS distances in [0, 1] (lower is better, 0=identical)

    Note:
        All images are normalized to [-1, 1] as required by LPIPS.
        If dimensions differ, smaller images are center-padded to match the largest.
        Uses lpips=True (default, adds linear calibration on top of network features).
    """
    if not candidate_images:
        return []

    # Determine device
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load LPIPS model with lpips=True (default, recommended for forward scoring)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*pretrained.*deprecated.*")
        warnings.filterwarnings("ignore", message=".*Arguments other than.*weights.*")

        try:
            loss_fn = lpips.LPIPS(net=model, lpips=True).to(device)
        except Exception as e:
            if device == "cuda":
                print(f"Warning: CUDA failed ({e}), falling back to CPU")
                device = "cpu"
                loss_fn = lpips.LPIPS(net=model, lpips=True).to(device)
            else:
                raise

    # Helper to load and prepare image
    def load_image(img: Union[Path, Image.Image, np.ndarray]) -> Image.Image:
        if isinstance(img, Path):
            return Image.open(img).convert("RGBA")
        elif isinstance(img, np.ndarray):
            # Assume RGB uint8 [H, W, 3]
            if img.shape[2] == 3:
                return Image.fromarray(img, mode="RGB").convert("RGBA")
            elif img.shape[2] == 4:
                return Image.fromarray(img, mode="RGBA")
            else:
                raise ValueError(f"Unsupported array shape: {img.shape}")
        elif isinstance(img, Image.Image):
            return img.convert("RGBA")
        else:
            raise TypeError(f"Unsupported image type: {type(img)}")

    # Helper to composite over background
    def composite_over_bg(img: Image.Image, bg_color: list[int]) -> Image.Image:
        if img.mode != "RGBA":
            return img.convert("RGB")

        bg = Image.new("RGB", img.size, tuple(bg_color))
        bg.paste(img, mask=img.split()[3])
        return bg

    # Use provided background or default to black
    bg_rgb = background_rgb if background_rgb is not None else [0, 0, 0]

    # Load and composite GT image
    gt_pil = load_image(gt_image)
    gt_pil = composite_over_bg(gt_pil, bg_rgb)

    # Load and composite all candidate images
    candidate_pils = []
    for cand in candidate_images:
        cand_pil = load_image(cand)
        cand_pil = composite_over_bg(cand_pil, bg_rgb)
        candidate_pils.append(cand_pil)

    # Find maximum dimensions across all images
    all_images = [gt_pil] + candidate_pils
    max_w = max(img.width for img in all_images)
    max_h = max(img.height for img in all_images)

    # Helper to pad image to target size (center padding)
    def pad_to_size(img: Image.Image, target_size: tuple[int, int], bg_color: list[int]) -> Image.Image:
        if img.size == target_size:
            return img

        canvas = Image.new("RGB", target_size, tuple(bg_color))
        paste_x = (target_size[0] - img.width) // 2
        paste_y = (target_size[1] - img.height) // 2
        canvas.paste(img, (paste_x, paste_y))
        return canvas

    # Pad GT to max dimensions
    gt_pil = pad_to_size(gt_pil, (max_w, max_h), bg_rgb)

    # Pad all candidates to max dimensions
    candidate_pils = [pad_to_size(cand, (max_w, max_h), bg_rgb) for cand in candidate_pils]

    # Transform to normalize to [-1, 1] (LPIPS expects this range)
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
    ])

    # Convert GT to tensor [1, 3, H, W]
    gt_tensor = transform(gt_pil).unsqueeze(0).to(device)

    # Convert all candidates to tensor [N, 3, H, W]
    candidate_tensors = torch.stack([transform(cand) for cand in candidate_pils]).to(device)

    # Replicate GT tensor to match batch size [N, 3, H, W]
    N = len(candidate_images)
    gt_batch = gt_tensor.repeat(N, 1, 1, 1)

    # Compute LPIPS distances in a single batch
    with torch.no_grad():
        distances = loss_fn(gt_batch, candidate_tensors)

    # Convert to list of floats and clamp to [0, 1]
    distance_list = [max(0.0, min(1.0, float(d.item()))) for d in distances]
    return distance_list


def compute_lpips_cached(
    img_a_path: Path,
    img_b_path: Path,
    model: str = "vgg",
    device: str = "auto",
    normalize: bool = True,
    background_rgb: Optional[list[int]] = None,
    debug_dir: Optional[Path] = None,
    cache_manager: Optional[CacheManager] = None,
) -> float:
    """Compute LPIPS perceptual distance with caching support.

    Checks cache before computation. If valid cached result exists with matching
    inputs and parameters, returns immediately. Otherwise computes and saves to cache.

    Args:
        img_a_path: Path to first image (e.g., GT image)
        img_b_path: Path to second image (e.g., HQ render)
        model: LPIPS model name ("vgg", "alex", or "squeeze")
        device: Device to use ("auto", "cuda", or "cpu")
        normalize: Whether to normalize inputs to [0,1]
        background_rgb: Optional background color [R, G, B] for compositing.
        debug_dir: Optional directory to save debug images.
        cache_manager: Optional cache manager (if None, no caching)

    Returns:
        LPIPS distance in [0, 1] (lower is better, 0=identical)
    """
    # Define cache artifact name
    artifact_name = "lpips_distance"

    # Check cache if manager provided
    if cache_manager is not None:
        input_files = {"img_a": img_a_path, "img_b": img_b_path}
        input_params = {
            "model": model,
            "normalize": normalize,
            "background_rgb": background_rgb,
        }

        if cache_manager.is_cached(
            artifact_name=artifact_name,
            artifact_path=None,  # This is a data value, not a file
            input_files=input_files,
            input_params=input_params,
            check_file_hashes=True,  # Check hashes since images can change
        ):
            # Cache hit - return cached value
            cached_value = cache_manager.get_cached_data(artifact_name)
            if cached_value is not None:
                # Even on cache hit, we might want to save debug images if they don't exist
                if debug_dir is not None and not (debug_dir / "lpips_input_a_gt.png").exists():
                     # Re-run compute just to save images (a bit wasteful but safe)
                     # Or better: just skip saving if cached. Let's skip for now to avoid re-compute.
                     pass
                return float(cached_value)

    # Cache miss or no cache manager - compute
    distance = compute_lpips(img_a_path, img_b_path, model, device, normalize, background_rgb, debug_dir)

    # Save to cache if cache manager provided
    if cache_manager is not None:
        cache_manager.save_cache(
            artifact_name=artifact_name,
            artifact_path=None,
            artifact_data=distance,
            input_files={"img_a": img_a_path, "img_b": img_b_path},
            input_params={
                "model": model,
                "normalize": normalize,
                "background_rgb": background_rgb,
            },
            compute_artifact_hash=False,  # No artifact file to hash
        )

    return distance

