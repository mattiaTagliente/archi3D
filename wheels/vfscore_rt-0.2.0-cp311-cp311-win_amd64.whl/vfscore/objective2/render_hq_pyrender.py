"""High-quality RGB rendering using pyrender only.

This module replaces the Blender-based HQ render with a pyrender-based
implementation to keep the entire objective2 pipeline on a single
renderer. It uses the same RealtimeRenderer used for pose search, but
at a higher resolution and with original GLB materials and lighting.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

from PIL import Image
import cv2

from vfscore.config import Config
from vfscore.objective2.cache import CacheManager
from vfscore.objective2.render_realtime import RealtimeRenderer


def render_hq_pyrender(
    glb_path: Path,
    params: Dict[str, float],
    out_path: Path,
    config: Config,
) -> bool:
    """Render high-quality RGB image using pyrender.

    This uses the same normalization and camera conventions as the
    realtime optimizer and library generation, ensuring that the pose
    seen by LPIPS is exactly the one used during optimization.

    Args:
        glb_path: Path to GLB file.
        params: Camera/object parameters dict with keys:
            - fov_deg: Field of view (degrees)
            - azimuth_deg: Camera azimuth (degrees)
            - elevation_deg: Camera elevation (degrees)
            - radius: Camera distance from origin
            - obj_yaw_deg: Object rotation about Z axis (degrees)
        out_path: Output PNG path.
        config: VFScore configuration.

    Returns:
        True if the render was created successfully, False otherwise.
    """
    fov_deg = float(params.get("fov_deg", 42.0))
    azimuth_deg = float(params.get("azimuth_deg", 45.0))
    elevation_deg = float(params.get("elevation_deg", 35.0))
    radius = float(params.get("radius", 2.2))
    obj_yaw_deg = float(params.get("obj_yaw_deg", 0.0))

    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Try rendering at the configured HQ resolution, with graceful fallbacks
    # if the GPU/GL context cannot handle large offscreen buffers.
    desired_res = int(config.objective.hq_resolution)
    fallback_resolutions = [desired_res]

    # Avoid duplicate entries and ensure we always have a small safe size.
    if desired_res != 512:
        fallback_resolutions.append(512)
    if desired_res != 256:
        fallback_resolutions.append(256)

    rgb = None
    mask = None
    for res in fallback_resolutions:
        try:
            renderer = RealtimeRenderer(resolution=res)
            # Render RGB (lit or unlit based on config, but usually lit for HQ)
            rgb = renderer.render_rgb(
                glb_path=glb_path,
                azimuth_deg=azimuth_deg,
                elevation_deg=elevation_deg,
                radius=radius,
                fov_deg=fov_deg,
                obj_yaw_deg=obj_yaw_deg,
                fast=False,
                coarse=False,
                unlit=False,
            )
            # Render Mask (for alpha channel)
            mask = renderer.render_mask(
                glb_path=glb_path,
                azimuth_deg=azimuth_deg,
                elevation_deg=elevation_deg,
                radius=radius,
                fov_deg=fov_deg,
                obj_yaw_deg=obj_yaw_deg,
                fast=False,
                coarse=False,
            )
            break
        except Exception as exc:  # pylint: disable=broad-except
            print(f"[ERROR] render_hq_pyrender: pyrender failed at {res}px - {exc!r}")
            rgb = None
            mask = None

    if rgb is None or mask is None:
        return False

    try:
        # Combine RGB and Mask to create RGBA
        # Mask is [H, W] with 0 or 255. RGB is [H, W, 3].
        import numpy as np
        if mask.shape != rgb.shape[:2]:
            # Should not happen if both rendered at same res, but safety check
            mask = cv2.resize(mask, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_NEAREST)
        
        # Create RGBA
        rgba = np.dstack((rgb, mask))
        
        Image.fromarray(rgba).save(out_path)
    except Exception as exc:  # pylint: disable=broad-except
        print(f"[ERROR] render_hq_pyrender: failed to save PNG - {exc}")
        return False

    return True


def render_hq_pyrender_exact_crop(
    glb_path: Path,
    params: Dict[str, float],
    out_path: Path,
    target_dimensions: tuple[int, int],
    max_dimension: int = 1024,
    border_safety_margin_fraction: float = 0.02,
    edge_threshold: int = 64,
) -> bool:
    """Render high-quality RGB image with exact crop (scale longest side to max_dimension).

    Strategy matches GT preprocessing:
    1. Render square at high resolution
    2. Crop to object bounding box with border safety margin
    3. Scale so longest side = max_dimension (preserving aspect ratio)
    4. Pad to match target_dimensions (GT dimensions) with transparent pixels

    Uses the same border safety logic as radius calibration to ensure proper
    transparent border around the object. Final image is padded to exactly match
    GT dimensions, avoiding padding during LPIPS comparison.

    Args:
        glb_path: Path to GLB file.
        params: Camera/object parameters dict.
        out_path: Output PNG path.
        target_dimensions: Target GT dimensions (width, height) - output will be padded to match these exactly.
        max_dimension: Maximum dimension (longest side will be scaled to this before padding).
        border_safety_margin_fraction: Required border as fraction of image size (e.g., 0.02 = 2%).
        edge_threshold: Threshold for opaque pixels (0-255, matches GT preprocessing).

    Returns:
        True if the render was created successfully, False otherwise.
    """
    fov_deg = float(params.get("fov_deg", 42.0))
    azimuth_deg = float(params.get("azimuth_deg", 45.0))
    elevation_deg = float(params.get("elevation_deg", 35.0))
    radius = float(params.get("radius", 2.2))
    obj_yaw_deg = float(params.get("obj_yaw_deg", 0.0))

    out_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        # Render at max_dimension (square)
        renderer = RealtimeRenderer(resolution=max_dimension)

        # Render RGB
        rgb = renderer.render_rgb(
            glb_path=glb_path,
            azimuth_deg=azimuth_deg,
            elevation_deg=elevation_deg,
            radius=radius,
            fov_deg=fov_deg,
            obj_yaw_deg=obj_yaw_deg,
            fast=False,
            coarse=False,
            unlit=False,
        )

        # Render Mask
        mask = renderer.render_mask(
            glb_path=glb_path,
            azimuth_deg=azimuth_deg,
            elevation_deg=elevation_deg,
            radius=radius,
            fov_deg=fov_deg,
            obj_yaw_deg=obj_yaw_deg,
            fast=False,
            coarse=False,
        )

        # Crop to object bounding box with border safety margin (matching GT preprocessing)
        import numpy as np

        # Find opaque pixels (using edge_threshold to ignore anti-aliased edges)
        opaque_coords = np.argwhere(mask > edge_threshold)
        if len(opaque_coords) == 0:
            # No object - save black image
            rgba = np.zeros((max_dimension, max_dimension, 4), dtype=np.uint8)
            Image.fromarray(rgba).save(out_path)
            return True

        # Get tight bounding box around opaque pixels
        y_min, x_min = opaque_coords.min(axis=0)
        y_max, x_max = opaque_coords.max(axis=0)

        # Add border safety margin (calculated as fraction of image size, matching radius calibration)
        h, w = mask.shape
        border_px = int(np.ceil(min(h, w) * border_safety_margin_fraction))

        y_min = max(0, y_min - border_px)
        x_min = max(0, x_min - border_px)
        y_max = min(h, y_max + border_px + 1)  # +1 to include the last pixel
        x_max = min(w, x_max + border_px + 1)

        # Crop to bbox (y_max and x_max already include +1 from line 215-216)
        rgb_cropped = rgb[y_min:y_max, x_min:x_max]
        mask_cropped = mask[y_min:y_max, x_min:x_max]

        # Scale cropped render to match GT dimensions (bounded by max_dimension)
        # This ensures the render fills the GT frame like the GT preprocessing does,
        # eliminating the transparent padding that causes black borders.
        target_w, target_h = target_dimensions
        h, w = rgb_cropped.shape[:2]

        # Compute scale factor to fill GT dimensions while respecting max_dimension
        # target_max = largest allowed dimension (min of max_dimension and GT's longest side)
        target_max = min(max_dimension, max(target_w, target_h))

        # Scale to fit within both GT dimensions and max_dimension constraint
        # Use the smallest scale that fits both constraints
        scale = min(target_w / w, target_h / h, target_max / max(h, w))

        new_w = int(round(w * scale))
        new_h = int(round(h * scale))

        # Resize RGB with Lanczos (high quality), mask with nearest (preserve binary edges)
        rgb_scaled = cv2.resize(rgb_cropped, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
        mask_scaled = cv2.resize(mask_cropped, (new_w, new_h), interpolation=cv2.INTER_NEAREST)

        # Zero RGB where mask is 0 (clean up any artifacts at transparent edges)
        rgb_scaled[mask_scaled == 0] = 0

        # Check if dimensions match (may differ by 1px due to rounding)
        if (new_h, new_w) != (target_h, target_w):
            # Only pad if there's a small mismatch (should be at most 1-2px from rounding)
            if abs(new_h - target_h) <= 2 and abs(new_w - target_w) <= 2:
                # Create canvas with transparent background
                rgba_padded = np.zeros((target_h, target_w, 4), dtype=np.uint8)

                # Calculate paste position (center for small adjustments)
                paste_y = (target_h - new_h) // 2
                paste_x = (target_w - new_w) // 2

                # Paste scaled RGB and mask
                rgba_padded[paste_y:paste_y+new_h, paste_x:paste_x+new_w, :3] = rgb_scaled
                rgba_padded[paste_y:paste_y+new_h, paste_x:paste_x+new_w, 3] = mask_scaled

                rgba = rgba_padded
            else:
                # Larger mismatch - force resize to exact dimensions (shouldn't happen normally)
                rgb_exact = cv2.resize(rgb_scaled, (target_w, target_h), interpolation=cv2.INTER_LANCZOS4)
                mask_exact = cv2.resize(mask_scaled, (target_w, target_h), interpolation=cv2.INTER_NEAREST)
                rgb_exact[mask_exact == 0] = 0
                rgba = np.dstack((rgb_exact, mask_exact))
        else:
            # Dimensions match exactly - combine RGB and mask
            rgba = np.dstack((rgb_scaled, mask_scaled))

        Image.fromarray(rgba).save(out_path)
        return True

    except Exception as exc:  # pylint: disable=broad-except
        print(f"[ERROR] render_hq_pyrender_exact_crop: failed - {exc}")
        return False


def render_hq_pyrender_cached(
    glb_path: Path,
    params: Dict[str, float],
    out_path: Path,
    config: Config,
    cache_manager: Optional[CacheManager] = None,
    exact_crop_dimensions: Optional[tuple[int, int]] = None,
) -> bool:
    """Render high-quality RGB image with optional caching (pyrender-only).

    Args:
        glb_path: Path to GLB file.
        params: Camera/object parameters.
        out_path: Output PNG path.
        config: VFScore configuration.
        cache_manager: Optional cache manager (if None, no caching).
        exact_crop_dimensions: If provided, render at these exact (w, h) dimensions.

    Returns:
        True if successful (from cache or fresh render), False otherwise.
    """
    artifact_name = f"hq_render_pyrender_{out_path.stem}"

    if cache_manager is not None:
        input_files = {"glb": glb_path}
        input_params = {
            "params": params,
            "resolution": config.objective.hq_resolution,
            "engine": "PYRENDER",
            "exact_crop_dimensions": exact_crop_dimensions,
            "border_safety_margin_fraction": config.preprocess.border_safety_margin_fraction,
            "edge_threshold": config.preprocess.edge_threshold,
        }

        if cache_manager.is_cached(
            artifact_name=artifact_name,
            artifact_path=out_path,
            input_files=input_files,
            input_params=input_params,
            check_file_hashes=False,
        ):
            return True

    # Use exact crop rendering if dimensions provided
    if exact_crop_dimensions is not None:
        success = render_hq_pyrender_exact_crop(
            glb_path,
            params,
            out_path,
            exact_crop_dimensions,
            max_dimension=config.objective.hq_resolution,
            border_safety_margin_fraction=config.preprocess.border_safety_margin_fraction,
            edge_threshold=config.preprocess.edge_threshold
        )
    else:
        success = render_hq_pyrender(glb_path, params, out_path, config)

    if success and cache_manager is not None:
        cache_manager.save_cache(
            artifact_name=artifact_name,
            artifact_path=out_path,
            input_files={"glb": glb_path},
            input_params={
                "params": params,
                "resolution": config.objective.hq_resolution,
                "engine": "PYRENDER",
                "exact_crop_dimensions": exact_crop_dimensions,
                "border_safety_margin_fraction": config.preprocess.border_safety_margin_fraction,
                "edge_threshold": config.preprocess.edge_threshold,
            },
            compute_artifact_hash=True,
        )

    return success
