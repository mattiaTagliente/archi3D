"""High-quality Cycles rendering at best pose."""

import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Optional

from vfscore.config import Config
from vfscore.objective2.cache import CacheManager
from vfscore.objective2.render_realtime import RealtimeRenderer

# Calibrated Blender intrinsics (from Rodin 353489 validation):
#   best_iou ~ 0.606 with:
#       fov_scale = 1.04  (base FOV 50 -> 52 deg)
#       shift_x   = -0.03
#       shift_y   = -0.015
# These are treated as global Blender-vs-pyrender intrinsics for now.
BLENDER_FOV_SCALE: float = 1.04
BLENDER_PRINCIPAL_SHIFT_X: float = -0.03
BLENDER_PRINCIPAL_SHIFT_Y: float = -0.015


def render_hq(
    glb_path: Path, params: Dict[str, float], out_path: Path, config: Config
) -> bool:
    """Render high-quality image using Blender Cycles at specified pose.

    Args:
        glb_path: Path to GLB file
        params: Camera/object parameters dict with keys:
            - fov_deg: Field of view (degrees)
            - azimuth_deg: Camera azimuth (degrees)
            - elevation_deg: Camera elevation (degrees)
            - radius: Camera distance from origin
            - obj_yaw_deg: Object rotation about Z axis (degrees)
        out_path: Output PNG path
        config: VFScore configuration

    Returns:
        True if successful, False otherwise
    """
    # Extract parameters
    fov_deg = params.get("fov_deg", 42.0)
    azimuth_deg = params.get("azimuth_deg", 45.0)
    elevation_deg = params.get("elevation_deg", 35.0)
    radius = params.get("radius", 2.2)
    obj_yaw_deg = params.get("obj_yaw_deg", 0.0)

    # Ensure output directory exists
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Generate Blender script
    script = _generate_hq_render_script(
        glb_path,
        out_path,
        fov_deg,
        azimuth_deg,
        elevation_deg,
        radius,
        obj_yaw_deg,
        config,
    )

    # Write script to temporary file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        script_path = Path(f.name)
        f.write(script)

    try:
        # Run Blender in background mode
        cmd = [
            str(config.paths.blender_exe),
            "--background",
            "--python",
            str(script_path),
        ]

        result = subprocess.run(
            cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=600, check=False
        )

        # Check for errors
        if result.returncode != 0:
            print(f"Blender HQ render failed with code {result.returncode}")
            print(f"Stderr: {result.stderr}")
            print(f"Stdout: {result.stdout}")
            return False

        # Check if output was created
        if not out_path.exists():
            print(f"HQ render output not created: {out_path}")
            print(f"Blender stdout: {result.stdout}")
            print(f"Blender stderr: {result.stderr}")
            return False

        return True

    except subprocess.TimeoutExpired:
        print("Blender HQ render timed out")
        return False
    except Exception as e:
        print(f"HQ render error: {e}")
        return False
    finally:
        # Clean up script file
        if script_path.exists():
            script_path.unlink()


def _generate_hq_render_script(
    glb_path: Path,
    output_path: Path,
    fov_deg: float,
    azimuth_deg: float,
    elevation_deg: float,
    radius: float,
    obj_yaw_deg: float,
    config: Config,
) -> str:
    """Generate Blender Python script for HQ Cycles rendering."""

    render_cfg = config.render
    resolution = config.objective.hq_resolution

    # Correct the denoiser name
    if render_cfg.denoiser == "OIDN":
        denoiser = "OPENIMAGEDENOISE"
    else:
        denoiser = render_cfg.denoiser

    # Convert to absolute paths to avoid Blender working directory issues
    glb_path_abs = glb_path.resolve()
    output_path_abs = output_path.resolve()

    # Reuse EXACT pyrender normalization and camera pose used by objective2
    renderer = RealtimeRenderer()
    norm_meta = renderer.get_normalization_metadata(glb_path)
    camera_pose_matrix = renderer.get_camera_pose(azimuth_deg, elevation_deg, radius)

    centroid_tuple = tuple(float(c) for c in norm_meta.get("centroid_before_translation", (0.0, 0.0, 0.0)))
    scale_factor = float(norm_meta.get("scale_factor", 1.0))
    cam_pose_tuple = tuple(tuple(float(v) for v in row) for row in camera_pose_matrix.tolist())

    script = f'''
import bpy
import math
import sys
from pathlib import Path
from mathutils import Vector, Matrix

# Clear scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Import GLB
glb_path = r"{glb_path_abs}"
bpy.ops.import_scene.gltf(filepath=glb_path)

# Get imported objects
imported_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']

if not imported_objects:
    print("ERROR: No mesh objects imported from GLB")
    sys.exit(1)

# Join all meshes
if len(imported_objects) > 1:
    bpy.context.view_layer.objects.active = imported_objects[0]
    bpy.ops.object.select_all(action='DESELECT')
    for obj in imported_objects:
        obj.select_set(True)
    bpy.ops.object.join()

obj = bpy.context.active_object

# Apply import transforms so mesh data is in world space
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# Apply EXACT pyrender normalization (centroid + scale)
centroid = Vector({centroid_tuple})
mesh = obj.data
mesh.transform(Matrix.Translation(-centroid))
mesh.update()
obj.location = (0.0, 0.0, 0.0)

norm_scale = {scale_factor}
obj.scale = (norm_scale, norm_scale, norm_scale)
bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

# Apply yaw rotation (object rotation about Z-axis)
obj.rotation_euler = (0, 0, math.radians({obj_yaw_deg}))

# Setup camera with VERTICAL FOV to match pyrender and principal point alignment
cam_data = bpy.data.cameras.new(name='Camera')
cam_data.lens_unit = 'FOV'
cam_data.sensor_fit = 'VERTICAL'  # CRITICAL: Match pyrender's vertical FOV
cam_data.sensor_width = 24.0
cam_data.sensor_height = 24.0
cam_data.angle_y = math.radians({fov_deg} * {BLENDER_FOV_SCALE})  # Calibrated vertical FOV
cam_data.shift_x = {BLENDER_PRINCIPAL_SHIFT_X}
cam_data.shift_y = {BLENDER_PRINCIPAL_SHIFT_Y}

cam_obj = bpy.data.objects.new('Camera', cam_data)
bpy.context.scene.collection.objects.link(cam_obj)

cam_matrix = Matrix({cam_pose_tuple})
cam_obj.matrix_world = cam_matrix

bpy.context.scene.camera = cam_obj

# Setup HDRI lighting
world = bpy.context.scene.world
world.use_nodes = True
nodes = world.node_tree.nodes
links = world.node_tree.links

nodes.clear()

node_env = nodes.new('ShaderNodeTexEnvironment')
node_env.image = bpy.data.images.load(r"{config.paths.hdri}")

node_bg = nodes.new('ShaderNodeBackground')
node_bg.inputs['Strength'].default_value = 1.0

node_output = nodes.new('ShaderNodeOutputWorld')

links.new(node_env.outputs['Color'], node_bg.inputs['Color'])
links.new(node_bg.outputs['Background'], node_output.inputs['Surface'])

# Setup render settings
scene = bpy.context.scene
scene.render.engine = 'CYCLES'
scene.cycles.device = 'GPU'  # Use GPU if available
scene.cycles.samples = {render_cfg.samples}
scene.cycles.use_denoising = True
scene.cycles.denoiser = '{denoiser}'

# Film settings
scene.render.film_transparent = {str(render_cfg.film_transparent)}

# Color management
scene.view_settings.view_transform = 'Filmic' if {str(render_cfg.filmic)} else 'Standard'
scene.view_settings.look = 'None'
scene.view_settings.exposure = 0
scene.view_settings.gamma = 1

# Output settings
scene.render.resolution_x = {resolution}
scene.render.resolution_y = {resolution}
scene.render.resolution_percentage = 100

scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.render.image_settings.color_depth = '8'
scene.render.image_settings.compression = 15

# Render
output_path = r"{output_path_abs}"
scene.render.filepath = output_path
bpy.ops.render.render(write_still=True)

print(f"HQ render complete: {{output_path}}")
'''

    return script


def render_hq_cached(
    glb_path: Path,
    params: Dict[str, float],
    out_path: Path,
    config: Config,
    cache_manager: Optional[CacheManager] = None,
) -> bool:
    """Render high-quality image with caching support.

    Checks cache before rendering. If valid cached render exists with matching
    parameters, returns immediately. Otherwise renders and saves to cache.

    Args:
        glb_path: Path to GLB file
        params: Camera/object parameters
        out_path: Output PNG path
        config: VFScore configuration
        cache_manager: Optional cache manager (if None, no caching)

    Returns:
        True if successful (from cache or fresh render), False otherwise
    """
    # Define cache artifact name
    artifact_name = f"hq_render_{out_path.stem}"

    # Check cache if manager provided
    if cache_manager is not None:
        input_files = {"glb": glb_path}
        input_params = {
            "params": params,
            "resolution": config.objective.hq_resolution,
            "samples": config.render.samples,
            "engine": "CYCLES",
        }

        if cache_manager.is_cached(
            artifact_name=artifact_name,
            artifact_path=out_path,
            input_files=input_files,
            input_params=input_params,
            check_file_hashes=False,  # GLB files are immutable, skip hash check
        ):
            # Cache hit - render already exists and is valid
            return True

    # Cache miss or no cache manager - render
    success = render_hq(glb_path, params, out_path, config)

    # Save to cache if successful and cache manager provided
    if success and cache_manager is not None:
        cache_manager.save_cache(
            artifact_name=artifact_name,
            artifact_path=out_path,
            input_files={"glb": glb_path},
            input_params={
                "params": params,
                "resolution": config.objective.hq_resolution,
                "samples": config.render.samples,
                "engine": "CYCLES",
            },
            compute_artifact_hash=True,
        )

    return success

