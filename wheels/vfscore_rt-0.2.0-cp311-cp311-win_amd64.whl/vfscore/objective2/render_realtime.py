"""GPU-accelerated real-time rendering using trimesh+pyrender for pose optimization.

This module provides real-time 3D rendering capabilities for gradient descent-based
pose optimization. It uses trimesh for GLB loading and pyrender for GPU-accelerated
OpenGL rendering, achieving 60-120 FPS rendering speeds.
"""

from __future__ import annotations

import numpy as np
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from PIL import Image, ImageDraw, ImageFont
import cv2

try:
    import trimesh
    import pyrender
    PYRENDER_AVAILABLE = True
except ImportError:
    PYRENDER_AVAILABLE = False
    trimesh = None
    pyrender = None


class RealtimeRenderer:
    """GPU-accelerated real-time renderer for pose search and optimization.

    This renderer uses trimesh+pyrender for fast OpenGL rendering without subprocess
    overhead. It's designed for interactive pose optimization where we need to render
    hundreds of frames quickly.

    Features:
    - 60-120 FPS rendering speed (vs 0.5-2 FPS with Blender subprocess)
    - Mesh caching to avoid reloading GLB files
    - Alpha channel support for silhouette extraction
    - Configurable resolution and camera parameters
    """

    def __init__(self, resolution: int = 512, flip_180_for_blender: bool = False):
        """Initialize the realtime renderer.

        Args:
            resolution: Default output image resolution (square images)
            flip_180_for_blender: Add 180deg to azimuth for Blender compatibility

        Raises:
            ImportError: If pyrender is not available
        """
        if not PYRENDER_AVAILABLE:
            raise ImportError(
                "pyrender not available. Install with: pip install trimesh pyrender"
            )

        self.resolution = resolution
        self.flip_180_for_blender = flip_180_for_blender
        self.renderer = pyrender.OffscreenRenderer(resolution, resolution)
        self.renderer_256 = pyrender.OffscreenRenderer(256, 256)  # Fast refinement renderer
        self.renderer_coarse = pyrender.OffscreenRenderer(resolution, resolution)  # Coarse search renderer (uses configured resolution)
        self.mesh_cache = {}  # Cache base meshes by GLB path (no yaw rotation)
        self.mesh_norm_metadata: Dict[str, Dict[str, Any]] = {}

        # Persistent scene with reusable nodes
        self.scene = pyrender.Scene(ambient_light=[0.3, 0.3, 0.3])

        # CRITICAL OPTIMIZATION: Caching for mesh nodes (one per material type)
        # This avoids rebuilding pyrender.Mesh from trimesh on every render
        self.mesh_nodes: Dict[str, pyrender.Node] = {}
        self.active_mesh_node: pyrender.Node | None = None
        self.current_glb: str | None = None  # Track which GLB is loaded

        # Scene nodes
        self.cam_node = None
        self.camera_obj = None  # Store camera object reference for FOV updates
        self.key_light_node = None
        self.fill_light_node = None

    def render_mask(
        self,
        glb_path: Path,
        azimuth_deg: float,
        elevation_deg: float,
        radius: float,
        fov_deg: float,
        obj_yaw_deg: float = 0.0,
        fast: bool = False,
        coarse: bool = False
    ) -> np.ndarray:
        """Render silhouette mask of GLB file using persistent scene.

        This is the fast path for pose search - renders only the binary silhouette
        without materials or lighting complexity.

        Args:
            glb_path: Path to GLB file
            azimuth_deg: Camera azimuth angle in degrees (0 = +X axis)
            elevation_deg: Camera elevation angle in degrees (0 = horizon)
            radius: Camera distance from origin
            fov_deg: Camera field of view in degrees
            obj_yaw_deg: Object yaw rotation in degrees (around Z axis)
            fast: If True, use 256px renderer for refinement (default: False)
            coarse: If True, use configured resolution renderer for coarse search (default: False)

        Returns:
            Binary mask (0 or 255) as numpy array [H, W]
        """
        # CRITICAL FIX: Use material=None to avoid "already bound to context" errors
        # We extract the mask from depth buffer anyway, so material doesn't matter
        self._ensure_mesh_loaded(glb_path, obj_yaw_deg, material=None)

        # Ensure camera is set up
        self._ensure_camera(fov_deg, azimuth_deg, elevation_deg, radius)

        # Ensure light is set up (only if not fast/coarse mode)
        if not fast and not coarse:
            camera_pose = self._camera_pose(azimuth_deg, elevation_deg, radius)
            if self.key_light_node is None:
                light = pyrender.DirectionalLight(color=[1.0, 1.0, 1.0], intensity=2.0)
                self.key_light_node = self.scene.add(light, pose=camera_pose)
            else:
                self.scene.set_pose(self.key_light_node, camera_pose)

        # Render using appropriate renderer (configured resolution for coarse, 256px fast, or full resolution)
        if coarse:
            renderer = self.renderer_coarse
        elif fast:
            renderer = self.renderer_256
        else:
            renderer = self.renderer
        color, depth = renderer.render(self.scene)

        # Extract silhouette from depth
        mask = (depth > 0).astype(np.uint8) * 255

        return mask

    def render_rgb(
        self,
        glb_path: Path,
        azimuth_deg: float,
        elevation_deg: float,
        radius: float,
        fov_deg: float,
        obj_yaw_deg: float = 0.0,
        fast: bool = False,
        coarse: bool = False,
        unlit: bool = False
    ) -> np.ndarray:
        """Render full RGB image of GLB file using persistent scene.

        This renders with materials and lighting for visual comparison with GT images.

        Args:
            glb_path: Path to GLB file
            azimuth_deg: Camera azimuth angle in degrees
            elevation_deg: Camera elevation angle in degrees
            radius: Camera distance from origin
            fov_deg: Camera field of view in degrees
            obj_yaw_deg: Object yaw rotation in degrees
            fast: If True, use 256px renderer for refinement (default: False)
            coarse: If True, use configured resolution renderer for coarse search (default: False)
            unlit: If True, use simple white material and no lights (MUCH faster for optimization)

        Returns:
            RGB image as numpy array [H, W, 3]
        """
        # CRITICAL: Use white unlit material during optimization for 2-3x speedup
        if unlit:
            # Simple white material with no lighting needed
            material = pyrender.MetallicRoughnessMaterial(
                baseColorFactor=[1.0, 1.0, 1.0, 1.0],
                metallicFactor=0.0,
                roughnessFactor=1.0
            )
            self._ensure_mesh_loaded(glb_path, obj_yaw_deg, material=material)
        else:
            # Use original materials for final renders
            self._ensure_mesh_loaded(glb_path, obj_yaw_deg, material=None)

        # Ensure camera is set up
        self._ensure_camera(fov_deg, azimuth_deg, elevation_deg, radius)

        # CRITICAL: Skip lights in unlit mode for faster rendering
        if not unlit:
            # Ensure lights are set up for lit rendering
            key_pose = self._camera_pose(azimuth_deg + 30, elevation_deg + 20, radius)
            fill_pose = self._camera_pose(azimuth_deg - 30, elevation_deg, radius)

            if self.key_light_node is None:
                key_light = pyrender.DirectionalLight(color=[1.0, 1.0, 1.0], intensity=3.0)
                self.key_light_node = self.scene.add(key_light, pose=key_pose)
            else:
                self.scene.set_pose(self.key_light_node, key_pose)

            if self.fill_light_node is None:
                fill_light = pyrender.DirectionalLight(color=[1.0, 1.0, 1.0], intensity=1.5)
                self.fill_light_node = self.scene.add(fill_light, pose=fill_pose)
            else:
                self.scene.set_pose(self.fill_light_node, fill_pose)

        # Render using appropriate renderer (configured resolution for coarse, 256px fast, or full resolution)
        if coarse:
            renderer = self.renderer_coarse
        elif fast:
            renderer = self.renderer_256
        else:
            renderer = self.renderer
        color, _ = renderer.render(self.scene)

        return color

    def render_edges(
        self,
        glb_path: Path,
        azimuth_deg: float,
        elevation_deg: float,
        radius: float,
        fov_deg: float,
        obj_yaw_deg: float = 0.0,
        low_threshold: int = 50,
        high_threshold: int = 150
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Render RGB image and extract edges for pose search.

        This renders the object and computes Canny edges for use in the global
        search objective function.

        Args:
            glb_path: Path to GLB file
            azimuth_deg: Camera azimuth angle in degrees
            elevation_deg: Camera elevation angle in degrees
            radius: Camera distance from origin
            fov_deg: Camera field of view in degrees
            obj_yaw_deg: Object yaw rotation in degrees
            low_threshold: Lower threshold for Canny edge detection
            high_threshold: Upper threshold for Canny edge detection

        Returns:
            Tuple of (edges, distance_transform) as numpy arrays
        """
        # Render RGB image
        rgb = self.render_rgb(glb_path, azimuth_deg, elevation_deg, radius, fov_deg, obj_yaw_deg)

        # Extract edges using Canny
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(gray, low_threshold, high_threshold)

        # Compute distance transform for efficient chamfer distance
        binary = (edges > 0).astype(np.uint8)
        dist_transform = cv2.distanceTransform(binary, cv2.DIST_L2, 5).astype(np.float32)

        return edges, dist_transform

    def _load_base_mesh(self, glb_path: Path) -> trimesh.Trimesh:
        """Load and normalize base mesh from GLB file with caching.

        This caches only the base mesh without any yaw rotation. Yaw is applied
        at render time via node transforms to avoid geometry duplication.

        Args:
            glb_path: Path to GLB file

        Returns:
            Normalized trimesh object (float32 vertices)
        """
        cache_key = str(glb_path)

        if cache_key in self.mesh_cache:
            return self.mesh_cache[cache_key]

        # Load mesh
        mesh = trimesh.load(str(glb_path))

        # Handle multi-geometry GLB files
        if isinstance(mesh, trimesh.Scene):
            # Merge all geometries into a single mesh
            mesh = mesh.dump(concatenate=True)

        # CRITICAL FIX: Apply Y-up to Z-up transformation
        # GLB/GLTF standard uses Y-up, but we use Z-up
        # Use +90° X-axis rotation to match GT images (right-side up)
        # Transformation: (x_new, y_new, z_new) = (x_old, -z_old, y_old)
        y_up_to_z_up = np.array([
            [1,  0,  0,  0],
            [0,  0, -1,  0],  # y_new = -z_old
            [0,  1,  0,  0],  # z_new =  y_old
            [0,  0,  0,  1]
        ])
        mesh.apply_transform(y_up_to_z_up)

        # Normalize to unit cube centered at origin
        centroid = mesh.centroid.copy()
        mesh.apply_translation(-centroid)

        bbox_after_translation = mesh.bounding_box
        bbox_extents = bbox_after_translation.extents.copy()
        bbox_bounds = bbox_after_translation.bounds.copy()
        raw_max_extent = float(bbox_extents.max())
        max_extent = raw_max_extent if raw_max_extent > 0.0 else 1.0
        scale = 1.0 / max_extent
        mesh.apply_scale(scale)

        # Convert vertices to float32 to halve memory usage
        mesh.vertices = mesh.vertices.astype(np.float32)

        # Cache the base normalized mesh
        self.mesh_cache[cache_key] = mesh
        self.mesh_norm_metadata[cache_key] = {
            "y_up_to_z_up": y_up_to_z_up.tolist(),
            "centroid_before_translation": centroid.tolist(),
            "bbox_bounds_after_translation": bbox_bounds.tolist(),
            "bbox_extents_after_translation": bbox_extents.tolist(),
            "scale_factor": float(scale),
            "max_extent_before_scale": float(raw_max_extent),
            "bbox_bounds_after_scale": mesh.bounding_box.bounds.tolist(),
            "bbox_extents_after_scale": mesh.bounding_box.extents.tolist(),
        }

        return mesh

    def get_normalization_metadata(self, glb_path: Path) -> Dict[str, Any]:
        """Return the normalization transform metadata for a GLB."""

        cache_key = str(glb_path)
        if cache_key not in self.mesh_norm_metadata:
            self._load_base_mesh(glb_path)
        return dict(self.mesh_norm_metadata.get(cache_key, {}))

    def _ensure_mesh_loaded(
        self,
        glb_path: Path,
        obj_yaw_deg: float,
        material=None
    ) -> None:
        """Ensure mesh is loaded in the persistent scene with correct yaw rotation.

        CRITICAL OPTIMIZATION: Caches pyrender.Mesh nodes in a dictionary,
        one for each material key ('none', 'unlit', 'default').
        This avoids rebuilding the mesh from trimesh on every call.

        Args:
            glb_path: Path to GLB file
            obj_yaw_deg: Object yaw rotation in degrees
            material: Optional pyrender material
        """
        # 1. Determine material key for caching
        material_key = "default"
        if material is None:
            material_key = "none"  # Used for render_mask
        elif hasattr(material, 'metallicFactor') and material.metallicFactor == 0.0:
            material_key = "unlit"  # Used for render_rgb(unlit=True)

        # 2. Check if GLB has changed. If so, clear all cached mesh nodes.
        if self.current_glb != str(glb_path):
            for node in self.mesh_nodes.values():
                if self.scene.has_node(node):
                    self.scene.remove_node(node)
            self.mesh_nodes.clear()
            self.active_mesh_node = None
            self.current_glb = str(glb_path)

        # 3. Check if this specific mesh/material combo is cached
        if material_key not in self.mesh_nodes:
            # --- Cache Miss: Build this mesh variant ---

            # Load base trimesh (this is cached by _load_base_mesh)
            base_mesh = self._load_base_mesh(glb_path)

            # Create FRESH pyrender mesh
            if material is not None:
                py_mesh = pyrender.Mesh.from_trimesh(base_mesh, material=material)
            elif hasattr(base_mesh, 'visual') and hasattr(base_mesh.visual, 'material'):
                py_mesh = pyrender.Mesh.from_trimesh(base_mesh)
            else:
                # Default material
                default_mat = pyrender.MetallicRoughnessMaterial(
                    baseColorFactor=[0.8, 0.8, 0.8, 1.0],
                    metallicFactor=0.2,
                    roughnessFactor=0.8
                )
                py_mesh = pyrender.Mesh.from_trimesh(base_mesh, material=default_mat)

            # Add fresh mesh to scene and store it in our cache
            self.mesh_nodes[material_key] = self.scene.add(py_mesh)

        # 4. Set the active mesh node and hide others
        # CRITICAL FIX: Always run the visibility loop to prevent state-leak.
        # This is extremely fast (loops 2-3 items, microseconds) and guarantees
        # only one mesh is visible, fixing the "two-mesh" bug.
        # Performance impact: negligible (boolean assignment << render time).
        self.active_mesh_node = self.mesh_nodes[material_key]
        for node in self.mesh_nodes.values():
            if hasattr(node, "mesh") and node.mesh is not None:
                # pyrender toggles visibility on the Mesh, not Node; using node.visible
                # silently adds an attribute and leaves all meshes active.
                node.mesh.is_visible = (node == self.active_mesh_node)

        # 5. Apply yaw rotation to the active mesh node
        yaw_matrix = trimesh.transformations.rotation_matrix(
            np.radians(obj_yaw_deg), [0, 0, 1]
        )
        self.scene.set_pose(self.active_mesh_node, yaw_matrix)

    def _ensure_camera(self, fov_deg: float, azimuth_deg: float, elevation_deg: float, radius: float) -> None:
        """Ensure camera is set up in the persistent scene.

        Args:
            fov_deg: Vertical field of view in degrees
            azimuth_deg: Camera azimuth angle
            elevation_deg: Camera elevation angle
            radius: Camera distance from origin
        """
        camera_pose = self._camera_pose(azimuth_deg, elevation_deg, radius)

        if self.cam_node is None:
            # Create camera for the first time
            self.camera_obj = pyrender.PerspectiveCamera(yfov=np.radians(fov_deg))
            self.cam_node = self.scene.add(self.camera_obj, pose=camera_pose)
        else:
            # Update camera pose
            self.scene.set_pose(self.cam_node, camera_pose)
            # CRITICAL FIX: Update camera FOV to enable FOV optimization
            # This ensures FOV gradients are non-zero and the optimizer can adjust scale
            self.camera_obj.yfov = np.radians(fov_deg)

    def _camera_pose(
        self,
        azimuth_deg: float,
        elevation_deg: float,
        radius: float
    ) -> np.ndarray:
        """Calculate camera pose matrix from spherical coordinates.

        Args:
            azimuth_deg: Horizontal angle in degrees (0 = +X axis)
            elevation_deg: Vertical angle in degrees (0 = horizon)
            radius: Distance from origin

        Returns:
            4x4 camera pose matrix
        """
        # Convert to radians (optionally add 180 for Blender compatibility)
        azimuth_offset = 180 if self.flip_180_for_blender else 0
        az = np.radians(azimuth_deg + azimuth_offset)
        el = np.radians(elevation_deg)

        # Spherical to Cartesian coordinates
        x = radius * np.cos(el) * np.cos(az)
        y = radius * np.cos(el) * np.sin(az)
        z = radius * np.sin(el)

        # Create look-at transformation
        eye = np.array([x, y, z])
        center = np.array([0, 0, 0])
        up = np.array([0, 0, 1])

        # Build 4x4 camera matrix
        z_axis = eye - center
        z_axis = z_axis / np.linalg.norm(z_axis)
        x_axis = np.cross(up, z_axis)
        x_axis = x_axis / np.linalg.norm(x_axis)
        y_axis = np.cross(z_axis, x_axis)

        pose = np.eye(4)
        pose[:3, 0] = x_axis
        pose[:3, 1] = y_axis
        pose[:3, 2] = z_axis
        pose[:3, 3] = eye

        return pose

    def get_camera_pose(self, azimuth_deg: float, elevation_deg: float, radius: float) -> np.ndarray:
        """Public helper to reuse the exact camera pose matrix used by pyrender."""
        return self._camera_pose(azimuth_deg, elevation_deg, radius)

    def cleanup_scene(self):
        """Clear scene state to prevent context leaks between items.

        CRITICAL FIX (2025-11-12): This cleans up all cached pyrender nodes
        to prevent "already bound to context" errors between items.

        UPDATE (2025-11-12): Use self.scene.clear() for a more robust
        cleanup than manually removing nodes, fixing the "two-mesh" bug.

        PERFORMANCE FIX: We NO LONGER clear self.mesh_cache (the trimesh cache),
        as this was a performance bottleneck, forcing re-loading of the GLB.
        """

        # CRITICAL FIX: Use scene.clear() to remove ALL nodes (mesh, cam, lights)
        # This is more robust than iterating self.mesh_nodes.values()
        if self.scene is not None:
            self.scene.clear()

        # Clear the dictionary of *pyrender nodes*
        self.mesh_nodes.clear()

        # Reset all scene-related attributes to None
        self.active_mesh_node = None
        self.current_glb = None  # Force reload on next item
        self.cam_node = None
        self.camera_obj = None
        self.key_light_node = None
        self.fill_light_node = None

        # DO NOT CLEAR self.mesh_cache HERE
        # self.mesh_cache.clear() # <-- This line was harmful to performance

    def __del__(self):
        """Cleanup renderer resources."""
        if hasattr(self, 'renderer'):
            self.renderer.delete()
        if hasattr(self, 'renderer_256'):
            self.renderer_256.delete()
        if hasattr(self, 'renderer_coarse'):
            self.renderer_coarse.delete()


def compute_perceptual_error(
    rendered_rgb: np.ndarray,
    gt_rgb: np.ndarray,
    gt_mask: Optional[np.ndarray] = None,
    debug: bool = False
) -> float:
    """Compute perceptual error between rendered and ground truth images.

    This uses a simplified perceptual metric based on color differences in LAB space,
    which is fast enough for real-time optimization. For final scoring, we still use
    LPIPS which is more accurate but slower.

    IMPORTANT: No resizing is performed. Images must be the same size.
    This preserves scale cues that FOV optimization depends on.

    Args:
        rendered_rgb: Rendered RGB image [H, W, 3]
        gt_rgb: Ground truth RGB image [H, W, 3]
        gt_mask: Optional mask to focus on object region [H, W]
        debug: If True, print debug information

    Returns:
        Perceptual error in range [0, 1] where 0 is perfect match

    Raises:
        ValueError: If images have different shapes
    """
    # CRITICAL FIX: No resizing! This would remove the scale cue for FOV optimization
    if rendered_rgb.shape != gt_rgb.shape:
        raise ValueError(
            f"Rendered and GT images must have the same shape. "
            f"Got rendered={rendered_rgb.shape}, gt={gt_rgb.shape}. "
            f"Ensure renderer resolution matches GT image resolution."
        )

    # Convert to LAB color space (perceptually uniform)
    rendered_lab = cv2.cvtColor(rendered_rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
    gt_lab = cv2.cvtColor(gt_rgb, cv2.COLOR_RGB2LAB).astype(np.float32)

    # Compute Delta E (CIEDE2000 approximation)
    delta_e = np.sqrt(np.sum((rendered_lab - gt_lab) ** 2, axis=2))

    # Apply mask if provided
    if gt_mask is not None:
        if gt_mask.shape != delta_e.shape:
            gt_mask = cv2.resize(gt_mask, (delta_e.shape[1], delta_e.shape[0]))
        mask_binary = (gt_mask > 128).astype(np.float32)
        if mask_binary.sum() > 0:
            delta_e = delta_e * mask_binary
            # Normalize by masked area
            error = delta_e.sum() / mask_binary.sum()
        else:
            error = delta_e.mean()
    else:
        error = delta_e.mean()

    if debug:
        print(f"  [DEBUG] Raw Delta E error: {error:.2f}")
        print(f"  [DEBUG] Rendered stats: min={rendered_rgb.min()}, max={rendered_rgb.max()}, mean={rendered_rgb.mean():.1f}")
        print(f"  [DEBUG] GT stats: min={gt_rgb.min()}, max={gt_rgb.max()}, mean={gt_rgb.mean():.1f}")
        if gt_mask is not None:
            print(f"  [DEBUG] Mask coverage: {mask_binary.sum() / mask_binary.size * 100:.1f}%")

    # CRITICAL FIX: Don't saturate the error!
    # Use a much larger normalization range to preserve gradient signal
    # Delta E can range from 0 to ~400+ for very different colors
    # We use 200 as the normalization factor (severe mismatch = 0.5, not 1.0)
    normalized_error = error / 200.0

    return normalized_error


def create_overlay_frame(
    rendered_rgb: np.ndarray,
    gt_rgb: np.ndarray,
    error: float,
    iteration: int,
    params: Dict[str, float],
    flash: bool = False,
    threshold_met: bool = False,
    success: bool = False,
    tag_opacity: float = 0.6,
    tag_corner: str = "tr"
) -> np.ndarray:
    """Create visualization frame with rendered image overlaid on GT.

    IMPORTANT: Both images must be the same resolution (no resizing performed).
    This ensures the visualization accurately reflects the optimization process.

    Args:
        rendered_rgb: Rendered RGB image [H, W, 3]
        gt_rgb: Ground truth RGB image [H, W, 3]
        error: Current error value
        iteration: Current iteration number
        params: Current pose parameters
        flash: If True, shows flashing effect at the end
        threshold_met: If True, error is below threshold (flash red during optimization)
        success: If True, optimization succeeded (flash red at end)
        tag_opacity: Opacity for overlay tags (0.0-1.0)
        tag_corner: Tag corner placement ("tl", "tr", "bl", "br")

    Returns:
        Visualization frame with error overlay [H, W, 3]

    Raises:
        ValueError: If images have different shapes
    """
    # CRITICAL FIX: No resizing - preserve optimization resolution
    if rendered_rgb.shape != gt_rgb.shape:
        raise ValueError(
            f"Rendered and GT must have same shape. "
            f"Got rendered={rendered_rgb.shape}, gt={gt_rgb.shape}"
        )

    # NEW VISUALIZATION LOGIC:
    # - GT always visible at 50% opacity
    # - 3D object flashes red when threshold met

    if flash:
        # Final flash frames
        if success:
            # Flash red for success
            if (iteration // 2) % 2 == 0:
                # Show red-tinted rendered image
                red_tint = rendered_rgb.copy().astype(np.float32)
                red_tint[:, :, 0] = np.minimum(255, red_tint[:, :, 0] * 1.5)  # Boost red channel
                red_tint[:, :, 1] = red_tint[:, :, 1] * 0.7  # Reduce green
                red_tint[:, :, 2] = red_tint[:, :, 2] * 0.7  # Reduce blue
                overlay = (0.5 * red_tint + 0.5 * gt_rgb).astype(np.uint8)
            else:
                # Show normal blend
                overlay = (0.5 * rendered_rgb + 0.5 * gt_rgb).astype(np.uint8)
        else:
            # Flash normal for failure (just alternate between rendered and GT)
            alpha = 1.0 if (iteration // 2) % 2 == 0 else 0.0
            overlay = (alpha * rendered_rgb + (1 - alpha) * gt_rgb).astype(np.uint8)
    else:
        # During optimization
        if threshold_met:
            # Flash red when threshold is met
            if iteration % 4 < 2:
                # Show red-tinted rendered image
                red_tint = rendered_rgb.copy().astype(np.float32)
                red_tint[:, :, 0] = np.minimum(255, red_tint[:, :, 0] * 1.5)  # Boost red
                red_tint[:, :, 1] = red_tint[:, :, 1] * 0.7  # Reduce green
                red_tint[:, :, 2] = red_tint[:, :, 2] * 0.7  # Reduce blue
                overlay = (0.5 * red_tint + 0.5 * gt_rgb).astype(np.uint8)
            else:
                # Show normal blend
                overlay = (0.5 * rendered_rgb + 0.5 * gt_rgb).astype(np.uint8)
        else:
            # Always show GT at 50% + rendered at 50%
            overlay = (0.5 * rendered_rgb + 0.5 * gt_rgb).astype(np.uint8)

    # CRITICAL FIX: Place tags OUTSIDE the image by expanding canvas
    # This prevents tags from hiding the rendered content

    # Calculate tag dimensions
    error_tag_height = 80
    param_tag_height = 110
    margin = 10

    # Original image dimensions
    img_h, img_w = overlay.shape[:2]

    # Calculate new canvas size based on tag_corner
    if tag_corner in ["tl", "tr"]:
        # Tags at top: add vertical space above image
        tag_space = error_tag_height + param_tag_height + 3 * margin
        new_h = img_h + tag_space
        new_w = img_w
        img_y_offset = tag_space
        img_x_offset = 0
    elif tag_corner in ["bl", "br"]:
        # Tags at bottom: add vertical space below image
        tag_space = error_tag_height + param_tag_height + 3 * margin
        new_h = img_h + tag_space
        new_w = img_w
        img_y_offset = 0
        img_x_offset = 0
    else:
        # Default: top-right
        tag_space = error_tag_height + param_tag_height + 3 * margin
        new_h = img_h + tag_space
        new_w = img_w
        img_y_offset = tag_space
        img_x_offset = 0

    # Create expanded canvas with black background
    expanded_canvas = np.zeros((new_h, new_w, 3), dtype=np.uint8)

    # Place original image on canvas
    expanded_canvas[img_y_offset:img_y_offset+img_h, img_x_offset:img_x_offset+img_w] = overlay

    # Convert to PIL for text rendering
    frame = Image.fromarray(expanded_canvas)
    draw = ImageDraw.Draw(frame)

    # Try to use a font, fall back to default if not available
    try:
        font_large = ImageFont.truetype("arial.ttf", 24)
        font_small = ImageFont.truetype("arial.ttf", 16)
    except IOError:
        font_large = ImageFont.load_default()
        font_small = ImageFont.load_default()

    # Prepare text content
    error_text = f"Error: {error:.4f}"
    iter_text = f"Iter: {iteration}"
    param_text = (
        f"Az: {params['azimuth_deg']:.1f}  El: {params['elevation_deg']:.1f}\n"
        f"R: {params['radius']:.2f}  FOV: {params['fov_deg']:.1f}\n"
        f"Yaw: {params['obj_yaw_deg']:.1f}  Roll: {params.get('roll_deg', 0.0):.1f}\n"
        f"Cx: {params.get('cx_norm', 0.0):.3f}  Cy: {params.get('cy_norm', 0.0):.3f}"
    )

    # Calculate tag positions in margin areas
    if tag_corner in ["tl", "tr"]:
        # Tags in top margin
        error_y = margin
        param_y = error_y + error_tag_height + margin

        if tag_corner == "tl":
            # Left-aligned
            error_x = margin
            param_x = margin
        else:  # "tr"
            # Right-aligned
            error_x = new_w - 250 - margin
            param_x = new_w - 250 - margin
    else:  # "bl", "br"
        # Tags in bottom margin
        error_y = img_y_offset + img_h + margin
        param_y = error_y + error_tag_height + margin

        if tag_corner == "bl":
            # Left-aligned
            error_x = margin
            param_x = margin
        else:  # "br"
            # Right-aligned
            error_x = new_w - 250 - margin
            param_x = new_w - 250 - margin

    # Draw semi-transparent background rectangles
    alpha_value = int(255 * tag_opacity)

    # Since we can't use alpha on RGB, draw solid rectangles with slight gray for visibility
    bg_color = (40, 40, 40) if tag_opacity > 0.5 else (20, 20, 20)

    # Error tag background
    draw.rectangle(
        [(error_x, error_y), (error_x + 240, error_y + error_tag_height)],
        fill=bg_color,
        outline=(80, 80, 80),
        width=1
    )

    # Param tag background
    draw.rectangle(
        [(param_x, param_y), (param_x + 240, param_y + param_tag_height)],
        fill=bg_color,
        outline=(80, 80, 80),
        width=1
    )

    # Draw text
    draw.text((error_x + 10, error_y + 10), error_text, fill=(255, 255, 255), font=font_large)
    draw.text((error_x + 10, error_y + 45), iter_text, fill=(200, 200, 200), font=font_small)
    draw.text((param_x + 10, param_y + 10), param_text, fill=(200, 200, 200), font=font_small)

    return np.array(frame)
