"""Objective2 Pipeline - Multi-GT Pre-rendered Library Approach.

This pipeline improves upon the realtime optimizer by:
1. Using ALL ground truth images (not just first)
2. Pre-rendering a systematic library at 5° increments
3. Matching all GT-candidate pairs to find best initialization
4. Refining from the best match pair

Architecture:
- Stage 0: Radius calibration (match GT area)
- Stage 1: Pre-render library (128px, lightless, systematic coverage)
- Stage 2: Multi-GT matching (ALL GTs vs ALL library renders)
- Stage 3: Refinement from best match (Adam optimizer)
- Stage 4: HQ render + LPIPS scoring
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

from PIL import Image
from rich.console import Console
from rich.progress import BarColumn, Progress, TaskProgressColumn, TextColumn

from vfscore.config import Config
from vfscore.objective2.cache import CacheManager
from vfscore.objective2.combine import combine_score
from vfscore.objective2.lpips_score import compute_lpips_cached, compute_lpips_batch
from vfscore.objective2.render_hq_pyrender import render_hq_pyrender_cached
from vfscore.objective2.silhouette import extract_mask, prepare_edges_and_dt, iou
from vfscore.objective2.prerender_library import PrerenderLibrary, PrerenderPose
from vfscore.objective2.multi_gt_matcher import MultiGTMatcher, MatchResult
from vfscore.objective2.refine_pose import PoseRefiner, RefineParams
from vfscore.objective2.image_utils import (
    save_gt_with_bbox_visualization,
    save_render_with_bbox_visualization,
    exact_crop_and_pad_to_gt,
    exact_crop_to_bbox,
    scale_to_target_dimension,
    scale_to_max_dimension,
    pad_to_dimensions,
    pad_mask_to_square
)
from vfscore.utils import make_gt_id
import time
import numpy as np
import cv2

console = Console(legacy_windows=True)
USE_BLENDER_VALIDATION: bool = False


class Objective2Pipeline:
    """Pipeline using multi-GT pre-rendered library approach."""

    def __init__(self, config: Config, force_cache: bool = False) -> None:
        """Initialize the objective2 pipeline.

        Args:
            config: VFScore configuration
            force_cache: If True, invalidate all caches
        """
        self.config = config
        self.force_cache = force_cache

        # Initialize components using objective2 config
        lib_cfg = config.objective.objective2.library
        calib_cfg = lib_cfg.radius_calibration
        self.prerender = PrerenderLibrary(
            resolution=calib_cfg.pose_estimation_resolution,  # Use configured resolution for pose estimation
            angular_step_deg=lib_cfg.angular_step_deg,
            fov_values=lib_cfg.fov_values,
            radius_multipliers=lib_cfg.radius_multipliers,
            elevation_values=lib_cfg.elevation_values
        )

        # CRITICAL FIX: Use same edge weight as refinement for objective consistency
        ref_cfg = config.objective.objective2.refinement
        self.matcher = MultiGTMatcher(
            iou_weight=ref_cfg.iou_weight,
            edge_weight=ref_cfg.edge_weight,  # MUST match refinement!
            binarize_threshold=config.objective.silhouette.binarize_threshold,
            erode_dilate_px=config.objective.silhouette.erode_dilate_px
        )

    def run(self, manifest: List[Dict]) -> None:
        """Run the objective2 pipeline on all items.

        Args:
            manifest: List of item records from manifest.jsonl
        """
        print("\n" + "="*80)
        print("  VFScore Objective2 Pipeline - Multi-GT Library-Based Pose Estimation")
        print("="*80)
        print("Pipeline Features:")
        print("  - Multi-GT support: uses ALL reference photos")
        print("  - Pre-rendered library: systematic spherical sweep")
        print("  - Pyrender rendering: fast GPU-accelerated, NO Blender for estimation")
        print("  - Validation render: verify pose before expensive HQ Blender render")
        print("  - Best initialization: starts from best GT-candidate match")
        print("="*80 + "\n")

        success = 0
        failure = 0

        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Scoring", total=len(manifest))

            for record in manifest:
                item_id = record.get("item_id") or record.get("product_id")
                try:
                    result = self._process_item(record)
                    if result:
                        success += 1
                    else:
                        failure += 1
                except Exception as exc:  # pylint: disable=broad-except
                    failure += 1
                    print(f"[ERROR] {item_id}: Objective2 pipeline error - {exc}")
                finally:
                    # Cleanup
                    try:
                        self.prerender.renderer.cleanup_scene()
                    except Exception as cleanup_exc:
                        print(f"[WARNING] {item_id}: Warning - cleanup error: {cleanup_exc}")
                    progress.advance(task)

        print("\n" + "="*80)
        print(f"  Objective2 Pipeline Complete")
        print(f"  Success: {success} | Failed: {failure}")
        print("="*80 + "\n")

    def _process_item(self, record: Dict) -> Optional[Dict]:
        """Process a single item through the objective2 pipeline.

        Args:
            record: Item record from manifest

        Returns:
            Result dictionary with scores and metadata, or None if failed
        """
        item_id = record["item_id"]
        product_id = record.get("product_id", item_id)
        variant = record.get("variant", "")
        glb_path = Path(record["glb_path"])

        # Start timing
        item_start_time = time.time()

        # Validate GLB exists
        if not glb_path.exists():
            print(f"[WARNING] {item_id}: Missing GLB {glb_path}")
            return None

        # Setup output directory
        output_dir = self.config.objective.priors_cache_dir / item_id
        output_dir.mkdir(parents=True, exist_ok=True)

        # Check if final.json already exists (cache detection)
        final_path = output_dir / "final.json"
        if not self.force_cache and final_path.exists():
            try:
                with open(final_path, 'r', encoding='utf-8') as f:
                    cached_result = json.load(f)
                print(f"{item_id}: SKIPPING (final.json already exists)")
                return cached_result
            except (json.JSONDecodeError, KeyError) as e:
                print(f"{item_id}: WARNING - Invalid final.json ({e}), reprocessing...")

        # Create main log file
        main_log_file = output_dir / "pipeline_log.txt"
        log_lines = []
        log_lines.append("=" * 80)
        log_lines.append(f"OBJECTIVE2 PIPELINE - {item_id}")
        log_lines.append("=" * 80)
        log_lines.append(f"Started: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        log_lines.append(f"GLB: {glb_path}")
        log_lines.append("-" * 80)

        cache_manager = CacheManager(
            output_dir, enabled=self.config.objective.use_cache
        )
        if self.force_cache:
            cache_manager.invalidate_all()
            log_lines.append("Cache invalidated (force mode)")

        # Load ALL ground truth images
        gt_id = make_gt_id(product_id, variant)
        gt_dir = self.config.paths.out_dir / "preprocess" / "refs" / gt_id

        if not gt_dir.exists():
            print(f"[WARNING] {item_id}: GT directory not found")
            return None

        print(f"{item_id}: STAGE 1 - Loading ground truth images...")
        stage_start = time.time()

        # Determine GT matching mode from config
        gt_matching_mode = self.config.objective.objective2.gt_matching_mode
        selected_only = (gt_matching_mode == "single")

        # Load GT images using new metadata-based method (falls back to legacy if no metadata)
        gt_images = self.matcher.load_gt_images_from_metadata(
            gt_dir,
            mode="square",  # Use square for pose estimation
            selected_only=selected_only
        )

        if not gt_images:
            print(f"[WARNING] {item_id}: No GT images found")
            return None

        mode_str = "single (selected)" if selected_only else "multi (all)"
        print(f"  Found {len(gt_images)} GT image(s) in {mode_str} mode ({time.time() - stage_start:.1f}s)")
        log_lines.append(f"STAGE 1: Loaded {len(gt_images)} GT image(s), mode={mode_str} ({time.time() - stage_start:.1f}s)")

        # Use first GT mask for radius calibration
        _, _, _, gt_mask_first, _, _ = gt_images[0]

        # Print GT area at actual resolution
        gt_area = np.sum(gt_mask_first > 64)  # Count opaque pixels
        gt_h, gt_w = gt_mask_first.shape
        print(f"  GT mask resolution: {gt_w}x{gt_h}, Area: {gt_area} pixels ({gt_area/(gt_w*gt_h)*100:.1f}% of image)")
        log_lines.append(f"GT mask: {gt_w}x{gt_h}, Area={gt_area}px ({gt_area/(gt_w*gt_h)*100:.1f}%)")

        # Check pipeline mode
        calib_config = self.config.objective.objective2.library.radius_calibration
        pipeline_mode = calib_config.pipeline_mode

        # Check if we can skip library generation (AR-based pipeline)
        skip_library = (
            self.config.objective.objective2.skip_library_if_ar and
            calib_config.orientation_method == "aspect_ratio" and
            pipeline_mode != "tri_criterion"  # Tri-criterion always uses library
        )

        # TRI-CRITERION PIPELINE: New default mode
        if pipeline_mode == "tri_criterion":
            # Display configuration summary
            criterion_display = {
                "iou": "IoU only",
                "area": "Area only",
                "ar": "Aspect Ratio only",
                "iou_ar": "IoU + AR hybrid",
                "tri_criterion": "IoU + Area + AR (Tri-Criterion)"
            }
            step2_method = criterion_display.get(calib_config.step2_selection_criterion, calib_config.step2_selection_criterion)
            step4_method = criterion_display.get(calib_config.step4_selection_criterion, calib_config.step4_selection_criterion)

            print(f"\n{'='*80}")
            print(f"{item_id}: PIPELINE CONFIGURATION")
            print(f"{'='*80}")
            print(f"  Pipeline Mode: TRI-CRITERION")
            print(f"  Step 2 Selection: {step2_method}")
            print(f"  Step 4 Selection: {step4_method}")
            print(f"  Coarse Iterations: {calib_config.tri_criterion_coarse_iterations}")
            print(f"  Crop Enabled: Step2={calib_config.step2_crop_enabled}, Step4={calib_config.step4_crop_enabled}")
            print(f"{'='*80}\n")
            log_lines.append(f"PIPELINE: TRI-CRITERION, Step2={step2_method}, Step4={step4_method}")

            # Step 0: Save GT with bbox visualization for debugging (if enabled)
            if self.config.objective.objective2.debug_save_images:
                print(f"\n{'-'*80}")
                print(f"{item_id}: STEP 0 - GT Bounding Box Visualization")
                print(f"{'-'*80}")
                bbox_dir = output_dir / "debug_bbox"
                bbox_dir.mkdir(parents=True, exist_ok=True)
                for gt_idx, (_, gt_path, _, gt_mask, _, _) in enumerate(gt_images):
                    bbox_out = bbox_dir / f"gt_{gt_idx+1}_bbox.png"
                    gt_mask_path = gt_path.parent / gt_path.name.replace("_square.png", "_mask_square.png")
                    save_gt_with_bbox_visualization(
                        gt_path, gt_mask_path, bbox_out,
                        edge_threshold=self.config.preprocess.edge_threshold,
                        border_px=0
                    )
                print(f"  Saved {len(gt_images)} GT bbox visualization(s)")
                print(f"{'-'*80}\n")
                log_lines.append(f"STEP 0: Saved {len(gt_images)} GT bbox visualizations")

            # Step 1: Initial radius adjustment at configured orientation
            print(f"\n{'-'*80}")
            print(f"{item_id}: STEP 1 - Initial Radius Adjustment")
            print(f"{'-'*80}")
            stage_start = time.time()
            initial_yaw = calib_config.initial_adjustment_yaw
            initial_elev = calib_config.initial_adjustment_elevation
            initial_radius = self.config.render.camera.radius

            # Use initial border margin
            debug_border_dir = output_dir / "debug_border" if self.config.objective.objective2.debug_save_images else None
            adjusted_radius, _ = self.prerender._ensure_radius_has_border(
                glb_path, initial_radius, initial_yaw, initial_elev,
                self.config.render.fov_deg, calib_config,
                self.prerender.renderer,
                label="Step1",
                margin_fraction=calib_config.initial_border_safety_margin_fraction,
                debug_dir=debug_border_dir
            )
            print(f"  Radius: {initial_radius:.3f} -> {adjusted_radius:.3f} ({time.time() - stage_start:.1f}s)")
            print(f"{'-'*80}\n")
            log_lines.append(f"STEP 1: Initial radius adjustment {initial_radius:.3f} -> {adjusted_radius:.3f}")

            # Get GT dimensions for crop operations
            gt_square_h, gt_square_w = gt_mask_first.shape

            # Get GT object's bbox aspect ratio for AR calculation (not full image aspect)
            # Compute once before loop
            gt_opaque = np.argwhere(gt_mask_first > calib_config.edge_threshold)
            if len(gt_opaque) > 0:
                gt_y_min, gt_x_min = gt_opaque.min(axis=0)
                gt_y_max, gt_x_max = gt_opaque.max(axis=0)
                gt_bbox_w = gt_x_max - gt_x_min + 1
                gt_bbox_h = gt_y_max - gt_y_min + 1
                gt_aspect = gt_bbox_w / gt_bbox_h if gt_bbox_h > 0 else 1.0
            else:
                # Fallback to full image aspect if no object found
                gt_h, gt_w = gt_mask_first.shape
                gt_aspect = gt_w / gt_h

            # Search parameters (same for all iterations)
            yaw_start = calib_config.yaw_search_start
            yaw_stop = calib_config.yaw_search_stop
            yaw_step = calib_config.yaw_search_coarse_step
            elev_start = calib_config.elevation_search_start
            elev_stop = calib_config.elevation_search_stop
            elev_step = calib_config.elevation_search_coarse_step
            fov = self.config.render.fov_deg

            # Iterative coarse search + radius adjustment
            num_coarse_iterations = calib_config.tri_criterion_coarse_iterations
            current_radius = adjusted_radius  # Start with radius from step 1

            # Step 2 crop mode
            step2_crop_enabled = calib_config.step2_crop_enabled
            target_dim_step2 = calib_config.pose_estimation_resolution

            if step2_crop_enabled:
                # Pre-crop GT once for Step 2 (same transform as Step 4):
                # crop to bbox -> scale longest side to pose_estimation_resolution -> pad to square
                gt_rgb_for_crop_step2 = np.stack([gt_mask_first] * 3, axis=-1)
                _, gt_cropped_step2, _ = exact_crop_to_bbox(
                    gt_rgb_for_crop_step2,
                    gt_mask_first,
                    edge_threshold=calib_config.edge_threshold,
                    border_px=0
                )
                # Compute GT crop aspect ratio (before padding)
                gt_crop_h_step2, gt_crop_w_step2 = gt_cropped_step2.shape[:2]
                gt_crop_aspect_step2 = gt_crop_w_step2 / gt_crop_h_step2 if gt_crop_h_step2 > 0 else 1.0

                # Scale GT crop so longest side = target_dim
                gt_scaled_step2 = scale_to_target_dimension(
                    gt_cropped_step2, target_dim_step2, use_nearest=False
                )
                # Pad to square (target_dim x target_dim) for fair comparison
                gt_for_step2 = pad_mask_to_square(gt_scaled_step2, target_dim_step2)
            else:
                # No crop: resize GT to pose_estimation_resolution for comparison
                from PIL import Image
                gt_resized = np.array(Image.fromarray(gt_mask_first).resize(
                    (target_dim_step2, target_dim_step2), Image.Resampling.LANCZOS
                ))
                gt_for_step2 = gt_resized
                gt_crop_aspect_step2 = gt_aspect  # Use full bbox aspect ratio

            for iter_num in range(1, num_coarse_iterations + 1):
                # Step 2: Coarse search - find 1 best pose (with crop/scale/pad)
                print(f"\n{'-'*80}")
                print(f"{item_id}: STEP 2 (iter {iter_num}/{num_coarse_iterations}) - Coarse Search (Find 1 Best Pose)")
                print(f"{'-'*80}")
                stage_start = time.time()

                # Clean up renderer state before intensive loop
                self.prerender.renderer.cleanup_scene()

                # Perform coarse sweep over yaw and elevation
                coarse_candidates_step2 = []

                for yaw in np.arange(yaw_start, yaw_stop, yaw_step):
                    for elev in np.arange(elev_start, elev_stop, elev_step):
                        # Render mask at this pose
                        mask_native = self.prerender.renderer.render_mask(
                            glb_path, 0.0, elev, current_radius, fov, yaw, fast=False, coarse=True
                        )

                        if step2_crop_enabled:
                            # Step 2 crop workflow (same as Step 4):
                            # crop to bbox -> scale longest side to pose_estimation_resolution -> pad to square
                            mask_rgb = np.stack([mask_native] * 3, axis=-1)
                            _, mask_cropped, _ = exact_crop_to_bbox(
                                mask_rgb,
                                mask_native,
                                edge_threshold=calib_config.edge_threshold,
                                border_px=0
                            )
                            # Scale render crop so longest side = target_dim
                            mask_scaled = scale_to_target_dimension(
                                mask_cropped, target_dim_step2, use_nearest=True
                            )
                            # Pad to square for fair comparison (same transform as GT)
                            mask_for_comparison = pad_mask_to_square(mask_scaled, target_dim_step2)

                            # Compute AR error (using pre-padding aspect ratios)
                            mask_crop_h, mask_crop_w = mask_cropped.shape[:2]
                            if mask_crop_h > 0 and mask_crop_w > 0:
                                render_aspect = mask_crop_w / mask_crop_h
                                ar_error = abs(render_aspect - gt_crop_aspect_step2)
                            else:
                                ar_error = 999.0
                        else:
                            # No crop: use native resolution mask directly
                            mask_for_comparison = mask_native

                            # Compute AR from native mask bbox
                            opaque = np.argwhere(mask_native > calib_config.edge_threshold)
                            if len(opaque) > 0:
                                y_min, x_min = opaque.min(axis=0)
                                y_max, x_max = opaque.max(axis=0)
                                bbox_w = x_max - x_min + 1
                                bbox_h = y_max - y_min + 1
                                render_aspect = bbox_w / bbox_h if bbox_h > 0 else 1.0
                                ar_error = abs(render_aspect - gt_crop_aspect_step2)
                            else:
                                ar_error = 999.0

                        # Compute IoU against GT
                        iou_val = iou(gt_for_step2, mask_for_comparison)

                        # Compute mask area
                        area = np.sum(mask_for_comparison > calib_config.edge_threshold)

                        coarse_candidates_step2.append((yaw, elev, iou_val, area, ar_error, mask_for_comparison))

                # Select 1 best pose using Step 2 selection criterion
                print(f"[DEBUG] Calling select_poses_by_criterion with {len(coarse_candidates_step2)} candidates...")
                import sys
                sys.stdout.flush()
                selected_step2 = self.prerender.select_poses_by_criterion(
                    coarse_candidates_step2,
                    num_candidates=1,  # Find exactly 1 pose
                    criterion=calib_config.step2_selection_criterion,
                    initial_top_fraction=calib_config.tri_criterion_initial_top_fraction,
                    step_fraction=calib_config.tri_criterion_step_fraction,
                    gt_aspect=gt_crop_aspect_step2,  # Use cropped GT aspect ratio
                    iou_ar_top_fraction=calib_config.iou_ar_top_fraction,
                    label=f"Step2_iter{iter_num}"
                )
                print(f"[DEBUG] select_poses_by_criterion returned successfully!")
                sys.stdout.flush()

                if not selected_step2:
                    print(f"[ERROR] {item_id}: No pose found in step 2 iteration {iter_num}")
                    return None

                best_step2 = selected_step2[0]
                yaw_step2, elev_step2, iou_step2, area_step2, ar_step2, mask_step2 = best_step2
                print(f"  Best pose: yaw={yaw_step2:.1f}deg, elev={elev_step2:.1f}deg, "
                      f"IoU={iou_step2:.3f}, Area={area_step2}, AR_err={ar_step2:.4f} ({time.time() - stage_start:.1f}s)")
                print(f"{'-'*80}\n")
                log_lines.append(f"STEP 2 (iter {iter_num}/{num_coarse_iterations}): Found best pose yaw={yaw_step2:.1f}, elev={elev_step2:.1f}, IoU={iou_step2:.3f}, AR_err={ar_step2:.4f}")

                # Save debug visualization for step 2 best (if enabled)
                # Use padded GT (same transform as render masks)
                if self.config.objective.objective2.debug_save_images:
                    debug_dir = output_dir / "debug_steps"
                    debug_dir.mkdir(exist_ok=True, parents=True)
                    save_render_with_bbox_visualization(
                        mask_step2,
                        debug_dir / f"step2_iter{iter_num}_best_yaw{yaw_step2:.1f}_elev{elev_step2:.1f}.png",
                        edge_threshold=calib_config.edge_threshold,
                        bbox_color="green",
                        yaw=yaw_step2,
                        elev=elev_step2,
                        iou=iou_step2,
                        area=area_step2,
                        ar_error=ar_step2,
                        gt_mask=gt_for_step2  # Show padded GT side-by-side (same transform as render)
                    )

                # Save top 15 candidates by each metric if debug enabled (from step 2 search)
                if self.config.objective.objective2.debug_save_top_candidates:
                    debug_dir = output_dir / "debug_candidates" / f"step2_iter{iter_num}"
                    debug_dir.mkdir(exist_ok=True, parents=True)

                    # Sort by each metric and save top 15
                    # IoU: higher is better
                    top_by_iou = sorted(coarse_candidates_step2, key=lambda x: x[2], reverse=True)[:15]
                    for i, (yaw, elev, iou_val, area, ar_err, mask) in enumerate(top_by_iou):
                        filename = f"iou_{i+1:02d}_yaw{yaw:05.1f}_elev{elev:04.1f}_iou{iou_val:.3f}_area{area:.0f}_ar{ar_err:.4f}.png"
                        save_render_with_bbox_visualization(
                            mask, debug_dir / filename,
                            edge_threshold=calib_config.edge_threshold,
                            bbox_color="green",
                            yaw=yaw, elev=elev, iou=iou_val, area=area, ar_error=ar_err,
                            gt_mask=gt_for_step2
                        )

                    # Area: higher is better
                    top_by_area = sorted(coarse_candidates_step2, key=lambda x: x[3], reverse=True)[:15]
                    for i, (yaw, elev, iou_val, area, ar_err, mask) in enumerate(top_by_area):
                        filename = f"area_{i+1:02d}_yaw{yaw:05.1f}_elev{elev:04.1f}_iou{iou_val:.3f}_area{area:.0f}_ar{ar_err:.4f}.png"
                        save_render_with_bbox_visualization(
                            mask, debug_dir / filename,
                            edge_threshold=calib_config.edge_threshold,
                            bbox_color="blue",
                            yaw=yaw, elev=elev, iou=iou_val, area=area, ar_error=ar_err,
                            gt_mask=gt_for_step2
                        )

                    # AR: lower error is better
                    top_by_ar = sorted(coarse_candidates_step2, key=lambda x: x[4])[:15]
                    for i, (yaw, elev, iou_val, area, ar_err, mask) in enumerate(top_by_ar):
                        filename = f"ar_{i+1:02d}_yaw{yaw:05.1f}_elev{elev:04.1f}_iou{iou_val:.3f}_area{area:.0f}_ar{ar_err:.4f}.png"
                        save_render_with_bbox_visualization(
                            mask, debug_dir / filename,
                            edge_threshold=calib_config.edge_threshold,
                            bbox_color="yellow",
                            yaw=yaw, elev=elev, iou=iou_val, area=area, ar_error=ar_err,
                            gt_mask=gt_for_step2
                        )

                    print(f"  Saved top 15 step2 iter{iter_num} candidates by IoU, Area, and AR to {debug_dir}")

                # Step 3: Radius adjustment at best pose from step 2
                print(f"\n{'-'*80}")
                print(f"{item_id}: STEP 3 (iter {iter_num}/{num_coarse_iterations}) - Radius Adjustment at Best Pose")
                print(f"{'-'*80}")
                stage_start = time.time()

                # Clean up renderer state after loop before radius adjustment
                self.prerender.renderer.cleanup_scene()

                prev_radius = current_radius
                current_radius, _ = self.prerender._ensure_radius_has_border(
                    glb_path, current_radius, yaw_step2, elev_step2,
                    fov, calib_config, self.prerender.renderer,
                    label=f"Step3_iter{iter_num}",
                    margin_fraction=calib_config.intermediate_border_safety_margin_fraction,
                    debug_dir=debug_border_dir
                )
                print(f"  Radius: {prev_radius:.3f} -> {current_radius:.3f} ({time.time() - stage_start:.1f}s)")
                print(f"{'-'*80}\n")
                log_lines.append(f"STEP 3 (iter {iter_num}/{num_coarse_iterations}): Radius adjusted {prev_radius:.3f} -> {current_radius:.3f}")

            # After all step 2+3 iterations, use final radius for step 4+5 iterations
            adjusted_radius_step3 = current_radius

            # Extract GT paths and RGB (needed for Steps 6 and 8, moved here before step4+5 loop)
            _, gt_path_first, gt_rgb_first, _, _, _ = gt_images[0]

            # Step 4 + Step 5 iterations (candidate selection + radius adjustment)
            num_step4_5_iterations = calib_config.step4_5_iterations
            current_radius_step4 = adjusted_radius_step3

            # Initialize reference pose for Step 4 iterations (starts from Step 3 best)
            # This gets updated at the end of each Step 4 iteration
            ref_yaw_step4 = yaw_step2
            ref_elev_step4 = elev_step2

            # Accumulate best candidates from all Step 4 iterations
            # Each entry: (yaw, elev, iou, area, ar_error, mask, iteration, radius_at_iteration)
            all_step4_best_candidates = []

            for iter_num_step4 in range(1, num_step4_5_iterations + 1):
                # Step 4: Final candidate selection (15 poses, optionally WITH exact crop + padding, MASK ONLY)
                crop_enabled = calib_config.step4_crop_enabled
                crop_mode_str = "with exact crop" if crop_enabled else "at native resolution"
                print(f"\n{'-'*80}")
                print(f"{item_id}: STEP 4 (iter {iter_num_step4}/{num_step4_5_iterations}) - Final Candidate Selection (15 Poses, {crop_mode_str})")
                print(f"{'-'*80}")
                stage_start = time.time()

                # Clean up renderer state before search
                self.prerender.renderer.cleanup_scene()

                # GT square dimensions already defined earlier (line 352)
                # gt_square_h, gt_square_w = gt_mask_first.shape

                # Resize GT to native render resolution for comparison
                from PIL import Image
                gt_native = np.array(Image.fromarray(gt_mask_first).resize(
                    (calib_config.pose_estimation_resolution, calib_config.pose_estimation_resolution),
                    Image.Resampling.LANCZOS
                ))

                # Compute GT aspect at native resolution (needed for AR comparison)
                gt_opaque_native = np.argwhere(gt_native > calib_config.edge_threshold)
                if len(gt_opaque_native) > 0:
                    gt_y_min_native, gt_x_min_native = gt_opaque_native.min(axis=0)
                    gt_y_max_native, gt_x_max_native = gt_opaque_native.max(axis=0)
                    gt_bbox_w_native = gt_x_max_native - gt_x_min_native + 1
                    gt_bbox_h_native = gt_y_max_native - gt_y_min_native + 1
                    gt_aspect_native = gt_bbox_w_native / gt_bbox_h_native if gt_bbox_h_native > 0 else 1.0
                else:
                    gt_aspect_native = 1.0

                # Step 4 search mode: coarse (full range) or fine (local search)
                step4_search_mode = calib_config.step4_search_mode
                if step4_search_mode == "fine":
                    # Fine search: use fine search parameters around reference pose
                    # Iteration 1: reference = Step 3 best, Iteration 2+: reference = previous Step 4 best
                    ref_source = "Step 3" if iter_num_step4 == 1 else f"Step 4 iter {iter_num_step4-1}"
                    print(f"  Step 4 search mode: FINE (local search around {ref_source} best pose)")
                    print(f"  Reference pose: yaw={ref_yaw_step4:.1f}deg, elev={ref_elev_step4:.1f}deg")

                    # Yaw fine search
                    yaw_fine_step = calib_config.yaw_search_fine_step
                    yaw_fine_range = calib_config.yaw_search_fine_range
                    yaw_start_step4 = max(0.0, ref_yaw_step4 - yaw_fine_range)
                    yaw_stop_step4 = min(360.0, ref_yaw_step4 + yaw_fine_range)
                    yaw_step_step4 = yaw_fine_step

                    # Elevation fine search
                    elev_fine_step = calib_config.elevation_search_fine_step
                    elev_fine_range = calib_config.elevation_search_fine_range
                    elev_start_step4 = max(calib_config.elevation_search_start, ref_elev_step4 - elev_fine_range)
                    elev_stop_step4 = min(calib_config.elevation_search_stop, ref_elev_step4 + elev_fine_range)
                    elev_step_step4 = elev_fine_step

                    print(f"  Yaw range: [{yaw_start_step4:.1f}, {yaw_stop_step4:.1f}] deg, step={yaw_step_step4:.1f} deg")
                    print(f"  Elevation range: [{elev_start_step4:.1f}, {elev_stop_step4:.1f}] deg, step={elev_step_step4:.1f} deg")
                else:
                    # Coarse search: use full range parameters
                    print(f"  Step 4 search mode: COARSE (full range)")
                    yaw_start_step4 = yaw_start
                    yaw_stop_step4 = yaw_stop
                    yaw_step_step4 = yaw_step
                    elev_start_step4 = elev_start
                    elev_stop_step4 = elev_stop
                    elev_step_step4 = elev_step

                # Pre-crop GT once before the loop (if crop enabled)
                # crop_enabled already defined above for print statement
                target_dim_step4 = calib_config.pose_estimation_resolution
                if crop_enabled:
                    # Crop GT to its tight bbox (done once, not per-candidate)
                    gt_rgb_for_crop = np.stack([gt_native] * 3, axis=-1)
                    _, gt_cropped_step4, _ = exact_crop_to_bbox(
                        gt_rgb_for_crop,
                        gt_native,
                        edge_threshold=calib_config.edge_threshold,
                        border_px=0
                    )
                    # Compute GT crop aspect ratio (before padding)
                    gt_crop_h, gt_crop_w = gt_cropped_step4.shape[:2]
                    gt_crop_aspect_step4 = gt_crop_w / gt_crop_h if gt_crop_h > 0 else 1.0

                    # Scale GT crop so longest side = target_dim
                    gt_scaled_step4 = scale_to_target_dimension(
                        gt_cropped_step4, target_dim_step4, use_nearest=False
                    )
                    # Pad to square (target_dim x target_dim) for fair comparison
                    gt_padded_step4 = pad_mask_to_square(gt_scaled_step4, target_dim_step4)

                coarse_candidates_step4 = []
                for yaw in np.arange(yaw_start_step4, yaw_stop_step4, yaw_step_step4):
                    for elev in np.arange(elev_start_step4, elev_stop_step4, elev_step_step4):
                        # Render MASK ONLY at native resolution
                        mask_native = self.prerender.renderer.render_mask(
                            glb_path, 0.0, elev, current_radius_step4, fov, yaw, fast=False, coarse=True
                        )

                        if crop_enabled:
                            # Step 4 crop workflow (with square padding):
                            # 1. Render at native resolution (256px)
                            # 2. Crop render to bounding box
                            # 3. Scale render crop so longest side = pose_estimation_resolution
                            # 4. Pad to square (256x256) for fair comparison and debug
                            # 5. Compare against pre-cropped+padded GT (done once before loop)

                            # Crop render to tight bbox
                            mask_rgb = np.stack([mask_native] * 3, axis=-1)
                            _, mask_cropped, _ = exact_crop_to_bbox(
                                mask_rgb,
                                mask_native,
                                edge_threshold=calib_config.edge_threshold,
                                border_px=0
                            )

                            # Scale render crop so longest side = target_dim
                            mask_scaled = scale_to_target_dimension(
                                mask_cropped, target_dim_step4, use_nearest=True
                            )

                            # Pad to square for fair comparison (same transform as GT)
                            mask_padded = pad_mask_to_square(mask_scaled, target_dim_step4)

                            # Use padded versions for comparison (both 256x256 square)
                            mask_for_comparison = mask_padded
                            gt_for_comparison = gt_padded_step4
                            comparison_aspect = gt_crop_aspect_step4
                        else:
                            # No crop: compare at native resolution directly
                            mask_for_comparison = mask_native
                            gt_for_comparison = gt_native
                            comparison_aspect = gt_aspect_native

                        # Compute metrics
                        iou_val = iou(gt_for_comparison, mask_for_comparison)
                        area = np.sum(mask_for_comparison > calib_config.edge_threshold)

                        # Compute AR error
                        opaque = np.argwhere(mask_for_comparison > calib_config.edge_threshold)
                        if len(opaque) > 0:
                            y_min, x_min = opaque.min(axis=0)
                            y_max, x_max = opaque.max(axis=0)
                            render_w = x_max - x_min + 1
                            render_h = y_max - y_min + 1
                            render_aspect = render_w / render_h if render_h > 0 else 1.0
                            ar_error = abs(render_aspect - comparison_aspect)
                        else:
                            ar_error = 999.0

                        coarse_candidates_step4.append((yaw, elev, iou_val, area, ar_error, mask_for_comparison))

                # Select candidates using Step 4 selection criterion
                selected_step4 = self.prerender.select_poses_by_criterion(
                    coarse_candidates_step4,
                    num_candidates=calib_config.tri_criterion_num_candidates,
                    criterion=calib_config.step4_selection_criterion,
                    initial_top_fraction=calib_config.tri_criterion_initial_top_fraction,
                    step_fraction=calib_config.tri_criterion_step_fraction,
                    gt_aspect=gt_aspect,
                    iou_ar_top_fraction=calib_config.iou_ar_top_fraction,
                    label="Step4"
                )

                if not selected_step4:
                    print(f"[ERROR] {item_id}: No candidates found in step 4")
                    return None

                best_step4 = selected_step4[0]
                yaw_best, elev_best, iou_best, area_best, ar_best, mask_best = best_step4
                print(f"  Selected {len(selected_step4)} candidates, best: yaw={yaw_best:.1f}deg, elev={elev_best:.1f}deg, "
                      f"IoU={iou_best:.3f}, Area={area_best}, AR_err={ar_best:.4f} ({time.time() - stage_start:.1f}s)")
                print(f"{'-'*80}\n")
                log_lines.append(f"STEP 4 (iter {iter_num_step4}): Selected {len(selected_step4)} candidates, best IoU={iou_best:.3f}")

                # Accumulate this iteration's best candidate (with iteration number and radius)
                all_step4_best_candidates.append((
                    yaw_best, elev_best, iou_best, area_best, ar_best, mask_best,
                    iter_num_step4, current_radius_step4
                ))

                # Save debug visualization for step 4 best (if enabled)
                # Use padded GT when crop is enabled (same transform as render masks)
                gt_for_debug_step4 = gt_padded_step4 if crop_enabled else gt_native
                if self.config.objective.objective2.debug_save_images:
                    debug_dir = output_dir / "debug_steps"
                    debug_dir.mkdir(exist_ok=True, parents=True)
                    save_render_with_bbox_visualization(
                        mask_best,
                        debug_dir / f"step4_iter{iter_num_step4}_best_yaw{yaw_best:.1f}_elev{elev_best:.1f}.png",
                        edge_threshold=calib_config.edge_threshold,
                        bbox_color="cyan",
                        yaw=yaw_best,
                        elev=elev_best,
                        iou=iou_best,
                        area=area_best,
                        ar_error=ar_best,
                        gt_mask=gt_for_debug_step4  # Show padded GT side-by-side (same transform as render)
                    )

                # Save top 15 candidates by each metric if debug enabled (from step 4 search)
                if self.config.objective.objective2.debug_save_top_candidates:
                    debug_dir = output_dir / "debug_candidates" / f"step4_iter{iter_num_step4}"
                    debug_dir.mkdir(exist_ok=True, parents=True)

                    # Use the same GT as metrics (padded to square when crop enabled)
                    gt_for_visualization = gt_for_debug_step4

                    # Sort by each metric and save top 15
                    # IoU: higher is better
                    top_by_iou = sorted(coarse_candidates_step4, key=lambda x: x[2], reverse=True)[:15]
                    for i, (yaw, elev, iou_val, area, ar_err, mask) in enumerate(top_by_iou):
                        filename = f"iou_{i+1:02d}_yaw{yaw:05.1f}_elev{elev:04.1f}_iou{iou_val:.3f}_area{area:.0f}_ar{ar_err:.4f}.png"
                        save_render_with_bbox_visualization(
                            mask, debug_dir / filename,
                            edge_threshold=calib_config.edge_threshold,
                            bbox_color="cyan",
                            yaw=yaw, elev=elev, iou=iou_val, area=area, ar_error=ar_err,
                            gt_mask=gt_for_visualization
                        )

                    # Area: higher is better
                    top_by_area = sorted(coarse_candidates_step4, key=lambda x: x[3], reverse=True)[:15]
                    for i, (yaw, elev, iou_val, area, ar_err, mask) in enumerate(top_by_area):
                        filename = f"area_{i+1:02d}_yaw{yaw:05.1f}_elev{elev:04.1f}_iou{iou_val:.3f}_area{area:.0f}_ar{ar_err:.4f}.png"
                        save_render_with_bbox_visualization(
                            mask, debug_dir / filename,
                            edge_threshold=calib_config.edge_threshold,
                            bbox_color="magenta",
                            yaw=yaw, elev=elev, iou=iou_val, area=area, ar_error=ar_err,
                            gt_mask=gt_for_visualization
                        )

                    # AR: lower error is better
                    top_by_ar = sorted(coarse_candidates_step4, key=lambda x: x[4])[:15]
                    for i, (yaw, elev, iou_val, area, ar_err, mask) in enumerate(top_by_ar):
                        filename = f"ar_{i+1:02d}_yaw{yaw:05.1f}_elev{elev:04.1f}_iou{iou_val:.3f}_area{area:.0f}_ar{ar_err:.4f}.png"
                        save_render_with_bbox_visualization(
                            mask, debug_dir / filename,
                            edge_threshold=calib_config.edge_threshold,
                            bbox_color="orange",
                            yaw=yaw, elev=elev, iou=iou_val, area=area, ar_error=ar_err,
                            gt_mask=gt_for_visualization
                        )

                    print(f"  Saved top 15 step4 candidates by IoU, Area, and AR to {debug_dir}")

                # Step 5: Radius adjustment at best Step 4 pose (intermediate iterations only)
                # Final Step 5 will be run after all iterations using overall best candidate
                if iter_num_step4 < num_step4_5_iterations:
                    print(f"\n{'-'*80}")
                    print(f"{item_id}: STEP 5 (iter {iter_num_step4}/{num_step4_5_iterations}) - Radius Adjustment at Best Step 4 Pose")
                    print(f"{'-'*80}")
                    stage_start = time.time()

                    # Use the best candidate from this Step 4 iteration for radius adjustment
                    yaw_step4_best, elev_step4_best, iou_step4_best, area_step4_best, ar_step4_best, _ = best_step4

                    print(f"  Adjusting radius at Step 4 iter {iter_num_step4} best pose: yaw={yaw_step4_best:.1f}deg, elev={elev_step4_best:.1f}deg")

                    # Perform radius adjustment (border-based adjustment like Step 3)
                    step5_margin = calib_config.step5_border_safety_margin_fraction
                    print(f"  Border safety margin: {step5_margin*100:.1f}%")

                    # Clean up renderer before radius adjustment
                    self.prerender.renderer.cleanup_scene()

                    adjusted_radius_step5, step5_converged = self.prerender._ensure_radius_has_border(
                        glb_path, current_radius_step4,
                        yaw=yaw_step4_best, elevation=elev_step4_best, fov=fov,
                        calib_config=calib_config, calib_renderer=self.prerender.renderer,
                        label="  ",
                        margin_fraction=step5_margin
                    )

                    radius_change = adjusted_radius_step5 - current_radius_step4
                    radius_change_pct = (radius_change / current_radius_step4) * 100 if current_radius_step4 > 0 else 0

                    print(f"  Step 5 complete: radius {current_radius_step4:.4f} -> {adjusted_radius_step5:.4f} "
                          f"(change: {radius_change:+.4f}, {radius_change_pct:+.2f}%) ({time.time() - stage_start:.1f}s)")
                    print(f"{'-'*80}\n")
                    log_lines.append(f"STEP 5 (iter {iter_num_step4}): Radius adjustment {current_radius_step4:.4f} -> {adjusted_radius_step5:.4f}")

                    # Update radius for next iteration
                    current_radius_step4 = adjusted_radius_step5

                    # Update reference pose for next iteration (Step 4 iter 2+ will search around this)
                    ref_yaw_step4 = yaw_step4_best
                    ref_elev_step4 = elev_step4_best

            # After all Step 4 iterations, select overall best candidate from all iterations
            # Sort by IoU (descending) to find the best across all iterations
            all_step4_best_candidates_sorted = sorted(all_step4_best_candidates, key=lambda x: x[2], reverse=True)
            overall_best = all_step4_best_candidates_sorted[0]
            overall_yaw, overall_elev, overall_iou, overall_area, overall_ar, overall_mask, overall_iter, overall_radius = overall_best

            print(f"\n{'='*80}")
            print(f"{item_id}: OVERALL BEST from {num_step4_5_iterations} Step 4 iterations")
            print(f"{'='*80}")
            print(f"  Best candidate from iteration {overall_iter}: yaw={overall_yaw:.1f}deg, elev={overall_elev:.1f}deg")
            print(f"  IoU={overall_iou:.3f}, Area={overall_area}, AR_err={overall_ar:.4f}")
            print(f"  Radius at that iteration: {overall_radius:.4f}")

            # Update best_step4 to be the overall best (for use in Step 6+)
            best_step4 = (overall_yaw, overall_elev, overall_iou, overall_area, overall_ar, overall_mask)

            # Final Step 5: Radius adjustment at overall best pose
            print(f"\n{'-'*80}")
            print(f"{item_id}: STEP 5 (FINAL) - Radius Adjustment at Overall Best Pose")
            print(f"{'-'*80}")
            stage_start = time.time()

            print(f"  Adjusting radius at overall best pose: yaw={overall_yaw:.1f}deg, elev={overall_elev:.1f}deg")

            step5_margin = calib_config.step5_border_safety_margin_fraction
            print(f"  Border safety margin: {step5_margin*100:.1f}%")

            # Clean up renderer before radius adjustment
            self.prerender.renderer.cleanup_scene()

            adjusted_radius_step5, step5_converged = self.prerender._ensure_radius_has_border(
                glb_path, current_radius_step4,
                yaw=overall_yaw, elevation=overall_elev, fov=fov,
                calib_config=calib_config, calib_renderer=self.prerender.renderer,
                label="  ",
                margin_fraction=step5_margin
            )

            radius_change = adjusted_radius_step5 - current_radius_step4
            radius_change_pct = (radius_change / current_radius_step4) * 100 if current_radius_step4 > 0 else 0

            print(f"  Step 5 FINAL complete: radius {current_radius_step4:.4f} -> {adjusted_radius_step5:.4f} "
                  f"(change: {radius_change:+.4f}, {radius_change_pct:+.2f}%) ({time.time() - stage_start:.1f}s)")
            print(f"{'-'*80}\n")
            log_lines.append(f"STEP 5 (FINAL): Overall best from iter {overall_iter}, radius {current_radius_step4:.4f} -> {adjusted_radius_step5:.4f}")

            # Use final adjusted radius
            adjusted_radius_final = adjusted_radius_step5

            # Step 6: RGB rendering + LPIPS scoring of selected candidates (optional, renamed from old Step 5)
            if calib_config.step6_lpips_enabled:
                print(f"\n{'-'*80}")
                print(f"{item_id}: STEP 6 - RGB Rendering + LPIPS Scoring ({len(selected_step4)} candidates)")
                print(f"{'-'*80}")
                stage_start = time.time()

                # Clean up renderer state before RGB rendering
                self.prerender.renderer.cleanup_scene()

                # Render RGB for the selected candidates only (much faster than all poses)
                # Apply exact crop + padding to match GT dimensions
                candidate_rgb_cropped = []

                for yaw_cand, elev_cand, _, _, _, _ in selected_step4:
                    rgb = self.prerender.renderer.render_rgb(
                        glb_path, 0.0, elev_cand, adjusted_radius_step3, fov, yaw_cand,
                        fast=True, coarse=False, unlit=True
                    )
                    mask = self.prerender.renderer.render_mask(
                        glb_path, 0.0, elev_cand, adjusted_radius_step3, fov, yaw_cand,
                        fast=True, coarse=False
                    )
                    # Exact crop + pad
                    rgb_cropped = exact_crop_and_pad_to_gt(
                        rgb, mask, gt_square_w, gt_square_h,
                        edge_threshold=calib_config.edge_threshold,
                        border_px=0,
                        background_rgb=(0, 0, 0)
                    )
                    candidate_rgb_cropped.append(rgb_cropped)

                # Batch LPIPS scoring
                lpips_distances = compute_lpips_batch(
                    gt_rgb_first,
                    candidate_rgb_cropped,
                    model=self.config.objective.lpips.model,
                    device=self.config.objective.lpips.device,
                    background_rgb=[0, 0, 0]
                )

                best_lpips_idx = int(np.argmin(lpips_distances))
                best_lpips_distance = lpips_distances[best_lpips_idx]
                best_pose_data = selected_step4[best_lpips_idx]
                yaw_best_lpips, elev_best_lpips, iou_best_lpips, area_best_lpips, ar_best_lpips, _ = best_pose_data

                print(f"  Best LPIPS candidate #{best_lpips_idx+1}: yaw={yaw_best_lpips:.1f}deg, elev={elev_best_lpips:.1f}deg, "
                      f"LPIPS={best_lpips_distance:.4f} ({time.time() - stage_start:.1f}s)")
                log_lines.append(f"STEP 6: RGB rendered {len(selected_step4)} candidates, best LPIPS={best_lpips_distance:.4f}")

                # Clean up renderer state after RGB rendering + LPIPS scoring
                self.prerender.renderer.cleanup_scene()
            else:
                # LPIPS disabled: use best candidate from Step 4 directly
                print(f"\n{'-'*80}")
                print(f"{item_id}: STEP 6 - LPIPS Scoring DISABLED (using best Step 4 candidate)")
                print(f"{'-'*80}")

                yaw_best_lpips, elev_best_lpips, iou_best_lpips, area_best_lpips, ar_best_lpips, _ = best_step4
                best_lpips_distance = None  # No LPIPS score
                best_lpips_idx = 0  # Using first candidate (best_step4) when LPIPS disabled

                print(f"  Using Step 4 best: yaw={yaw_best_lpips:.1f}deg, elev={elev_best_lpips:.1f}deg, "
                      f"IoU={iou_best_lpips:.3f}, area={area_best_lpips:.0f}px, AR_err={ar_best_lpips:.4f}")
                log_lines.append(f"STEP 6: LPIPS scoring disabled, using Step 4 best candidate")

            # Step 7: HQ render of best pose (always render, no gates)
            print(f"\n{'-'*80}")
            print(f"{item_id}: STEP 7 - HQ Rendering Best Pose")
            print(f"{'-'*80}")
            stage_start = time.time()

            # Clean up renderer state before HQ render
            self.prerender.renderer.cleanup_scene()

            final_params = {
                "azimuth_deg": 0.0,
                "elevation_deg": elev_best_lpips,
                "radius": adjusted_radius_step3,
                "fov_deg": fov,
                "obj_yaw_deg": yaw_best_lpips
            }

            # Determine HQ render mode
            hq_render_mode = self.config.objective.objective2.hq_render_mode
            exact_crop_dimensions = None

            if hq_render_mode == "exact_crop" and selected_only:
                # Use exact crop dimensions from selected GT metadata
                gt_data_first = gt_images[0]
                gt_idx_first = gt_data_first[0]
                metadata_path = gt_dir / "metadata.json"
                if metadata_path.exists():
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        metadata = json.load(f)
                    for gt_entry in metadata.get("gts", []):
                        if gt_entry.get("gt_index") == gt_idx_first:
                            exact_dims = gt_entry.get("exact_dimensions")
                            if exact_dims:
                                exact_crop_dimensions = tuple(exact_dims)
                                break

            hq_render_path = output_dir / "hq_render_pyrender.png"
            success = render_hq_pyrender_cached(
                glb_path, final_params, hq_render_path, self.config,
                cache_manager, exact_crop_dimensions
            )

            if not success:
                print(f"[ERROR] {item_id}: HQ render failed")
                return None

            print(f"  HQ render complete ({time.time() - stage_start:.1f}s)")
            log_lines.append(f"STEP 7: HQ render complete, mode={hq_render_mode}")
            print(f"{'-'*80}\n")

            # Step 8: Final LPIPS scoring (HQ render vs GT)
            print(f"\n{'-'*80}")
            print(f"{item_id}: STEP 8 - Final LPIPS Scoring on HQ Render")
            print(f"{'-'*80}")
            stage_start = time.time()

            # Load GT exact crop image (if available, otherwise use square)
            if hq_render_mode == "exact_crop" and selected_only:
                gt_exact_path = gt_path_first.parent / gt_path_first.name.replace("_square.png", "_exact.png")
                if gt_exact_path.exists():
                    gt_for_lpips = gt_exact_path
                else:
                    gt_for_lpips = gt_path_first
            else:
                gt_for_lpips = gt_path_first

            # Load GT image to get target dimensions
            from PIL import Image
            gt_img = Image.open(gt_for_lpips)
            gt_width, gt_height = gt_img.size

            # Step 7 exact crop: crop HQ render to bbox before LPIPS comparison
            step7_exact_crop_enabled = self.config.objective.objective2.step7_exact_crop_enabled
            render_for_lpips = hq_render_path

            if step7_exact_crop_enabled:
                print(f"  Step 7 exact crop ENABLED: cropping HQ render to bbox before LPIPS comparison")

                # Load HQ render RGB and mask
                hq_render_rgb = np.array(Image.open(hq_render_path).convert("RGB"))

                # Render mask at HQ resolution to get bounding box
                hq_mask = self.prerender.renderer.render_mask(
                    glb_path, 0.0, elev_best_lpips, adjusted_radius_step3, fov, yaw_best_lpips,
                    fast=False, coarse=False
                )

                # Convert mask to match HQ render size
                hq_mask_resized = np.array(Image.fromarray(hq_mask).resize(
                    (hq_render_rgb.shape[1], hq_render_rgb.shape[0]),
                    Image.Resampling.LANCZOS
                ))

                # Crop render to bounding box (using module-level imports)
                hq_cropped_rgb, hq_cropped_mask, _ = exact_crop_to_bbox(
                    hq_render_rgb, hq_mask_resized,
                    edge_threshold=calib_config.edge_threshold
                )

                if hq_cropped_rgb is not None:
                    # Scale to max dimension 1024px
                    hq_scaled_rgb = scale_to_max_dimension(hq_cropped_rgb, max_dimension=1024)

                    # Center pad to match GT dimensions
                    hq_final_rgb = pad_to_dimensions(
                        hq_scaled_rgb, target_w=gt_width, target_h=gt_height,
                        background_rgb=(0, 0, 0)
                    )

                    # Save cropped render
                    render_for_lpips = output_dir / "hq_render_cropped.png"
                    Image.fromarray(hq_final_rgb).save(render_for_lpips)

                    crop_h, crop_w = hq_cropped_rgb.shape[:2]
                    final_h, final_w = hq_final_rgb.shape[:2]
                    print(f"    Cropped HQ render: {crop_h}x{crop_w}px -> scaled/padded to {final_w}x{final_h}px (GT size)")
                else:
                    print(f"    WARNING: Could not crop HQ render (empty mask), using original")
                    render_for_lpips = hq_render_path
            else:
                print(f"  Step 7 exact crop DISABLED: comparing full HQ render")

            lpips_distance = compute_lpips_cached(
                gt_for_lpips, render_for_lpips,
                model=self.config.objective.lpips.model,
                device=self.config.objective.lpips.device,
                normalize=self.config.objective.lpips.normalize,
                background_rgb=[0, 0, 0],
                debug_dir=output_dir / "lpips_debug",
                cache_manager=cache_manager
            )

            print(f"  Final LPIPS: {lpips_distance:.4f} ({time.time() - stage_start:.1f}s)")
            log_lines.append(f"STEP 8: Final LPIPS on HQ render={lpips_distance:.4f}")
            print(f"{'-'*80}\n")

            # Compute final score
            mask_error = 1.0 - iou_best_lpips
            pose_confidence = iou_best_lpips  # IoU as pose confidence (0-1, higher is better)
            final_score = combine_score(
                lpips_distance=lpips_distance,
                pose_confidence=pose_confidence,
                gamma=self.config.objective.combiner.gamma,
                pose_compensation_c=self.config.objective.combiner.pose_compensation_c
            )

            print(f"{item_id}: Final Score: {final_score:.2f} (LPIPS={lpips_distance:.4f}, IoU={iou_best_lpips:.3f})")
            log_lines.append(f"FINAL SCORE: {final_score:.2f} (LPIPS={lpips_distance:.4f}, IoU={iou_best_lpips:.3f})")

            # Save results
            total_time = time.time() - item_start_time
            log_lines.append(f"Total time: {total_time:.1f}s")
            log_lines.append("=" * 80)
            with open(main_log_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(log_lines))

            # Save final.json
            final_json = {
                "score": float(final_score),
                "lpips": float(lpips_distance),
                "iou": float(iou_best_lpips),
                "mask_error": float(mask_error),
                "params": final_params,
                "pipeline_mode": "tri_criterion",
                "num_step2_candidates": len(coarse_candidates_step2),
                "num_step4_candidates": len(coarse_candidates_step4),
                "num_selected_candidates": len(selected_step4),
                "best_lpips_idx": best_lpips_idx,
                "time_seconds": total_time
            }

            final_path = output_dir / "final.json"
            with open(final_path, 'w', encoding='utf-8') as f:
                json.dump(final_json, f, indent=2)

            # Export scoring artifacts for GT/HQ pair visualization
            self._export_scoring_artifacts(
                output_dir=output_dir,
                gt_path=Path(gt_for_lpips),
                render_path=Path(render_for_lpips)
            )

            return final_json

        elif skip_library:
            # AR-BASED PIPELINE: Skip library, use calibrated pose directly
            print(f"{item_id}: STAGE 2 - Calibrating radius with AR-based orientation search (skipping library)...")
            stage_start = time.time()

            library_dir = output_dir / "calibration"
            library_dir.mkdir(parents=True, exist_ok=True)

            calibrated_radius, calibrated_pose = self.prerender.calibrate_radius(
                glb_path=glb_path,
                gt_mask=gt_mask_first,
                initial_radius=self.config.render.camera.radius,
                calib_config=calib_config,
                output_dir=library_dir
            )

            stage_time = time.time() - stage_start
            print(f"  Radius calibrated: {self.config.render.camera.radius:.3f} -> {calibrated_radius:.3f}")

            # Display AR error and IoU (if IoU filtering was enabled)
            if calibrated_pose.get('iou') is not None:
                print(f"  Pose calibrated: yaw={calibrated_pose['yaw_deg']:.1f}deg, "
                      f"elev={calibrated_pose['elevation_deg']:.1f}deg, "
                      f"AR_error={calibrated_pose['ar_error']:.4f}, IoU={calibrated_pose['iou']:.3f} ({stage_time:.1f}s)")
                log_lines.append(f"STAGE 2: Radius calibrated from {self.config.render.camera.radius:.3f} to {calibrated_radius:.3f} (AR+IoU hybrid)")
                log_lines.append(f"STAGE 2: Pose calibrated yaw={calibrated_pose['yaw_deg']:.1f}deg, elev={calibrated_pose['elevation_deg']:.1f}deg, AR_error={calibrated_pose['ar_error']:.4f}, IoU={calibrated_pose['iou']:.3f} ({stage_time:.1f}s)")
            else:
                print(f"  Pose calibrated: yaw={calibrated_pose['yaw_deg']:.1f}deg, "
                      f"elev={calibrated_pose['elevation_deg']:.1f}deg, "
                      f"AR_error={calibrated_pose['ar_error']:.4f} ({stage_time:.1f}s)")
                log_lines.append(f"STAGE 2: Radius calibrated from {self.config.render.camera.radius:.3f} to {calibrated_radius:.3f} (AR-based, no library)")
                log_lines.append(f"STAGE 2: Pose calibrated yaw={calibrated_pose['yaw_deg']:.1f}deg, elev={calibrated_pose['elevation_deg']:.1f}deg, AR_error={calibrated_pose['ar_error']:.4f} ({stage_time:.1f}s)")

            # Use calibrated pose directly (skip Stage 3 matching)
            best_pose_dict = calibrated_pose
            best_pose = PrerenderPose(
                azimuth_deg=calibrated_pose['azimuth_deg'],
                elevation_deg=calibrated_pose['elevation_deg'],
                radius=calibrated_pose['radius'],
                fov_deg=calibrated_pose['fov_deg'],
                obj_yaw_deg=calibrated_pose['yaw_deg']  # Note: dict uses 'yaw_deg', PrerenderPose uses 'obj_yaw_deg'
            )
            best_gt_data = gt_images[0]  # Use first GT
            _, best_gt_path, best_gt_rgb, best_gt_mask, best_gt_edges, best_gt_dt = best_gt_data

            # Use IoU-based error if AR+IoU filtering was enabled, otherwise use AR error
            if calibrated_pose.get('iou') is not None:
                mask_error = 1.0 - calibrated_pose['iou']  # Convert IoU to error (0-1 range)
            else:
                mask_error = calibrated_pose['ar_error']  # Fallback to AR error

            print(f"{item_id}: STAGE 3 - Skipped (using calibrated pose directly)")
            log_lines.append(f"STAGE 3: Skipped (AR-based pipeline)")

        else:
            # IoU-BASED PIPELINE: Generate library and match
            library_dir = output_dir / "prerender_library"
            print(f"{item_id}: STAGE 2 - Calibrating radius and generating library...")
            stage_start = time.time()

            # The generate_full_library does both radius calibration and library rendering
            # Pass calibration config for improved accuracy
            calibrated_radius, library_results = self.prerender.generate_full_library(
                glb_path=glb_path,
                gt_mask=gt_mask_first,
                output_dir=library_dir,
                initial_radius=self.config.render.camera.radius,
                calib_config=calib_config
            )

            stage_time = time.time() - stage_start
            radius_multipliers = self.config.objective.objective2.library.radius_multipliers
            multipliers_str = "/".join([f"{m:.2f}x" for m in radius_multipliers])
            print(f"  Radius calibrated: {self.config.render.camera.radius:.3f} -> {calibrated_radius:.3f}")
            print(f"  Library generated: {len(library_results)} poses "
                f"(base radius: {calibrated_radius:.3f}, using {multipliers_str} multipliers) ({stage_time:.1f}s)")
            log_lines.append(f"STAGE 2: Radius calibrated from {self.config.render.camera.radius:.3f} to {calibrated_radius:.3f}")
            log_lines.append(f"STAGE 2: Generated {len(library_results)} poses, base_radius={calibrated_radius:.3f} ({multipliers_str} multipliers) ({stage_time:.1f}s)")

            # Stage 3: Match all GT images against library
            print(f"{item_id}: STAGE 3 - Matching GT images against library...")
            stage_start = time.time()
            library_loaded = self.matcher.load_library(library_dir)

            match_dir = output_dir / "matching"
            match_dir.mkdir(parents=True, exist_ok=True)

            top_matches = self.matcher.match_all_pairs(
                gt_images=gt_images,
                library=library_loaded,
                output_dir=match_dir,
                top_k=10
            )

            if not top_matches:
                print(f"[ERROR] {item_id}: No matches found")
                return None

            # Get best match
            best_match = top_matches[0]
            stage_time = time.time() - stage_start
            print(f"{item_id}: Best match found - "
                f"GT#{best_match.gt_index+1}, Lib#{best_match.lib_index}, "
                f"IoU={best_match.iou:.3f}, Error={best_match.combined_error:.4f} ({stage_time:.1f}s)")
            log_lines.append(f"STAGE 3: Best match GT#{best_match.gt_index+1}, Lib#{best_match.lib_index}, IoU={best_match.iou:.3f}, error={best_match.combined_error:.4f} ({stage_time:.1f}s)")

            # Get pose and GT data from best match
            best_lib_entry = [l for l in library_loaded if l[0] == best_match.lib_index][0]
            # CRITICAL FIX: After dropping RGB, tuple format changed from 7 to 5 elements
            # OLD: (idx, rgb_path, mask_path, rgb, mask, edges, pose_dict) - pose_dict at [6]
            # NEW: (idx, mask_path, mask, edges, pose_dict) - pose_dict at [4]
            best_pose_dict = best_lib_entry[4]  # pose_dict
            best_pose = PrerenderPose.from_dict(best_pose_dict)

            # Get best GT data for refinement
            best_gt_data = [g for g in gt_images if g[0] == best_match.gt_index][0]
            _, best_gt_path, best_gt_rgb, best_gt_mask, best_gt_edges, best_gt_dt = best_gt_data
            mask_error = best_match.combined_error  # Use library match error

            # ERROR GATE 1: Check refinement error threshold (IoU mode only)
            refinement_threshold = self.config.objective.refinement_error_threshold
            if best_match.combined_error >= refinement_threshold:
                print(f"[ERROR] {item_id}: Match error {best_match.combined_error:.4f} >= "
                    f"{refinement_threshold} threshold - skipping refinement and HQ render")
                log_lines.append(
                    f"FAILED: Match error {best_match.combined_error:.4f} >= "
                    f"{refinement_threshold} refinement threshold"
                )
                log_lines.append(f"Total time: {time.time() - item_start_time:.1f}s")
                log_lines.append("=" * 80)
                with open(main_log_file, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(log_lines))
                self._mark_failed(output_dir, reason="match_error_too_high")
                return None

        # Check if refinement is disabled in config
        ref_cfg = self.config.objective.objective2.refinement
        if not ref_cfg.enabled:
            if skip_library:
                # AR mode: refinement disabled
                print(f"{item_id}: Refinement disabled in config - using calibrated pose directly")
                log_lines.append(f"Refinement disabled in config, using calibrated pose directly")
                refined_error = mask_error  # AR error
                iou_str = "N/A (computed post-HQ)"
            else:
                # IoU mode: refinement disabled
                print(f"{item_id}: Refinement disabled in config - using library pose directly")
                log_lines.append(f"Refinement disabled in config, using library pose directly")
                refined_error = best_match.combined_error
                iou_str = f"{best_match.iou:.3f}"

            # Use pose directly (common to both modes)
            refined_params = RefineParams(
                azimuth_deg=best_pose.azimuth_deg,
                elevation_deg=best_pose.elevation_deg,
                radius=best_pose.radius,
                fov_deg=best_pose.fov_deg,
                obj_yaw_deg=best_pose.obj_yaw_deg
            )
            refinement_metadata = {
                "skipped": True,
                "reason": "disabled_in_config",
                "initial_error": refined_error,
                "final_error": refined_error,
                "final_iou": best_match.iou if not skip_library else None,
                "iterations": 0,
                "success": True
            }
            stage_time = 0.0

            print(f"{item_id}: Using pose (error={refined_error:.4f}, IoU={iou_str})")
            log_lines.append(f"STAGE 4: Refinement disabled, using pose directly")
        # CRITICAL FIX: Skip refinement if library match is already very good
        # Research shows gradient descent on discretized objectives (IoU) often gets stuck
        # If library match has error < 0.15, refinement typically makes it worse
        # NOTE: This branch only applies to IoU mode (skip_library=False)
        elif not skip_library and best_match.combined_error < 0.15:
            skip_refinement_threshold = 0.15
            print(f"{item_id}: Match error {best_match.combined_error:.4f} < {skip_refinement_threshold} "
                f"(very good!) - skipping refinement, using library pose directly")
            log_lines.append(f"Refinement skipped: match error {best_match.combined_error:.4f} already excellent")

            # Use library pose directly
            refined_params = RefineParams(
                azimuth_deg=best_pose.azimuth_deg,
                elevation_deg=best_pose.elevation_deg,
                radius=best_pose.radius,
                fov_deg=best_pose.fov_deg,
                obj_yaw_deg=best_pose.obj_yaw_deg
            )
            refined_error = best_match.combined_error
            refinement_metadata = {
                "skipped": True,
                "reason": "library_match_excellent",
                "initial_error": best_match.combined_error,
                "final_error": best_match.combined_error,
                "final_iou": best_match.iou,
                "iterations": 0,
                "success": True
            }
            stage_time = 0.0

            print(f"{item_id}: Using library pose (error={refined_error:.4f}, IoU={best_match.iou:.3f})")
            log_lines.append(f"STAGE 4: Refinement skipped, using library pose directly")
        else:
            if skip_library:
                # AR mode: proceed to refinement (if enabled)
                print(f"{item_id}: AR error {mask_error:.4f} - proceeding to refinement")
                log_lines.append(f"AR error check passed: {mask_error:.4f}")
            else:
                # IoU mode: proceed to refinement
                print(f"{item_id}: Match error {best_match.combined_error:.4f} < "
                    f"{refinement_threshold} - proceeding to refinement")
                log_lines.append(f"Match error check passed: {best_match.combined_error:.4f} < {refinement_threshold}")

            # Stage 4: Local refinement from best match
            print(f"{item_id}: STAGE 4 - Refining pose from best match...")
            stage_start = time.time()

            # Create refiner using config parameters
            ref_cfg = self.config.objective.objective2.refinement
            refiner = PoseRefiner(
                renderer=self.prerender.renderer,
                max_iterations=ref_cfg.max_iterations,
                learning_rate=ref_cfg.learning_rate,
                error_threshold=ref_cfg.error_threshold,
                min_improvement=ref_cfg.min_improvement,
                trust_azimuth=ref_cfg.trust_azimuth,
                trust_elevation=ref_cfg.trust_elevation,
                trust_log_radius=ref_cfg.trust_log_radius,
                trust_yaw=ref_cfg.trust_yaw,
                trust_fov=ref_cfg.trust_fov,
                freeze_yaw_until_iou=ref_cfg.freeze_yaw_until_iou,
                gradient_epsilon=ref_cfg.gradient_epsilon,
                iou_weight=ref_cfg.iou_weight,  # CRITICAL: Use same weights as library matcher!
                edge_weight=ref_cfg.edge_weight  # CRITICAL: Ensures objective consistency!
            )

            # Convert PrerenderPose to RefineParams
            initial_refine_params = RefineParams(
                azimuth_deg=best_pose.azimuth_deg,
                elevation_deg=best_pose.elevation_deg,
                radius=best_pose.radius,
                fov_deg=best_pose.fov_deg,
                obj_yaw_deg=best_pose.obj_yaw_deg
            )

            # Run refinement (with GIF generation)
            refinement_log_file = output_dir / "refinement_log.txt"
            refinement_gif_path = output_dir / "refinement_optimization.gif"
            refined_params, refined_error, refinement_metadata = refiner.refine(
                glb_path=glb_path,
                initial_params=initial_refine_params,
                gt_mask=best_gt_mask,
                gt_edges=best_gt_edges,
                gt_dt=best_gt_dt,
                log_file=refinement_log_file,
                gt_rgb=best_gt_rgb,
                gif_path=refinement_gif_path,
                gif_fps=self.config.objective.realtime.gif_fps,
                gif_min_frames=self.config.objective.realtime.gif_min_frames,
                tag_opacity=self.config.objective.realtime.overlay.tag_opacity,
                tag_corner=self.config.objective.realtime.overlay.tag_corner
            )

            stage_time = time.time() - stage_start

            # CRITICAL FIX: Compare refinement errors, not library error vs refinement error
            # (they use different objectives and are incomparable!)
            initial_ref_error = refinement_metadata.get('initial_error', refined_error)
            error_delta = refined_error - initial_ref_error

            if abs(error_delta) < 0.001:
                result_msg = "unchanged"
            elif error_delta < 0:
                result_msg = f"improved by {abs(error_delta):.4f}"
            else:
                result_msg = f"worsened by {error_delta:.4f}"

            print(
                f"{item_id}: Refinement complete - "
                f"error {result_msg} ({initial_ref_error:.4f} -> {refined_error:.4f}) "
                f"({refinement_metadata['iterations']} iters, {stage_time:.1f}s)"
            )
            log_lines.append(
                f"STAGE 4: Refinement {refinement_metadata['iterations']} iters, "
                f"error={initial_ref_error:.4f}->{refined_error:.4f} ({result_msg}), "
                f"success={refinement_metadata['success']} ({stage_time:.1f}s)"
            )

        # Use the refined parameters (from refinement or library) as final pose
        final_params = refined_params.to_dict()

        # Compute final pose confidence from refined IoU (or AR error in AR mode)
        if refinement_metadata['final_iou'] is not None:
            # IoU mode: use IoU from library match or refinement
            pose_confidence = refinement_metadata['final_iou']
            mask_error = 1.0 - pose_confidence
        else:
            # AR mode: use AR error directly until post-HQ IoU is computed
            pose_confidence = None  # Will be computed post-HQ
            mask_error = refined_error  # Use AR error for now

        # ERROR GATE 2: Check HQ render error threshold
        hq_threshold = self.config.objective.hq_error_threshold
        if mask_error >= hq_threshold:
            print(f"[ERROR] {item_id}: Mask error {mask_error:.3f} >= {hq_threshold} threshold - "
                f"skipping HQ render")
            log_lines.append(f"FAILED: Mask error {mask_error:.3f} >= {hq_threshold} HQ threshold")
            log_lines.append(f"Total time: {time.time() - item_start_time:.1f}s")
            log_lines.append("=" * 80)
            with open(main_log_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(log_lines))
            self._mark_failed(output_dir, reason="mask_error_too_high")
            return None

        print(f"{item_id}: Mask error {mask_error:.3f} < {hq_threshold} - proceeding to validation")
        log_lines.append(f"Mask error check passed: {mask_error:.3f} < {hq_threshold}")

        # STAGE 4.5: Blender validation disabled (pyrender-only pipeline)
        validation_error = 0.0
        validation_threshold = self.config.objective.validation_error_threshold
        print(f"{item_id}: STAGE 4.5 - Skipping Blender validation (pyrender-only pipeline)")
        log_lines.append("STAGE 4.5: Skipped Blender validation (pyrender-only pipeline)")
        """
        # STAGE 4.5: Validation render - verify Blender vs pyrender consistency
        print(f"{item_id}: STAGE 4.5 - Validation render (Blender HQ vs pyrender consistency check)...")
        stage_start = time.time()

        # Render VALIDATION mask with Blender at HQ resolution (fast engine)
        from vfscore.objective2.render_hq import render_hq
        validation_hq_path = output_dir / "validation_hq.png"
        validation_debug_dir = output_dir / "validation_debug"
        validation_debug_dir.mkdir(parents=True, exist_ok=True)
        blender_scene_debug_path = validation_debug_dir / "blender_scene_debug.json"
        pyrender_norm_debug_path = validation_debug_dir / "pyrender_norm_debug.json"

        # SPEED FIX: Use 128px fast validation (both Blender and pyrender at same res)
        # This is 16x faster than 512px (128^2 / 512^2 = 0.0625)
        validation_res = 128

        # Reset pyrender scene to avoid stale meshes
        self.prerender.renderer.cleanup_scene()

        # Render pyrender mask first (fast, no Blender subprocess needed yet)
        pyrender_mask_128 = self.prerender.renderer.render_mask(
            glb_path,
            azimuth_deg=refined_params.azimuth_deg,
            elevation_deg=refined_params.elevation_deg,
            radius=refined_params.radius,
            fov_deg=refined_params.fov_deg,
            obj_yaw_deg=refined_params.obj_yaw_deg,
            coarse=True  # 128px coarse renderer
        )

        pyrender_norm_meta = self.prerender.renderer.get_normalization_metadata(glb_path)
        camera_pose_matrix = self.prerender.renderer.get_camera_pose(
            refined_params.azimuth_deg,
            refined_params.elevation_deg,
            refined_params.radius
        )
        pyrender_norm_meta.update({
            "pose_params": refined_params.to_dict(),
            "render_resolution": validation_res,
            "camera_pose_matrix": camera_pose_matrix.tolist(),
        })
        with open(pyrender_norm_debug_path, 'w', encoding='utf-8') as f:
            json.dump(pyrender_norm_meta, f, indent=2)

        centroid_tuple = tuple(float(c) for c in pyrender_norm_meta["centroid_before_translation"])
        scale_factor = float(pyrender_norm_meta["scale_factor"])
        cam_pose_tuple = tuple(tuple(float(v) for v in row) for row in camera_pose_matrix.tolist())
        principal_shift_x = BLENDER_PRINCIPAL_SHIFT_X
        principal_shift_y = BLENDER_PRINCIPAL_SHIFT_Y

        # Now render Blender mask at same resolution
        import subprocess
        import tempfile

# Generate minimal Blender script for mask-only render
        script = f'''
import bpy
import math
import json
from pathlib import Path
from mathutils import Vector, Matrix

# Clear scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Import GLB
bpy.ops.import_scene.gltf(filepath=r"{glb_path.resolve()}")
imported = [o for o in bpy.context.selected_objects if o.type == 'MESH']
if imported:
    bpy.context.view_layer.objects.active = imported[0]
    if len(imported) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for o in imported: o.select_set(True)
        bpy.ops.object.join()

obj = bpy.context.active_object

bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# Apply EXACT pyrender normalization (centroid + scale)
centroid = Vector({centroid_tuple})
mesh = obj.data
mesh.transform(Matrix.Translation(-centroid))
mesh.update()
obj.location = (0.0, 0.0, 0.0)

norm_scale = {scale_factor}
obj.scale = (norm_scale, norm_scale, norm_scale)
bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

# Apply yaw rotation (object rotation about Z-axis)
obj.rotation_euler = (0, 0, math.radians({refined_params.obj_yaw_deg}))

# Override materials to a solid opaque emission to ensure geometry-only mask
mask_mat = bpy.data.materials.new(name="MaskMaterial")
mask_mat.use_nodes = True
node_tree = mask_mat.node_tree
for node in list(node_tree.nodes):
    node_tree.nodes.remove(node)
output_node = node_tree.nodes.new(type='ShaderNodeOutputMaterial')
emission_node = node_tree.nodes.new(type='ShaderNodeEmission')
emission_node.inputs['Color'].default_value = (1.0, 1.0, 1.0, 1.0)
emission_node.inputs['Strength'].default_value = 1.0
node_tree.links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])
mask_mat.blend_method = 'CLIP'
if hasattr(mask_mat, "shadow_method"):
    mask_mat.shadow_method = 'NONE'
if hasattr(mask_mat, "use_backface_culling"):
    mask_mat.use_backface_culling = False
obj.data.materials.clear()
obj.data.materials.append(mask_mat)

# Camera setup to match pyrender look-at
cam_data = bpy.data.cameras.new(name='Camera')
cam_data.lens_unit = 'FOV'
cam_data.sensor_fit = 'VERTICAL'
cam_data.sensor_width = 24.0
cam_data.sensor_height = 24.0
cam_data.angle_y = math.radians({refined_params.fov_deg} * {BLENDER_FOV_SCALE})
cam_data.shift_x = {principal_shift_x}
cam_data.shift_y = {principal_shift_y}
cam_obj = bpy.data.objects.new('Camera', cam_data)
bpy.context.scene.collection.objects.link(cam_obj)

cam_matrix = Matrix({cam_pose_tuple})
cam_obj.matrix_world = cam_matrix
bpy.context.scene.camera = cam_obj

# Write debug metadata for Blender normalization / camera
debug_output_path = Path(r"{blender_scene_debug_path.resolve()}")
debug_output_path.parent.mkdir(parents=True, exist_ok=True)

def vec3(v):
    return [float(v[0]), float(v[1]), float(v[2])]

cam_z_axis = Vector((cam_matrix[0][2], cam_matrix[1][2], cam_matrix[2][2]))
camera_forward_vec = vec3((-cam_z_axis).normalized())

debug_data = {{
    "centroid_before_translation": list({centroid_tuple}),
    "scale_factor_applied": float(norm_scale),
    "dimensions_after_scale": [float(d) for d in obj.dimensions],
    "object_location": vec3(obj.location),
    "object_scale": vec3(obj.scale),
    "object_rotation_euler": vec3(obj.rotation_euler),
    "bound_box_local": [[float(coord) for coord in corner] for corner in obj.bound_box],
    "camera_location": vec3(cam_obj.location),
    "camera_matrix_world": [[float(val) for val in row] for row in cam_obj.matrix_world],
    "camera_forward": camera_forward_vec,
    "camera_angle_x": float(cam_data.angle_x),
    "camera_angle_y": float(cam_data.angle_y),
}}

with open(debug_output_path, 'w', encoding='utf-8') as df:
    json.dump(debug_data, df, indent=2)

# Fast render settings (mask only) - SPEED FIX: 128px instead of 512px
scene = bpy.context.scene
scene.render.engine = 'BLENDER_WORKBENCH'
scene.render.resolution_x = {validation_res}
scene.render.resolution_y = {validation_res}
scene.render.film_transparent = True
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.render.filepath = r"{validation_hq_path.resolve()}"
bpy.ops.render.render(write_still=True)
'''

        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
            script_path = Path(f.name)
            f.write(script)

        blender_stdout_text: str | None = None
        blender_stderr_text: str | None = None

        try:
            cmd = [
                str(self.config.paths.blender_exe),
                "--background",
                "--factory-startup",
                "--python",
                str(script_path)
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, check=False)
            blender_stdout_text = result.stdout
            blender_stderr_text = result.stderr

            if result.returncode != 0 or not validation_hq_path.exists():
                def _safe(s: str) -> str:
                    return s.strip().encode('unicode_escape', errors='replace').decode('ascii', errors='replace')

                print(f"[ERROR] Blender validation render failed")
                print(f"         stdout: {_safe(result.stdout)}")
                print(f"         stderr: {_safe(result.stderr)}")
                validation_threshold = 999.0  # Skip validation on Blender failure
                validation_error = 0.0
                log_lines.append("FAILED: Blender validation render failed")
                log_lines.append(f"Blender stdout saved to: {validation_debug_dir / 'blender_stdout.log'}")
                log_lines.append(f"Blender stderr saved to: {validation_debug_dir / 'blender_stderr.log'}")
                log_lines.append(f"Total time: {time.time() - item_start_time:.1f}s")
                log_lines.append("=" * 80)
                with open(main_log_file, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(log_lines))
                self._mark_failed(output_dir, reason="validation_blender_failed")
                return None
            else:
                # Load Blender mask and extract alpha channel
                from PIL import Image
                blender_rgba = np.array(Image.open(validation_hq_path))
                blender_mask = blender_rgba[:, :, 3] if blender_rgba.shape[2] == 4 else np.mean(blender_rgba, axis=2).astype(np.uint8)

                # Compute IoU (Blender mask vs pyrender mask, both 128px)
                from vfscore.objective2.silhouette import iou as compute_iou
                validation_iou = compute_iou(blender_mask, pyrender_mask_128)
                validation_error = 1.0 - validation_iou

                stage_time = time.time() - stage_start
                print(f"  Blender vs pyrender IoU: {validation_iou:.3f}, error: {validation_error:.3f} @ {validation_res}px ({stage_time:.1f}s)")
                log_lines.append(f"STAGE 4.5: Validation (Blender vs pyrender) IoU={validation_iou:.3f}, error={validation_error:.3f} @ {validation_res}px ({stage_time:.1f}s)")

                validation_threshold = self.config.objective.validation_error_threshold
        finally:
            if blender_stdout_text is not None:
                (validation_debug_dir / "blender_stdout.log").write_text(blender_stdout_text, encoding='utf-8', errors='replace')
            if blender_stderr_text is not None:
                (validation_debug_dir / "blender_stderr.log").write_text(blender_stderr_text, encoding='utf-8', errors='replace')

            if script_path.exists():
                script_path.unlink()

        blender_scene_debug = {}
        if blender_scene_debug_path.exists():
            try:
                with open(blender_scene_debug_path, 'r', encoding='utf-8') as f:
                    blender_scene_debug = json.load(f)
            except Exception as exc:
                print(f"[WARNING] Failed to read Blender debug info: {exc}")

        # ERROR GATE 3: Check validation error threshold
        if validation_error >= validation_threshold:
            # Save masks (Blender vs pyrender comparison)
            from PIL import Image
            if 'blender_mask' in locals():
                Image.fromarray(blender_mask).save(validation_debug_dir / "blender_mask.png")
            if 'pyrender_mask_128' in locals():
                Image.fromarray(pyrender_mask_128).save(validation_debug_dir / "pyrender_mask.png")

                # Save side-by-side comparison
                side_by_side = np.hstack([blender_mask, pyrender_mask_128])
                Image.fromarray(side_by_side).save(validation_debug_dir / "comparison.png")

            # Save refined parameters and mask centroid offsets
            mask_centroids = {}
            try:
                if 'blender_mask' in locals():
                    by, bx = np.nonzero(blender_mask > 127)
                    if bx.size > 0:
                        mask_centroids["blender"] = {
                            "cx_frac": float(bx.mean() / blender_mask.shape[1]),
                            "cy_frac": float(by.mean() / blender_mask.shape[0]),
                        }
                if 'pyrender_mask_128' in locals():
                    py, px = np.nonzero(pyrender_mask_128 > 127)
                    if px.size > 0:
                        mask_centroids["pyrender"] = {
                            "cx_frac": float(px.mean() / pyrender_mask_128.shape[1]),
                            "cy_frac": float(py.mean() / pyrender_mask_128.shape[0]),
                        }
                if "blender" in mask_centroids and "pyrender" in mask_centroids:
                    dx = mask_centroids["blender"]["cx_frac"] - mask_centroids["pyrender"]["cx_frac"]
                    dy = mask_centroids["blender"]["cy_frac"] - mask_centroids["pyrender"]["cy_frac"]
                    mask_centroids["offset_fractional"] = {
                        "dx": float(dx),
                        "dy": float(dy),
                    }
            except Exception:
                mask_centroids = mask_centroids or {}

            debug_info = {
                "validation_iou": float(validation_iou),
                "validation_error": float(validation_error),
                "validation_threshold": float(validation_threshold),
                "refined_params": refined_params.to_dict(),
                "reason": "blender_pyrender_mismatch",
                "pyrender_norm_debug": pyrender_norm_meta,
                "blender_scene_debug": blender_scene_debug,
                "mask_centroids": mask_centroids,
                "blender_mask_flipped_x": False,
            }
            with open(validation_debug_dir / "debug_info.json", 'w', encoding='utf-8') as f:
                json.dump(debug_info, f, indent=2)

            print(f"[ERROR] {item_id}: Validation error {validation_error:.3f} >= {validation_threshold} threshold - "
                f"Blender vs pyrender mismatch detected, skipping HQ render")
            print(f"[WARNING]   Debug outputs saved to: {validation_debug_dir}")
            log_lines.append(
                f"FAILED: Validation error {validation_error:.3f} >= {validation_threshold} "
                f"(Blender and pyrender produce different poses - coordinate system mismatch)"
            )
            log_lines.append(f"Debug outputs saved to: {validation_debug_dir}")
            log_lines.append(f"Total time: {time.time() - item_start_time:.1f}s")
            log_lines.append("=" * 80)
            with open(main_log_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(log_lines))
            self._mark_failed(output_dir, reason="validation_pose_mismatch")
            return None

        print(f"{item_id}: Validation passed ({validation_error:.3f} < {validation_threshold}) - "
            f"proceeding to HQ render")
        log_lines.append(f"Validation check passed: {validation_error:.3f} < {validation_threshold}")
        """

        # Save pose priors
        priors_payload = {
            "params": final_params,
            "mask_error": float(mask_error),
            "source": "objective2_refined",
            "refinement": refinement_metadata,
            "num_gt_images": len(gt_images),
            "calibrated_radius": float(calibrated_radius)
        }

        # Add IoU-mode specific fields
        if not skip_library:
            priors_payload["best_match"] = best_match.to_dict()
            priors_payload["num_library_poses"] = len(library_results)
        else:
            # AR mode - no library matching
            priors_payload["ar_error"] = calibrated_pose.get('ar_error', None)
            priors_payload["iou"] = calibrated_pose.get('iou', None)
        with open(output_dir / "pose_priors.json", "w", encoding="utf-8") as f:
            json.dump(priors_payload, f, indent=2)

        # Stage 4.5: Final radius recalibration at estimated pose (if enabled)
        calib_config = self.config.objective.objective2.library.radius_calibration
        if calib_config.final_radius_recalibration_enabled:
            print(f"{item_id}: STAGE 4.5 - Final radius recalibration at estimated pose...")
            stage_start = time.time()

            # final_params is a dict, so use dict access
            recalibrated_radius = self.prerender.recalibrate_radius_at_pose(
                glb_path=glb_path,
                gt_mask=best_gt_mask,
                pose_dict=final_params,  # final_params is already a dict with correct keys
                calib_config=calib_config,
                output_dir=output_dir
            )

            # Update final params with recalibrated radius
            original_radius = final_params['radius']
            final_params['radius'] = recalibrated_radius

            # Update pose_priors.json with recalibrated radius
            priors_payload["params"]["radius"] = recalibrated_radius
            priors_payload["original_radius_before_final_recalibration"] = float(original_radius)
            priors_payload["final_recalibration_enabled"] = True
            with open(output_dir / "pose_priors.json", "w", encoding="utf-8") as f:
                json.dump(priors_payload, f, indent=2)

            stage_time = time.time() - stage_start
            print(f"  Final radius: {recalibrated_radius:.4f} (was {original_radius:.4f}, {stage_time:.1f}s)")
            log_lines.append(f"STAGE 4.5: Final radius recalibration complete, "
                           f"radius {original_radius:.4f} -> {recalibrated_radius:.4f} ({stage_time:.1f}s)")

            # Recompute mask error with new radius
            print(f"  Recomputing mask error with recalibrated radius...")
            from vfscore.objective2.silhouette import iou as compute_iou

            # Clean up scene to prevent "already bound to context" error
            self.prerender.renderer.cleanup_scene()

            # Render mask at new radius
            recalibrated_mask = self.prerender.renderer.render_mask(
                glb_path,
                azimuth_deg=final_params['azimuth_deg'],
                elevation_deg=final_params['elevation_deg'],
                radius=recalibrated_radius,
                fov_deg=final_params['fov_deg'],
                obj_yaw_deg=final_params['obj_yaw_deg'],
                coarse=False
            )

            # Compute IoU with GT mask
            recalibrated_iou = compute_iou(best_gt_mask, recalibrated_mask)
            recalibrated_error = 1.0 - recalibrated_iou

            # Update mask error and pose confidence
            old_mask_error = mask_error
            mask_error = recalibrated_error
            pose_confidence = recalibrated_iou

            print(f"  Mask error updated: {old_mask_error:.4f} -> {mask_error:.4f} (IoU: {recalibrated_iou:.3f})")
            log_lines.append(f"  Mask error recomputed: {old_mask_error:.4f} -> {mask_error:.4f}, IoU: {recalibrated_iou:.3f}")

            # Update pose_priors.json with new mask error
            priors_payload["mask_error"] = float(mask_error)
            priors_payload["recalibrated_iou"] = float(recalibrated_iou)
            with open(output_dir / "pose_priors.json", "w", encoding="utf-8") as f:
                json.dump(priors_payload, f, indent=2)
        else:
            print(f"{item_id}: STAGE 4.5 - Final radius recalibration disabled")
            log_lines.append(f"STAGE 4.5: Final radius recalibration disabled")

        # Stage 5: HQ render with pyrender (single-engine pipeline)
        hq_dir = output_dir / "hq"
        hq_dir.mkdir(parents=True, exist_ok=True)
        hq_render_path = hq_dir / "hq_render.png"

        # Determine if we should use exact crop mode
        hq_render_mode = self.config.objective.objective2.hq_render_mode
        use_exact_crop = (hq_render_mode == "exact_crop")

        # Load GT metadata to get exact crop dimensions (if available)
        exact_crop_dimensions = None
        exact_gt_path = None

        if use_exact_crop:
            metadata_path = gt_dir / "metadata.json"
            if metadata_path.exists():
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    gt_metadata = json.load(f)

                # Find the selected GT metadata
                selected_gt_meta = None
                for gt_meta in gt_metadata["gts"]:
                    if gt_meta.get("is_selected", False):
                        selected_gt_meta = gt_meta
                        break

                if selected_gt_meta and "exact_dimensions" in selected_gt_meta:
                    exact_crop_dimensions = tuple(selected_gt_meta["exact_dimensions"])
                    exact_gt_path = gt_dir / selected_gt_meta["exact_path"]
                    print(f"  Using exact crop mode: {exact_crop_dimensions[0]}x{exact_crop_dimensions[1]}")
                    log_lines.append(f"HQ render mode: exact_crop, dimensions={exact_crop_dimensions}")
                else:
                    print(f"  Exact crop requested but not available, falling back to square")
                    log_lines.append(f"HQ render mode: square (exact crop not available)")
            else:
                print(f"  No metadata found, falling back to square mode")
                log_lines.append(f"HQ render mode: square (no metadata)")

        print(f"{item_id}: STAGE 5 - Rendering HQ image (pyrender, "
            f"{self.config.objective.hq_resolution}px)...")
        stage_start = time.time()
        render_success = render_hq_pyrender_cached(
            glb_path, final_params, hq_render_path, self.config, cache_manager,
            exact_crop_dimensions=exact_crop_dimensions
        )
        if not render_success:
            print(f"[ERROR] {item_id}: HQ render failed")
            log_lines.append(f"STAGE 5: HQ render FAILED")
            log_lines.append(f"Total time: {time.time() - item_start_time:.1f}s")
            log_lines.append("=" * 80)
            with open(main_log_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(log_lines))
            self._mark_failed(output_dir, reason="hq_render")
            return None

        stage_time = time.time() - stage_start
        print(f"  HQ render complete ({stage_time:.1f}s)")
        log_lines.append(f"STAGE 5: HQ render complete ({stage_time:.1f}s)")

        # Stage 5.5: Post-HQ IoU calculation (pose_confidence from actual rendered output)
        # This gives the most accurate pose quality metric since it uses the final cropped images
        print(f"{item_id}: Computing post-HQ IoU (final pose confidence)...")
        from PIL import Image
        from vfscore.objective2.silhouette import iou as compute_iou

        # Use exact GT if available, otherwise use square GT
        lpips_gt_path = exact_gt_path if exact_gt_path and exact_gt_path.exists() else best_gt_path

        try:
            # Load HQ render and GT, extract alpha channels
            hq_img = Image.open(hq_render_path).convert("RGBA")
            gt_img = Image.open(lpips_gt_path).convert("RGBA")

            hq_alpha = np.array(hq_img.split()[3])
            gt_alpha = np.array(gt_img.split()[3])

            # Compute IoU between final cropped masks
            post_hq_iou = compute_iou(gt_alpha, hq_alpha)
            pose_confidence = post_hq_iou  # Update pose_confidence with post-HQ IoU

            print(f"  Post-HQ IoU: {post_hq_iou:.3f} (replaces initial error as pose_confidence)")
            log_lines.append(f"STAGE 5.5: Post-HQ IoU={post_hq_iou:.3f} (pose_confidence)")

        except Exception as exc:
            print(f"  [WARNING] Post-HQ IoU computation failed: {exc}, using initial error")
            log_lines.append(f"STAGE 5.5: Post-HQ IoU FAILED ({exc}), using initial error")
            # pose_confidence remains from AR error or library match

        # Stage 6: LPIPS perceptual distance

        print(f"{item_id}: STAGE 6 - Computing LPIPS perceptual distance...")
        stage_start = time.time()
        lpips_distance = compute_lpips_cached(
            lpips_gt_path,
            hq_render_path,
            model=self.config.objective.lpips.model,
            device=self.config.objective.lpips.device,
            normalize=self.config.objective.lpips.normalize,
            background_rgb=self.config.preprocess.bg_rgb,
            debug_dir=hq_dir / "debug_lpips",
            cache_manager=cache_manager
        )

        # Combine score
        final_score = combine_score(
            lpips_distance,
            pose_confidence,
            self.config.objective.combiner.gamma,
            self.config.objective.combiner.pose_compensation_c,
        )

        stage_time = time.time() - stage_start
        print(f"  LPIPS computed: {lpips_distance:.4f}, final_score: {final_score:.3f} ({stage_time:.1f}s)")
        log_lines.append(f"STAGE 6: LPIPS={lpips_distance:.4f}, final_score={final_score:.3f} ({stage_time:.1f}s)")

        # Build result (handle both AR and IoU pipelines)
        result = {
            "item_id": item_id,
            "lpips": lpips_distance,
            "pose_confidence": pose_confidence,
            "gamma": self.config.objective.combiner.gamma,
            "pose_compensation_c": self.config.objective.combiner.pose_compensation_c,
            "final_score": final_score,
            "score_scale": "0_1",
            "artifacts": {
                "gt": self._safe_relative(best_gt_path, self.config.paths.out_dir.parent),
                "hq_render": self._safe_relative(hq_render_path, output_dir),
                "library_dir": self._safe_relative(library_dir, output_dir),
            },
            "params": final_params,
            "num_gt_images": len(gt_images),
            "mask_error": float(mask_error),
            "pipeline_mode": "ar_based" if skip_library else "iou_based",
        }

        # Add IoU pipeline-specific fields if applicable
        if not skip_library:
            result["artifacts"]["match_viz"] = self._safe_relative(
                match_dir / "match_visualizations", output_dir
            )
            result["best_match_gt_index"] = best_match.gt_index
            result["best_match_lib_index"] = best_match.lib_index
            result["best_match_iou"] = float(best_match.iou)
            result["best_match_error"] = float(best_match.combined_error)
            result["num_library_poses"] = len(library_results)
        else:
            # AR pipeline-specific fields
            result["ar_error"] = best_pose_dict.get('ar_error', None)
            result["calibration_method"] = best_pose_dict.get('method', 'aspect_ratio')

        with open(output_dir / "final.json", "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)

        # Color-coded output based on quality
        if pose_confidence >= 0.8:
            style = "bold green"
            quality = "excellent"
        elif pose_confidence >= 0.5:
            style = "green"
            quality = "good"
        elif pose_confidence >= 0.3:
            style = "yellow"
            quality = "acceptable"
        else:
            style = "red"
            quality = "poor pose"

        console.print(
            f"[{style}]{item_id}: COMPLETE - score={final_score:.3f} "
            f"(LPIPS={lpips_distance:.3f}, pose_conf={pose_confidence:.3f}, "
            f"{quality})[/{style}]"
        )

        # Export scoring artifacts for GT/HQ pair visualization
        self._export_scoring_artifacts(
            output_dir=output_dir,
            gt_path=lpips_gt_path,
            render_path=hq_render_path
        )

        return result

    def _safe_relative(self, path: Path, base: Path) -> str:
        """Convert path to relative if possible, otherwise absolute."""
        try:
            return str(path.relative_to(base))
        except ValueError:
            return str(path)

    def _export_scoring_artifacts(
        self,
        output_dir: Path,
        gt_path: Path,
        render_path: Path
    ) -> dict:
        """
        Export GT and HQ render images used for LPIPS scoring.

        Creates a vfscore_artifacts directory with:
        - refs/gt_selected.png: The GT image used for LPIPS comparison
        - renders/hq_render.png: The HQ render used for LPIPS comparison
        - artifacts.json: Descriptor with relative paths

        Args:
            output_dir: Item output directory (outputs/objective/<item_id>)
            gt_path: Path to GT image used for LPIPS scoring
            render_path: Path to HQ render used for LPIPS scoring

        Returns:
            Dict with artifact paths (relative to output_dir)
        """
        import shutil

        artifacts_dir = output_dir / "vfscore_artifacts"
        refs_dir = artifacts_dir / "refs"
        renders_dir = artifacts_dir / "renders"

        # Create directories
        refs_dir.mkdir(parents=True, exist_ok=True)
        renders_dir.mkdir(parents=True, exist_ok=True)

        # Copy GT image
        gt_dest = refs_dir / "gt_selected.png"
        if gt_path.exists():
            shutil.copy2(gt_path, gt_dest)

        # Copy HQ render
        render_dest = renders_dir / "hq_render.png"
        if render_path.exists():
            shutil.copy2(render_path, render_dest)

        # Write artifacts.json with relative paths
        artifacts_json = {
            "gt": "refs/gt_selected.png",
            "render": "renders/hq_render.png"
        }
        artifacts_path = artifacts_dir / "artifacts.json"
        with open(artifacts_path, "w", encoding="utf-8") as f:
            json.dump(artifacts_json, f, indent=2)

        return {
            "artifacts_dir": str(artifacts_dir.relative_to(output_dir)),
            "gt": str(gt_dest.relative_to(output_dir)),
            "render": str(render_dest.relative_to(output_dir))
        }

    def _mark_failed(self, output_dir: Path, reason: str) -> None:
        """Mark item as failed with reason."""
        fail_path = output_dir / "pose_failed.txt"
        with open(fail_path, "w", encoding="utf-8") as f:
            f.write(f"Objective2 pipeline failed: {reason}\n")


def run_objective2_pipeline(
    config: Config,
    force_cache: bool = False
) -> None:
    """Run the objective2 pipeline on all items in manifest.

    Args:
        config: VFScore configuration
        force_cache: If True, invalidate all caches
    """
    # Load manifest
    manifest_path = config.paths.out_dir / "manifest.jsonl"
    if not manifest_path.exists():
        console.print(
            "[red]Error: manifest.jsonl not found. Run 'vfscore ingest' first.[/red]"
        )
        return

    manifest = []
    with open(manifest_path, "r", encoding="utf-8") as f:
        for line in f:
            manifest.append(json.loads(line.strip()))

    if not manifest:
        console.print("[yellow]Warning: manifest is empty[/yellow]")
        return

    # Run pipeline
    pipeline = Objective2Pipeline(config, force_cache=force_cache)
    pipeline.run(manifest)
