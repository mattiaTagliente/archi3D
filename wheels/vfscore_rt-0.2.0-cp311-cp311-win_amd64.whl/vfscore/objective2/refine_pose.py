"""Local pose refinement for objective2 pipeline.

Refines the best library match using gradient-based optimization with best practices
from the realtime optimizer: Adam optimizer, trust regions, edge-based objectives.
"""

from __future__ import annotations

import time
import numpy as np
from pathlib import Path
from typing import Dict, Tuple, List, Optional
from dataclasses import dataclass

try:
    import imageio.v2 as imageio
    IMAGEIO_AVAILABLE = True
except ImportError:
    try:
        import imageio
        IMAGEIO_AVAILABLE = True
    except ImportError:
        IMAGEIO_AVAILABLE = False

from vfscore.objective2.render_realtime import RealtimeRenderer, create_overlay_frame
from vfscore.objective2.silhouette import iou, extract_edges, compute_chamfer, prepare_edges_and_dt


@dataclass
class RefineParams:
    """Pose parameters for refinement."""
    azimuth_deg: float
    elevation_deg: float
    radius: float
    fov_deg: float
    obj_yaw_deg: float

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "azimuth_deg": float(self.azimuth_deg),
            "elevation_deg": float(self.elevation_deg),
            "radius": float(self.radius),
            "fov_deg": float(self.fov_deg),
            "obj_yaw_deg": float(self.obj_yaw_deg)
        }


class PoseRefiner:
    """Local pose refinement using gradient descent."""

    def __init__(
        self,
        renderer: RealtimeRenderer,
        max_iterations: int = 100,
        learning_rate: float = 0.01,  # REDUCED from 0.02 (research: 0.001-0.003 for stability)
        error_threshold: float = 0.10,
        min_improvement: float = 0.0001,
        trust_azimuth: float = 5.0,
        trust_elevation: float = 5.0,
        trust_log_radius: float = 0.1,
        trust_yaw: float = 2.0,
        trust_fov: float = 2.0,
        freeze_yaw_until_iou: float = 0.90,
        gradient_epsilon: float = 0.5,
        iou_weight: float = 1.0,  # NEW: Objective weight for IoU
        edge_weight: float = 0.25  # NEW: Objective weight for edge (MUST match library!)
    ):
        """Initialize pose refiner.

        Args:
            renderer: RealtimeRenderer instance
            max_iterations: Maximum refinement iterations
            learning_rate: Learning rate for Adam optimizer
            error_threshold: Success threshold (stop if error < threshold)
            min_improvement: Stop if improvement per iteration < this
            trust_azimuth: Max change per iteration for azimuth (degrees)
            trust_elevation: Max change per iteration for elevation (degrees)
            trust_log_radius: Max change per iteration for log(radius)
            trust_yaw: Max change per iteration for yaw (degrees)
            trust_fov: Max change per iteration for FOV (degrees)
            freeze_yaw_until_iou: Freeze yaw until IoU exceeds this
            gradient_epsilon: Step size for numerical gradients
            iou_weight: Weight for IoU term in objective (default: 1.0)
            edge_weight: Weight for edge term in objective (default: 0.25, MUST match library!)
        """
        self.renderer = renderer
        self.max_iterations = max_iterations
        self.learning_rate = learning_rate
        self.error_threshold = error_threshold
        self.min_improvement = min_improvement
        self.trust_regions = {
            'azimuth_deg': trust_azimuth,
            'elevation_deg': trust_elevation,
            'log_radius': trust_log_radius,
            'obj_yaw_deg': trust_yaw,
            'fov_deg': trust_fov
        }
        self.freeze_yaw_until_iou = freeze_yaw_until_iou
        self.gradient_epsilon = gradient_epsilon
        self.iou_weight = iou_weight
        self.edge_weight = edge_weight

        # Adam optimizer state
        self.m = {}  # First moment
        self.v = {}  # Second moment
        self.beta1 = 0.9
        self.beta2 = 0.999
        self.epsilon = 1e-8

    def _reset_optimizer_state(self):
        """Reset Adam optimizer state."""
        self.m = {
            'azimuth_deg': 0.0,
            'elevation_deg': 0.0,
            'log_radius': 0.0,
            'obj_yaw_deg': 0.0,
            'fov_deg': 0.0  # NEW: FOV moment
        }
        self.v = {
            'azimuth_deg': 0.0,
            'elevation_deg': 0.0,
            'log_radius': 0.0,
            'obj_yaw_deg': 0.0,
            'fov_deg': 0.0  # NEW: FOV variance
        }

    def _compute_objective(
        self,
        glb_path: Path,
        params: RefineParams,
        gt_mask: np.ndarray,
        gt_edges: np.ndarray,
        gt_dt: np.ndarray,
        iou_weight: float = 1.0,
        edge_weight: float = 1.0
    ) -> Tuple[float, float, float]:
        """Compute combined objective (IoU + edge chamfer).

        CRITICAL OPTIMIZATION: Mask-only rendering with edges extracted from silhouette.
        This is the standard illumination-invariant objective for pose refinement.
        RGB adds lighting/material non-convexities without improving identifiability.

        Args:
            glb_path: Path to GLB file
            params: Current pose parameters
            gt_mask: Ground truth mask
            gt_edges: Ground truth edges
            gt_dt: Precomputed distance transform
            iou_weight: Weight for IoU term
            edge_weight: Weight for edge chamfer term

        Returns:
            (objective, iou_score, edge_chamfer)
        """
        # CRITICAL OPTIMIZATION: Render ONLY mask (no RGB needed for refinement)
        rendered_mask = self.renderer.render_mask(
            glb_path,
            azimuth_deg=params.azimuth_deg,
            elevation_deg=params.elevation_deg,
            radius=params.radius,
            fov_deg=params.fov_deg,
            obj_yaw_deg=params.obj_yaw_deg,
            coarse=True  # 128px
        )

        # Resize to GT resolution for comparison
        h, w = gt_mask.shape
        rendered_mask_resized = np.array(
            rendered_mask
        ) if rendered_mask.shape == gt_mask.shape else np.array(
            self._resize_image(rendered_mask, (w, h), nearest=True)
        )

        # Compute IoU
        iou_score = iou(gt_mask, rendered_mask_resized)

        # CRITICAL: Extract edges from mask silhouette (not RGB)
        # Edges represent object boundary, independent of lighting/materials
        import cv2
        rendered_edges = cv2.Canny(rendered_mask_resized, 50, 150)

        # Compute directional chamfer using precomputed GT distance transform
        edge_chamfer = compute_chamfer(rendered_edges, gt_dt)

        # Combined objective (lower is better)
        # Silhouette IoU + edge chamfer: canonical illumination-invariant pose metric
        objective = self.iou_weight * (1.0 - iou_score) + self.edge_weight * edge_chamfer

        return objective, iou_score, edge_chamfer

    def _resize_image(self, img: np.ndarray, target_size: Tuple[int, int], nearest: bool = False):
        """Resize image using PIL."""
        from PIL import Image
        import cv2
        if nearest:
            return cv2.resize(img, target_size, interpolation=cv2.INTER_NEAREST)
        else:
            return cv2.resize(img, target_size, interpolation=cv2.INTER_LINEAR)

    def _compute_gradients(
        self,
        glb_path: Path,
        params: RefineParams,
        gt_mask: np.ndarray,
        gt_edges: np.ndarray,
        gt_dt: np.ndarray,
        current_iou: float,
        iou_weight: float = 1.0,
        edge_weight: float = 1.0,
        current_obj: float = None  # NEW: Pass current objective to avoid recomputation
    ) -> Dict[str, float]:
        """Compute numerical gradients for all parameters.

        Args:
            glb_path: Path to GLB file
            params: Current pose parameters
            gt_mask: Ground truth mask
            gt_edges: Ground truth edges
            gt_dt: Precomputed distance transform
            current_iou: Current IoU score
            iou_weight: Weight for IoU term
            edge_weight: Weight for edge chamfer term
            current_obj: Optional pre-computed current objective (avoids redundant render)

        Returns:
            Dictionary of gradients for each parameter
        """
        epsilon = self.gradient_epsilon
        gradients = {}

        # CRITICAL FIX: Use pre-computed objective if provided, else compute
        if current_obj is None:
            current_obj, _, _ = self._compute_objective(
                glb_path, params, gt_mask, gt_edges, gt_dt, iou_weight, edge_weight
            )

        # Compute gradient for azimuth
        params_plus = RefineParams(
            params.azimuth_deg + epsilon,
            params.elevation_deg,
            params.radius,
            params.fov_deg,
            params.obj_yaw_deg
        )
        obj_plus, _, _ = self._compute_objective(
            glb_path, params_plus, gt_mask, gt_edges, gt_dt, iou_weight, edge_weight
        )
        gradients['azimuth_deg'] = (obj_plus - current_obj) / epsilon

        # Compute gradient for elevation
        params_plus = RefineParams(
            params.azimuth_deg,
            params.elevation_deg + epsilon,
            params.radius,
            params.fov_deg,
            params.obj_yaw_deg
        )
        obj_plus, _, _ = self._compute_objective(
            glb_path, params_plus, gt_mask, gt_edges, gt_dt, iou_weight, edge_weight
        )
        gradients['elevation_deg'] = (obj_plus - current_obj) / epsilon

        # Compute gradient for log_radius (reparameterized)
        log_radius = np.log(params.radius)
        radius_plus = np.exp(log_radius + epsilon)
        params_plus = RefineParams(
            params.azimuth_deg,
            params.elevation_deg,
            radius_plus,
            params.fov_deg,
            params.obj_yaw_deg
        )
        obj_plus, _, _ = self._compute_objective(
            glb_path, params_plus, gt_mask, gt_edges, gt_dt, iou_weight, edge_weight
        )
        gradients['log_radius'] = (obj_plus - current_obj) / epsilon

        # Compute gradient for yaw (only if unfrozen)
        if current_iou >= self.freeze_yaw_until_iou:
            params_plus = RefineParams(
                params.azimuth_deg,
                params.elevation_deg,
                params.radius,
                params.fov_deg,
                params.obj_yaw_deg + epsilon
            )
            obj_plus, _, _ = self._compute_objective(
                glb_path, params_plus, gt_mask, gt_edges, gt_dt, iou_weight, edge_weight
            )
            gradients['obj_yaw_deg'] = (obj_plus - current_obj) / epsilon
        else:
            gradients['obj_yaw_deg'] = 0.0  # Frozen

        # NEW: Compute gradient for FOV
        params_plus = RefineParams(
            params.azimuth_deg,
            params.elevation_deg,
            params.radius,
            params.fov_deg + epsilon,
            params.obj_yaw_deg
        )
        obj_plus, _, _ = self._compute_objective(
            glb_path, params_plus, gt_mask, gt_edges, gt_dt, iou_weight, edge_weight
        )
        gradients['fov_deg'] = (obj_plus - current_obj) / epsilon

        return gradients

    def refine(
        self,
        glb_path: Path,
        initial_params: RefineParams,
        gt_mask: np.ndarray,
        gt_edges: np.ndarray,
        gt_dt: np.ndarray,
        log_file: Path | None = None,
        gt_rgb: np.ndarray | None = None,
        gif_path: Path | None = None,
        gif_fps: int = 10,
        gif_min_frames: int = 24,
        tag_opacity: float = 0.6,
        tag_corner: str = "tr"
    ) -> Tuple[RefineParams, float, Dict]:
        """Refine pose starting from initial parameters.

        Args:
            glb_path: Path to GLB file
            initial_params: Starting pose parameters
            gt_mask: Ground truth mask
            gt_edges: Ground truth edges
            gt_dt: Precomputed distance transform
            log_file: Optional path to log file
            gt_rgb: Optional GT RGB image for GIF visualization
            gif_path: Optional output path for optimization GIF
            gif_fps: Frames per second for GIF (default: 10)
            gif_min_frames: Minimum frames to ensure in GIF (default: 24)
            tag_opacity: Opacity for overlay tags (default: 0.6)
            tag_corner: Tag corner placement (default: "tr")

        Returns:
            (refined_params, final_error, metadata)
        """
        start_time = time.time()
        self._reset_optimizer_state()

        # Initialize GIF frames list
        frames = []
        enable_gif = (gif_path is not None and gt_rgb is not None and IMAGEIO_AVAILABLE)
        if enable_gif and not IMAGEIO_AVAILABLE:
            print("Warning: imageio not available, GIF generation disabled")
            enable_gif = False

        # Calculate stride to ensure minimum frames while respecting max_iterations
        # Strategy: capture first gif_min_frames, then every Nth frame
        gif_stride = max(1, self.max_iterations // gif_min_frames) if enable_gif else 1

        params = RefineParams(
            initial_params.azimuth_deg,
            initial_params.elevation_deg,
            initial_params.radius,
            initial_params.fov_deg,
            initial_params.obj_yaw_deg
        )

        # Log initial state
        log_lines = []
        log_lines.append("=" * 80)
        log_lines.append("POSE REFINEMENT - LOCAL OPTIMIZATION")
        log_lines.append("=" * 80)
        log_lines.append(f"Initial parameters:")
        log_lines.append(f"  Azimuth: {params.azimuth_deg:.2f}deg")
        log_lines.append(f"  Elevation: {params.elevation_deg:.2f}deg")
        log_lines.append(f"  Radius: {params.radius:.3f}")
        log_lines.append(f"  FOV: {params.fov_deg:.2f}deg")
        log_lines.append(f"  Yaw: {params.obj_yaw_deg:.2f}deg")
        log_lines.append(f"Refinement settings:")
        log_lines.append(f"  Max iterations: {self.max_iterations}")
        log_lines.append(f"  Learning rate: {self.learning_rate}")
        log_lines.append(f"  Error threshold: {self.error_threshold}")
        log_lines.append(f"  Trust regions: azim={self.trust_regions['azimuth_deg']:.1f}deg, "
                        f"elev={self.trust_regions['elevation_deg']:.1f}deg, "
                        f"yaw={self.trust_regions['obj_yaw_deg']:.1f}deg")
        log_lines.append(f"  Yaw freeze threshold: IoU > {self.freeze_yaw_until_iou:.2f}")
        log_lines.append("-" * 80)

        # CRITICAL FIX: Print header immediately so user knows refinement started
        for line in log_lines:
            print(line)

        # Initial objective
        print(f"  Computing initial objective...", end=" ", flush=True)
        initial_error, initial_iou, initial_edge = self._compute_objective(
            glb_path, params, gt_mask, gt_edges, gt_dt
        )
        print(f"Error={initial_error:.4f} (IoU={initial_iou:.3f}, Edge={initial_edge:.4f})")

        best_error = initial_error
        best_iou = initial_iou
        best_edge = initial_edge
        best_params = RefineParams(
            params.azimuth_deg, params.elevation_deg, params.radius,
            params.fov_deg, params.obj_yaw_deg
        )

        log_lines.append(f"Initial objective: {initial_error:.4f} (IoU={initial_iou:.3f}, Edge={initial_edge:.4f})")

        yaw_unfrozen = False
        success = False
        threshold_met_iteration = None

        # Optimization loop
        for iteration in range(self.max_iterations):
            iter_start = time.time()

            # CRITICAL FIX: Compute current objective once (reused in gradient computation)
            # This eliminates redundant render and speeds up by 10-15%
            current_error, current_iou, current_edge = self._compute_objective(
                glb_path, params, gt_mask, gt_edges, gt_dt
            )

            # Check yaw unfreezing
            if not yaw_unfrozen and current_iou >= self.freeze_yaw_until_iou:
                yaw_unfrozen = True
                msg = f"Iteration {iteration:3d}: Yaw UNFROZEN (IoU {current_iou:.3f} >= {self.freeze_yaw_until_iou:.2f})"
                log_lines.append(msg)
                print(f"  {msg}")

            # CRITICAL FIX: Pass current objective to avoid redundant computation
            gradients = self._compute_gradients(
                glb_path, params, gt_mask, gt_edges, gt_dt, current_iou,
                current_obj=current_error  # NEW: Pass current objective to avoid recomputation
            )

            # DEBUG: Log gradients on first iteration to diagnose stuck refinement
            if iteration == 0:
                print(f"  Iteration {iteration}: Gradients computed:")
                for key, grad in gradients.items():
                    print(f"    {key}: {grad:+.6f}")
                log_lines.append(f"Iteration {iteration}: Gradients computed:")
                for key, grad in gradients.items():
                    log_lines.append(f"  {key}: {grad:+.6f}")

            # Adam optimizer update
            log_radius = np.log(params.radius)

            # CRITICAL FIX: Store proposed moments BEFORE committing
            proposed_m = {}
            proposed_v = {}
            updates = {}

            # NEW: Include FOV in optimizer loop
            for key in ['azimuth_deg', 'elevation_deg', 'log_radius', 'obj_yaw_deg', 'fov_deg']:
                grad = gradients[key]

                # Compute proposed moments (not committed yet!)
                proposed_m[key] = self.beta1 * self.m[key] + (1 - self.beta1) * grad
                proposed_v[key] = self.beta2 * self.v[key] + (1 - self.beta2) * (grad ** 2)

                # Bias correction
                m_hat = proposed_m[key] / (1 - self.beta1 ** (iteration + 1))
                v_hat = proposed_v[key] / (1 - self.beta2 ** (iteration + 1))

                # Compute update
                update = -self.learning_rate * m_hat / (np.sqrt(v_hat) + self.epsilon)

                # Apply trust region
                max_delta = self.trust_regions[key]
                update = np.clip(update, -max_delta, max_delta)

                updates[key] = update

            # Apply updates to TRIAL parameters (not committed yet!)
            trial_params = RefineParams(
                params.azimuth_deg + updates['azimuth_deg'],
                params.elevation_deg + updates['elevation_deg'],
                np.exp(log_radius + updates['log_radius']),
                params.fov_deg + updates['fov_deg'],
                params.obj_yaw_deg + updates['obj_yaw_deg']
            )

            # Wrap angles
            trial_params.azimuth_deg = trial_params.azimuth_deg % 360
            trial_params.obj_yaw_deg = trial_params.obj_yaw_deg % 360

            # Evaluate TRIAL parameters
            new_error, new_iou, new_edge = self._compute_objective(
                glb_path, trial_params, gt_mask, gt_edges, gt_dt
            )

            improvement = current_error - new_error
            iter_time = time.time() - iter_start

            # CRITICAL FIX: Step rejection (backtracking)
            # Only accept step if it improves the objective!
            if new_error < current_error:
                # Accept step - commit parameters AND moments
                params = trial_params
                log_radius = np.log(params.radius)
                # Commit Adam moments
                for key in proposed_m.keys():
                    self.m[key] = proposed_m[key]
                    self.v[key] = proposed_v[key]
            else:
                # Reject step - DO NOT update params or moments!
                # This prevents Adam from thinking it's making progress
                pass

            # Capture frame for GIF (use ACCEPTED params, not trial!)
            if enable_gif:
                should_capture = (
                    len(frames) < gif_min_frames or
                    iteration % gif_stride == 0 or
                    iteration == 0
                )
                if should_capture:
                    # Render RGB for visualization (use ACCEPTED params)
                    rendered_rgb = self.renderer.render_rgb(
                        glb_path,
                        azimuth_deg=params.azimuth_deg,
                        elevation_deg=params.elevation_deg,
                        radius=params.radius,
                        fov_deg=params.fov_deg,
                        obj_yaw_deg=params.obj_yaw_deg,
                        coarse=True,  # 128px for speed
                        unlit=True  # Lightless for speed
                    )
                    # Resize to GT resolution for overlay
                    h, w = gt_rgb.shape[:2]
                    if rendered_rgb.shape[:2] != (h, w):
                        rendered_rgb_resized = self._resize_image(rendered_rgb, (w, h), nearest=False)
                    else:
                        rendered_rgb_resized = rendered_rgb

                    # Get current error (use accepted params error)
                    current_accepted_error, _, _ = self._compute_objective(
                        glb_path, params, gt_mask, gt_edges, gt_dt
                    )

                    # Create overlay frame
                    threshold_met = (threshold_met_iteration is not None)
                    frame = create_overlay_frame(
                        rendered_rgb_resized, gt_rgb, current_accepted_error, iteration, params.to_dict(),
                        threshold_met=threshold_met,
                        tag_opacity=tag_opacity, tag_corner=tag_corner
                    )
                    frames.append(frame)

            # CRITICAL FIX: Log progress (show step acceptance/rejection) with REAL-TIME printing
            if iteration % 10 == 0 or new_error < current_error:
                status_char = "+" if new_error < current_error else "X"  # + = accepted, X = rejected

                # DEBUG: Show parameter deltas to understand what's moving
                if iteration % 10 == 0:
                    delta_az = trial_params.azimuth_deg - params.azimuth_deg
                    delta_el = trial_params.elevation_deg - params.elevation_deg
                    delta_r = trial_params.radius - params.radius
                    delta_yaw = trial_params.obj_yaw_deg - params.obj_yaw_deg
                    msg = (
                        f"Iter {iteration:3d}: trial_error={new_error:.4f} ({status_char}) "
                        f"improvement={improvement:+.4f} IoU={new_iou:.3f} "
                        f"deltas(az={delta_az:+.3f}, el={delta_el:+.3f}, r={delta_r:+.3f}, yaw={delta_yaw:+.3f}) ({iter_time:.2f}s)"
                    )
                    log_lines.append(msg)
                    print(f"  {msg}")  # CRITICAL: Print immediately!
                else:
                    msg = (
                        f"Iter {iteration:3d}: trial_error={new_error:.4f} ({status_char}) "
                        f"improvement={improvement:+.4f} IoU={new_iou:.3f} edge={new_edge:.4f} ({iter_time:.2f}s)"
                    )
                    log_lines.append(msg)
                    print(f"  {msg}")  # CRITICAL: Print immediately!

            # Update best (only from ACCEPTED steps)
            if new_error < current_error and new_error < best_error:
                best_error = new_error
                best_iou = new_iou
                best_edge = new_edge
                best_params = RefineParams(
                    params.azimuth_deg, params.elevation_deg, params.radius,
                    params.fov_deg, params.obj_yaw_deg
                )

            # Check stopping criteria
            if best_error < self.error_threshold:
                if threshold_met_iteration is None:
                    threshold_met_iteration = iteration
                    msg = f"Iteration {iteration:3d}: Threshold met! (error {best_error:.4f} < {self.error_threshold})"
                    log_lines.append(msg)
                    print(f"  {msg}")  # CRITICAL: Print immediately!
                success = True

            if abs(improvement) < self.min_improvement and iteration > 10:
                msg = f"Iteration {iteration:3d}: Converged (improvement {improvement:.6f} < {self.min_improvement})"
                log_lines.append(msg)
                print(f"  {msg}")  # CRITICAL: Print immediately!
                break

        # Generate final render for GIF padding and flash frames
        if enable_gif:
            # Render final RGB at best parameters
            final_rendered = self.renderer.render_rgb(
                glb_path,
                azimuth_deg=best_params.azimuth_deg,
                elevation_deg=best_params.elevation_deg,
                radius=best_params.radius,
                fov_deg=best_params.fov_deg,
                obj_yaw_deg=best_params.obj_yaw_deg,
                coarse=True,  # 128px for speed
                unlit=True  # Lightless for speed
            )
            # Resize to GT resolution
            h, w = gt_rgb.shape[:2]
            if final_rendered.shape[:2] != (h, w):
                final_rendered_resized = self._resize_image(final_rendered, (w, h), nearest=False)
            else:
                final_rendered_resized = final_rendered

            # Pad frames to minimum if needed
            print(f"\n[GIF] Frames collected: {len(frames)} (minimum: {gif_min_frames})")
            while len(frames) < gif_min_frames:
                if frames:
                    # Pad with last frame
                    frames.append(frames[-1])
                else:
                    # No frames yet - create one from final render
                    initial_frame = create_overlay_frame(
                        final_rendered_resized, gt_rgb, best_error,
                        0, best_params.to_dict(),
                        tag_opacity=tag_opacity, tag_corner=tag_corner
                    )
                    frames.append(initial_frame)

            # Add 10 flash frames at end
            for i in range(10):
                flash_frame = create_overlay_frame(
                    final_rendered_resized, gt_rgb, best_error,
                    len(frames) + i, best_params.to_dict(),
                    flash=True, success=success,
                    tag_opacity=tag_opacity, tag_corner=tag_corner
                )
                frames.append(flash_frame)

            # Save GIF
            print(f"[GIF] Total frames with padding and flash: {len(frames)}")
            print(f"[GIF] Saving to: {gif_path}")

            # Convert frames to uint8
            frames_uint8 = []
            for frame in frames:
                if frame.dtype != np.uint8:
                    frame = (frame * 255).astype(np.uint8) if frame.max() <= 1.0 else frame.astype(np.uint8)
                frames_uint8.append(frame)

            # Calculate durations (last 10 are flash frames with 200ms)
            duration_ms = int(1000 / gif_fps)
            num_regular_frames = max(0, len(frames_uint8) - 10)
            durations = [duration_ms] * num_regular_frames + [200] * min(10, len(frames_uint8) - num_regular_frames)

            # Ensure output directory exists
            gif_path.parent.mkdir(parents=True, exist_ok=True)

            # Save GIF
            imageio.mimsave(gif_path, frames_uint8, duration=durations, loop=0)
            print(f"[GIF] Saved optimization GIF: {gif_path}")

        # Final summary
        elapsed = time.time() - start_time

        # CRITICAL FIX: Print final summary immediately (not just append to log)
        print("-" * 80)
        print(f"Refinement complete:")
        print(f"  Final error: {best_error:.4f}")
        print(f"  Final IoU: {best_iou:.3f}")
        print(f"  Final edge chamfer: {best_edge:.4f}")
        print(f"  Iterations: {iteration + 1}")
        print(f"  Elapsed time: {elapsed:.1f}s")
        print(f"  Success: {success}")
        print(f"Final parameters:")
        print(f"  Azimuth: {best_params.azimuth_deg:.2f}deg (d{best_params.azimuth_deg - initial_params.azimuth_deg:+.2f}deg)")
        print(f"  Elevation: {best_params.elevation_deg:.2f}deg (d{best_params.elevation_deg - initial_params.elevation_deg:+.2f}deg)")
        print(f"  Radius: {best_params.radius:.3f} (d{best_params.radius - initial_params.radius:+.3f})")
        print(f"  Yaw: {best_params.obj_yaw_deg:.2f}deg (d{best_params.obj_yaw_deg - initial_params.obj_yaw_deg:+.2f}deg)")
        print("=" * 80)

        # Also append to log_lines for file output
        log_lines.append("-" * 80)
        log_lines.append(f"Refinement complete:")
        log_lines.append(f"  Final error: {best_error:.4f}")
        log_lines.append(f"  Final IoU: {best_iou:.3f}")
        log_lines.append(f"  Final edge chamfer: {best_edge:.4f}")
        log_lines.append(f"  Iterations: {iteration + 1}")
        log_lines.append(f"  Elapsed time: {elapsed:.1f}s")
        log_lines.append(f"  Success: {success}")
        log_lines.append(f"Final parameters:")
        log_lines.append(f"  Azimuth: {best_params.azimuth_deg:.2f}deg (d{best_params.azimuth_deg - initial_params.azimuth_deg:+.2f}deg)")
        log_lines.append(f"  Elevation: {best_params.elevation_deg:.2f}deg (d{best_params.elevation_deg - initial_params.elevation_deg:+.2f}deg)")
        log_lines.append(f"  Radius: {best_params.radius:.3f} (d{best_params.radius - initial_params.radius:+.3f})")
        log_lines.append(f"  Yaw: {best_params.obj_yaw_deg:.2f}deg (d{best_params.obj_yaw_deg - initial_params.obj_yaw_deg:+.2f}deg)")
        log_lines.append("=" * 80)

        # Write log file
        if log_file is not None:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            with open(log_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(log_lines))

        # Metadata
        metadata = {
            "iterations": iteration + 1,
            "elapsed_time": elapsed,
            "success": success,
            "threshold_met_iteration": threshold_met_iteration,
            "initial_error": float(initial_error),  # FIXED: Use actual initial error!
            "final_error": float(best_error),
            "final_iou": float(best_iou),
            "final_edge_chamfer": float(best_edge),
            "yaw_unfrozen": yaw_unfrozen,
            "initial_params": initial_params.to_dict(),
            "final_params": best_params.to_dict()
        }

        return best_params, best_error, metadata
