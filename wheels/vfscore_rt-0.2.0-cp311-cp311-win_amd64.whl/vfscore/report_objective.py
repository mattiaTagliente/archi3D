"""Generate HTML report for objective scoring results."""

import json
from pathlib import Path

from jinja2 import Template
from rich.console import Console

console = Console(legacy_windows=True)


def generate_objective_report(config) -> Path:
    """Generate HTML report from objective scoring results.

    Reads:
    - outputs/results/objective_per_item.jsonl
    - outputs/objective/<item_id>/hq/render.png
    - outputs/preprocess/refs/<item_id>/gt_1.png

    Creates:
    - outputs/report/objective_report.html

    Args:
        config: VFScore configuration

    Returns:
        Path to generated report
    """
    results_dir = config.paths.out_dir / "results"
    jsonl_path = results_dir / "objective_per_item.jsonl"

    if not jsonl_path.exists():
        console.print(
            f"[yellow]No aggregated results found at {jsonl_path}. "
            "Run 'vfscore objective' first.[/yellow]"
        )
        return None

    # Load results
    results = []
    with open(jsonl_path, "r") as f:
        for line in f:
            results.append(json.loads(line))

    if not results:
        console.print("[yellow]No objective results to report[/yellow]")
        return None

    # Load summary statistics
    summary_path = results_dir / "objective_summary.json"
    summary = {}
    if summary_path.exists():
        with open(summary_path, "r") as f:
            summary = json.load(f)

    # Prepare data for template
    items = []
    for result in results:
        item_id = result["item_id"]

        # Get image paths
        gt_path = config.paths.out_dir / "preprocess" / "refs" / item_id / "gt_1.png"
        hq_path = config.objective.priors_cache_dir / item_id / "hq" / "render.png"

        # Make paths relative to report directory
        report_dir = config.paths.out_dir / "report"
        gt_rel = Path("..") / gt_path.relative_to(config.paths.out_dir)
        hq_rel = Path("..") / hq_path.relative_to(config.paths.out_dir)

        items.append({
            "item_id": item_id,
            "final_score": result["final_score"],
            "lpips": result["lpips"],
            "pose_confidence": result["pose_confidence"],
            "gt_image": str(gt_rel).replace("\\", "/"),
            "hq_image": str(hq_rel).replace("\\", "/"),
            "params": result.get("params", {}),
        })

    # Sort by score (descending)
    items.sort(key=lambda x: x["final_score"], reverse=True)

    # Generate HTML
    template = Template(REPORT_TEMPLATE)
    html = template.render(items=items, summary=summary, n_items=len(items))

    # Write report
    report_dir = config.paths.out_dir / "report"
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / "objective_report.html"

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)

    console.print(f"[green]Objective report generated: {report_path}[/green]")
    return report_path


REPORT_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VFScore - Objective Scoring Report</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .summary {
            background: #f8f9fa;
            padding: 30px 40px;
            border-bottom: 1px solid #e9ecef;
        }

        .summary h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .stat-label {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 5px;
        }

        .stat-value {
            font-size: 1.8em;
            font-weight: bold;
            color: #667eea;
        }

        .stat-range {
            font-size: 0.85em;
            color: #999;
            margin-top: 5px;
        }

        .results {
            padding: 40px;
        }

        .results h2 {
            color: #333;
            margin-bottom: 30px;
        }

        .item-grid {
            display: grid;
            gap: 30px;
        }

        .item-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 20px;
            align-items: start;
        }

        .item-images {
            display: flex;
            gap: 15px;
        }

        .item-image {
            text-align: center;
        }

        .item-image img {
            width: 200px;
            height: 200px;
            object-fit: contain;
            background: white;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .item-image .label {
            font-size: 0.85em;
            color: #666;
            margin-top: 5px;
        }

        .item-info {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .item-id {
            font-size: 1.2em;
            font-weight: bold;
            color: #333;
        }

        .score-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }

        .score-box {
            background: white;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid #667eea;
        }

        .score-label {
            font-size: 0.85em;
            color: #666;
            margin-bottom: 5px;
        }

        .score-value {
            font-size: 1.5em;
            font-weight: bold;
            color: #333;
        }

        .score-value.high {
            color: #28a745;
        }

        .score-value.medium {
            color: #ffc107;
        }

        .score-value.low {
            color: #dc3545;
        }

        .params {
            background: white;
            padding: 15px;
            border-radius: 6px;
            font-size: 0.9em;
            color: #666;
        }

        .params strong {
            color: #333;
        }

        .footer {
            background: #f8f9fa;
            padding: 20px 40px;
            text-align: center;
            color: #666;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>VFScore - Objective Scoring Report</h1>
            <p>Pose-Adjusted LPIPS Visual Fidelity Assessment</p>
        </div>

        {% if summary %}
        <div class="summary">
            <h2>Summary Statistics</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-label">Items Evaluated</div>
                    <div class="stat-value">{{ n_items }}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Avg Final Score</div>
                    <div class="stat-value">{{ "%.3f"|format(summary.final_score.mean) }}</div>
                    <div class="stat-range">{{ "%.3f"|format(summary.final_score.min) }} - {{ "%.3f"|format(summary.final_score.max) }}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Avg LPIPS</div>
                    <div class="stat-value">{{ "%.3f"|format(summary.lpips.mean) }}</div>
                    <div class="stat-range">{{ "%.3f"|format(summary.lpips.min) }} - {{ "%.3f"|format(summary.lpips.max) }}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Avg Pose Confidence</div>
                    <div class="stat-value">{{ "%.3f"|format(summary.pose_confidence.mean) }}</div>
                    <div class="stat-range">{{ "%.3f"|format(summary.pose_confidence.min) }} - {{ "%.3f"|format(summary.pose_confidence.max) }}</div>
                </div>
            </div>
        </div>
        {% endif %}

        <div class="results">
            <h2>Item Results ({{ n_items }} items)</h2>
            <div class="item-grid">
                {% for item in items %}
                <div class="item-card">
                    <div class="item-images">
                        <div class="item-image">
                            <img src="{{ item.gt_image }}" alt="Ground Truth">
                            <div class="label">Ground Truth</div>
                        </div>
                        <div class="item-image">
                            <img src="{{ item.hq_image }}" alt="HQ Render">
                            <div class="label">HQ Render (Best Pose)</div>
                        </div>
                    </div>
                    <div class="item-info">
                        <div class="item-id">{{ item.item_id }}</div>
                        <div class="score-grid">
                            <div class="score-box">
                                <div class="score-label">Final Score</div>
                                <div class="score-value {% if item.final_score >= 0.7 %}high{% elif item.final_score >= 0.4 %}medium{% else %}low{% endif %}">
                                    {{ "%.3f"|format(item.final_score) }}
                                </div>
                            </div>
                            <div class="score-box">
                                <div class="score-label">LPIPS Distance</div>
                                <div class="score-value">{{ "%.3f"|format(item.lpips) }}</div>
                            </div>
                            <div class="score-box">
                                <div class="score-label">Pose Confidence (IoU)</div>
                                <div class="score-value">{{ "%.3f"|format(item.pose_confidence) }}</div>
                            </div>
                        </div>
                        <div class="params">
                            <strong>Camera/Object Parameters:</strong>
                            FOV: {{ "%.1f"|format(item.params.fov_deg) }}°,
                            Azimuth: {{ "%.1f"|format(item.params.azimuth_deg) }}°,
                            Elevation: {{ "%.1f"|format(item.params.elevation_deg) }}°,
                            Radius: {{ "%.2f"|format(item.params.radius) }},
                            Yaw: {{ "%.1f"|format(item.params.obj_yaw_deg) }}°
                        </div>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>

        <div class="footer">
            Generated by VFScore | Objective Pose-Adjusted LPIPS Scoring
        </div>
    </div>
</body>
</html>
"""
