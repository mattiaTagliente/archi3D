"""Ground truth photo preprocessing: segmentation, standardization, labeling."""

import json
from pathlib import Path
from typing import Tuple

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from rembg import remove
from rich.console import Console
from rich.progress import Progress, TextColumn, BarColumn, TaskProgressColumn

from vfscore.config import Config
from vfscore.utils import make_gt_id

# Use legacy_windows for Windows compatibility
console = Console(legacy_windows=True)


def load_manifest(manifest_path: Path) -> list:
    """Load manifest from JSONL file."""
    records = []
    with open(manifest_path, "r", encoding="utf-8") as f:
        for line in f:
            records.append(json.loads(line))
    return records


def remove_background(image: Image.Image, model: str = "u2net") -> Image.Image:
    """Remove background using rembg with CPU-only mode and smaller model for stability."""
    # Convert to RGB if needed
    if image.mode != "RGB":
        image = image.convert("RGB")

    # Force CPU-only mode for stability on Windows (avoid ONNX GPU issues)
    # Use u2netp (smaller model, ~4MB vs ~170MB) for reduced memory pressure
    from rembg import new_session

    # Create CPU-only session with smaller model
    # providers=['CPUExecutionProvider'] forces CPU-only mode
    session = new_session(
        model_name="u2netp",  # Smaller model (4.7MB vs 176MB for u2net)
        providers=['CPUExecutionProvider']  # CPU-only, no GPU
    )

    # Remove background with CPU-only session
    output = remove(image, session=session)

    # Explicitly cleanup session to free ONNX resources
    del session

    return output


def get_tight_bbox(alpha: np.ndarray, margin_frac: float = 0.05) -> Tuple[int, int, int, int]:
    """Get tight bounding box from alpha channel with margin."""
    # Find non-zero pixels
    coords = np.column_stack(np.where(alpha > 0))

    if len(coords) == 0:
        # Return full image if no foreground detected
        return 0, 0, alpha.shape[1], alpha.shape[0]

    # Get bbox
    y_min, x_min = coords.min(axis=0)
    y_max, x_max = coords.max(axis=0)

    # Add margin
    h, w = alpha.shape
    margin_x = int((x_max - x_min) * margin_frac)
    margin_y = int((y_max - y_min) * margin_frac)

    x_min = max(0, x_min - margin_x)
    y_min = max(0, y_min - margin_y)
    x_max = min(w, x_max + margin_x)
    y_max = min(h, y_max + margin_y)

    return x_min, y_min, x_max, y_max


def get_exact_bbox(
    alpha: np.ndarray,
    border_safety_margin_fraction: float = 0.0,
    edge_threshold: int = 64
) -> Tuple[int, int, int, int]:
    """Get exact bounding box from alpha channel with border safety margin.

    Uses the same logic as radius calibration to ensure proper transparent border:
    1. Find opaque pixels using edge_threshold
    2. Get tight bounding box
    3. Add border_safety_margin_fraction (as fraction of image size) around object

    Args:
        alpha: Alpha channel as numpy array (0-255)
        border_safety_margin_fraction: Required border as fraction of image size (e.g., 0.02 = 2%)
                                       Matches the same parameter used in radius calibration
        edge_threshold: Threshold for opaque pixels (default: 64, same as radius calibration)
                       Only pixels with alpha > edge_threshold are considered solid object

    Returns:
        (x_min, y_min, x_max, y_max) tuple
    """
    # Find opaque pixels (using edge_threshold to ignore anti-aliased edges)
    coords = np.column_stack(np.where(alpha > edge_threshold))

    if len(coords) == 0:
        # Return full image if no foreground detected
        return 0, 0, alpha.shape[1], alpha.shape[0]

    # Get tight bbox around opaque pixels
    y_min, x_min = coords.min(axis=0)
    y_max, x_max = coords.max(axis=0)

    # Add border safety margin (calculated as fraction of image size, matching radius calibration)
    h, w = alpha.shape
    border_px = int(np.ceil(min(h, w) * border_safety_margin_fraction))

    x_min = max(0, x_min - border_px)
    y_min = max(0, y_min - border_px)
    x_max = min(w, x_max + border_px + 1)  # +1 to include the last pixel
    y_max = min(h, y_max + border_px + 1)

    return x_min, y_min, x_max, y_max


def calculate_background_ratio(alpha: np.ndarray) -> float:
    """Calculate background-to-object ratio.

    Args:
        alpha: Alpha channel as numpy array (0-255)

    Returns:
        Ratio of background area to object area: (total_area - object_area) / object_area
        Lower is better (less background relative to object)
    """
    # Count non-zero pixels (object)
    object_area = np.count_nonzero(alpha > 0)

    if object_area == 0:
        return float('inf')  # No object detected

    total_area = alpha.shape[0] * alpha.shape[1]
    background_area = total_area - object_area

    ratio = background_area / object_area
    return ratio


def resize_to_max_dimension(image: Image.Image, max_dim: int) -> Image.Image:
    """Resize image so longest dimension equals max_dim, preserving aspect ratio.

    Args:
        image: PIL Image
        max_dim: Maximum dimension (e.g., 1024)

    Returns:
        Resized PIL Image
    """
    w, h = image.size

    if w <= max_dim and h <= max_dim:
        return image  # No resize needed

    # Calculate scale factor
    scale = max_dim / max(w, h)
    new_w = int(w * scale)
    new_h = int(h * scale)

    return image.resize((new_w, new_h), Image.Resampling.LANCZOS)


def crop_exact(
    image: Image.Image,
    border_safety_margin_fraction: float = 0.0,
    edge_threshold: int = 64
) -> Tuple[Image.Image, Tuple[int, int, int, int]]:
    """Crop to exact object bounding box with border safety margin (no square padding).

    Uses the same border safety logic as radius calibration to ensure proper
    transparent border around the object.

    Args:
        image: PIL Image with alpha channel
        border_safety_margin_fraction: Required border as fraction of image size (e.g., 0.02 = 2%)
        edge_threshold: Threshold for opaque pixels (default: 64, matching radius calibration)

    Returns:
        (cropped_image, bbox) where bbox is (x_min, y_min, x_max, y_max)
    """
    # Get alpha channel
    if image.mode == "RGBA":
        alpha = np.array(image.split()[3])
    else:
        # If no alpha, assume full image is foreground
        alpha = np.ones((image.height, image.width), dtype=np.uint8) * 255

    # Get exact bbox with border safety margin
    x_min, y_min, x_max, y_max = get_exact_bbox(
        alpha,
        border_safety_margin_fraction=border_safety_margin_fraction,
        edge_threshold=edge_threshold
    )

    # Crop
    cropped = image.crop((x_min, y_min, x_max, y_max))

    return cropped, (x_min, y_min, x_max, y_max)


def crop_exact_and_pad_square(
    image: Image.Image,
    bg_color: Tuple[int, int, int],
    border_safety_margin_fraction: float = 0.0,
    edge_threshold: int = 64
) -> Image.Image:
    """Crop to exact object bbox, then pad to square (for pose estimation).

    Uses the same border safety logic as radius calibration to ensure proper
    transparent border around the object.

    Args:
        image: PIL Image with alpha channel
        bg_color: Background color for padding
        border_safety_margin_fraction: Required border as fraction of image size (e.g., 0.02 = 2%)
        edge_threshold: Threshold for opaque pixels (default: 64, matching radius calibration)

    Returns:
        Square PIL Image (RGBA) with object centered and alpha channel preserved
    """
    # Get exact crop first with border safety margin
    cropped, _ = crop_exact(
        image,
        border_safety_margin_fraction=border_safety_margin_fraction,
        edge_threshold=edge_threshold
    )

    # Determine square canvas size (max of width/height)
    w, h = cropped.size
    canvas_size = max(w, h)

    # CRITICAL FIX: Create RGBA canvas to preserve alpha channel for mask extraction
    # Background padding gets ZERO alpha (transparent) so it's treated as background in mask
    canvas = Image.new("RGBA", (canvas_size, canvas_size), bg_color + (0,))

    # Calculate paste position (center)
    paste_x = (canvas_size - w) // 2
    paste_y = (canvas_size - h) // 2

    # Paste with alpha compositing to preserve transparency
    if cropped.mode == "RGBA":
        canvas.paste(cropped, (paste_x, paste_y), cropped)
    else:
        # Convert to RGBA if needed
        cropped_rgba = cropped.convert("RGBA")
        canvas.paste(cropped_rgba, (paste_x, paste_y))

    return canvas


def crop_and_pad(image: Image.Image, canvas_size: int, bg_color: Tuple[int, int, int]) -> Image.Image:
    """Crop to content and pad to square canvas with black background."""
    # Get alpha channel
    if image.mode == "RGBA":
        alpha = np.array(image.split()[3])
    else:
        # If no alpha, assume full image is foreground
        alpha = np.ones((image.height, image.width), dtype=np.uint8) * 255
    
    # Get tight bbox
    x_min, y_min, x_max, y_max = get_tight_bbox(alpha)
    
    # Crop
    cropped = image.crop((x_min, y_min, x_max, y_max))
    
    # Create square canvas
    canvas = Image.new("RGB", (canvas_size, canvas_size), bg_color)
    
    # Calculate paste position (center)
    paste_w, paste_h = cropped.size
    
    # Scale down if too large
    if paste_w > canvas_size or paste_h > canvas_size:
        scale = min(canvas_size / paste_w, canvas_size / paste_h)
        new_w = int(paste_w * scale)
        new_h = int(paste_h * scale)
        cropped = cropped.resize((new_w, new_h), Image.Resampling.LANCZOS)
        paste_w, paste_h = new_w, new_h
    
    paste_x = (canvas_size - paste_w) // 2
    paste_y = (canvas_size - paste_h) // 2
    
    # Paste with alpha if available
    if cropped.mode == "RGBA":
        canvas.paste(cropped, (paste_x, paste_y), cropped)
    else:
        canvas.paste(cropped, (paste_x, paste_y))
    
    return canvas


def add_label(image: Image.Image, label: str, bar_frac: float = 0.06) -> Image.Image:
    """Add label bar at the top of the image."""
    w, h = image.size
    bar_height = int(h * bar_frac)
    
    # Create new image with space for label
    labeled = Image.new("RGB", (w, h + bar_height), (0, 0, 0))
    labeled.paste(image, (0, bar_height))
    
    # Draw label
    draw = ImageDraw.Draw(labeled)
    
    # Try to use a nice font, fall back to default if not available
    try:
        font_size = int(bar_height * 0.6)
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    # Get text bbox
    bbox = draw.textbbox((0, 0), label, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    
    # Center text
    text_x = (w - text_w) // 2
    text_y = (bar_height - text_h) // 2
    
    draw.text((text_x, text_y), label, fill=(255, 255, 255), font=font)
    
    return labeled


def preprocess_gt_image(
    input_path: Path,
    output_path: Path,
    label: str,
    config: Config,
) -> None:
    """Preprocess a single GT image."""
    # Load image
    image = Image.open(input_path)
    
    # Convert to sRGB
    if image.mode != "RGB":
        image = image.convert("RGB")
    
    # Remove background
    image_no_bg = remove_background(image, config.preprocess.segmentation_model)
    
    # Crop and pad
    standardized = crop_and_pad(
        image_no_bg,
        config.preprocess.canvas_px,
        tuple(config.preprocess.bg_rgb)
    )
    
    # Add label (but not yet - we'll do this in packetize step for consistency)
    # For now just save the standardized image
    
    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    standardized.save(output_path, "PNG")


def run_preprocess_gt(config: Config) -> None:
    """Run ground truth preprocessing for all items with GT selection and dual-mode output."""
    # Load manifest
    manifest_path = config.paths.out_dir / "manifest.jsonl"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}. Run 'vfscore ingest' first.")

    manifest = load_manifest(manifest_path)

    console.print(f"\n[bold]Manifest contains {len(manifest)} item(s)...[/bold]")

    # OPTIMIZATION: Deduplicate by gt_id first to avoid processing same GT images multiple times
    # When the same product+variant is processed by multiple algorithms, we only need to
    # preprocess the GT images once and share them across all algorithms
    gt_records = {}  # gt_id -> ref_paths

    for record in manifest:
        gt_id = make_gt_id(record["product_id"], record.get("variant", ""))
        ref_paths = tuple(record["ref_paths"])  # Use tuple for hashability

        # Only store the first occurrence of each gt_id
        # (all records with same gt_id should have same ref_paths)
        if gt_id not in gt_records:
            gt_records[gt_id] = ref_paths

    console.print(f"[bold]Found {len(gt_records)} unique GT set(s) to check[/bold]")

    # Check if exact crop is enabled
    exact_crop_enabled = config.preprocess.exact_crop_enabled
    gt_selection_enabled = config.preprocess.gt_selection_enabled

    if gt_selection_enabled:
        console.print("[bold]GT selection enabled - will select best GT per item[/bold]")
    if exact_crop_enabled:
        console.print("[bold]Exact crop mode enabled - will generate square + exact versions[/bold]")

    # Pre-filter to find GTs that need processing (check cache)
    gts_to_process = []
    skipped = 0

    for gt_id, ref_paths_tuple in gt_records.items():
        ref_paths = [Path(p) for p in ref_paths_tuple]
        output_dir = config.paths.out_dir / "preprocess" / "refs" / gt_id
        metadata_path = output_dir / "metadata.json"

        # Check if already processed
        if metadata_path.exists():
            try:
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)

                # Verify that required files exist
                all_files_exist = True
                for gt_meta in metadata.get("gts", []):
                    # Check square files (always required)
                    square_path = output_dir / gt_meta.get("square_path", "")
                    mask_square_path = output_dir / gt_meta.get("mask_square_path", "")

                    if not square_path.exists() or not mask_square_path.exists():
                        all_files_exist = False
                        break

                    # Check exact files if enabled
                    if exact_crop_enabled:
                        exact_path = output_dir / gt_meta.get("exact_path", "")
                        mask_exact_path = output_dir / gt_meta.get("mask_exact_path", "")

                        if not exact_path.exists() or not mask_exact_path.exists():
                            all_files_exist = False
                            break

                if all_files_exist:
                    # All required files exist - skip this GT
                    skipped += 1
                    continue

            except Exception:
                # If metadata is corrupted, reprocess
                pass

        # Need to process this GT
        gts_to_process.append((gt_id, ref_paths))

    if skipped > 0:
        console.print(f"[yellow]Skipped {skipped} already-processed GT set(s)[/yellow]")

    if not gts_to_process:
        console.print(f"[green]All {len(gt_records)} GT set(s) already processed![/green]")
        return

    console.print(f"[bold]Processing {len(gts_to_process)} GT set(s)...[/bold]")

    processed_gts = 0
    selected_gts = 0

    # Use simple progress without emojis for Windows compatibility
    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        disable=False
    ) as progress:
        task = progress.add_task("Preprocessing GT images", total=len(gts_to_process))

        for gt_id, ref_paths_tuple in gts_to_process:
            ref_paths = list(ref_paths_tuple) if isinstance(ref_paths_tuple, tuple) else ref_paths_tuple
            output_dir = config.paths.out_dir / "preprocess" / "refs" / gt_id
            output_dir.mkdir(parents=True, exist_ok=True)
            metadata_path = output_dir / "metadata.json"

            try:
                # Stage 1: Analyze all GTs to calculate ratios
                console.print(f"  {gt_id}: Analyzing {len(ref_paths)} GT image(s)...")
                gt_analysis = []
                for idx, ref_path in enumerate(ref_paths):
                    if not ref_path.exists():
                        console.print(f"[yellow]Warning: GT image not found: {ref_path}[/yellow]")
                        continue

                    # Load and remove background (get transparent background first)
                    image = Image.open(ref_path).convert("RGB")
                    image_no_bg = remove_background(image, config.preprocess.segmentation_model)

                    # Extract alpha channel from segmented image (transparent background)
                    if image_no_bg.mode == "RGBA":
                        alpha_full = np.array(image_no_bg.split()[3])
                    else:
                        alpha_full = np.ones((image_no_bg.height, image_no_bg.width), dtype=np.uint8) * 255

                    # CRITICAL: Get exact crop bbox from alpha (after segmentation, before ratio calculation)
                    # This ensures we're measuring background within the cropped region only
                    x_min, y_min, x_max, y_max = get_exact_bbox(alpha_full, border_safety_margin_fraction=0.0)

                    # Extract the CROPPED alpha region
                    alpha_cropped = alpha_full[y_min:y_max, x_min:x_max]

                    # Calculate background ratio on CROPPED region (not full image)
                    ratio = calculate_background_ratio(alpha_cropped)
                    object_area = int(np.count_nonzero(alpha_cropped > 0))
                    total_area = int(alpha_cropped.shape[0] * alpha_cropped.shape[1])
                    background_area = total_area - object_area

                    # Store both full and cropped dimensions for later processing
                    crop_bbox = (int(x_min), int(y_min), int(x_max), int(y_max))
                    crop_dimensions = (int(x_max - x_min), int(y_max - y_min))

                    gt_analysis.append({
                        "index": idx,
                        "path": str(ref_path),
                        "ratio": float(ratio),
                        "object_area": object_area,
                        "background_area": background_area,
                        "total_area": total_area,
                        "crop_bbox": crop_bbox,
                        "crop_dimensions": crop_dimensions,
                        "image_no_bg": image_no_bg,
                        "alpha_full": alpha_full
                    })

                    # Print analysis for this GT (showing cropped measurements)
                    console.print(f"    GT#{idx+1}: ratio={ratio:.3f}, "
                                f"object={object_area:,}px, background={background_area:,}px "
                                f"({background_area*100.0/total_area:.1f}% background) "
                                f"[crop: {crop_dimensions[0]}x{crop_dimensions[1]}]")

                if not gt_analysis:
                    console.print(f"[yellow]Warning: No valid GT images for {gt_id}[/yellow]")
                    progress.advance(task)
                    continue

                # Stage 2: Select best GT (minimum ratio) or process all
                if gt_selection_enabled:
                    # Select GT with minimum background ratio
                    best_gt = min(gt_analysis, key=lambda x: x["ratio"])
                    selected_index = best_gt["index"]
                    gts_to_process = [best_gt]
                    selected_gts += 1
                    console.print(f"  [bold green]{gt_id}: Selected GT#{selected_index+1}[/bold green] "
                                f"(ratio={best_gt['ratio']:.3f}, best of {len(gt_analysis)} GTs)")
                else:
                    # Process all GTs
                    gts_to_process = gt_analysis
                    selected_index = -1  # No selection
                    console.print(f"  {gt_id}: Processing all {len(gt_analysis)} GTs (selection disabled)")

                # Stage 3: Process selected/all GTs
                metadata_list = []

                for gt_data in gts_to_process:
                    idx = gt_data["index"]
                    image_no_bg = gt_data["image_no_bg"]
                    alpha_full = gt_data["alpha_full"]
                    ratio = gt_data["ratio"]
                    is_selected = (idx == selected_index) if gt_selection_enabled else False

                    # Generate output paths
                    gt_num = idx + 1
                    square_path = output_dir / f"gt_{gt_num}_square.png"
                    exact_path = output_dir / f"gt_{gt_num}_exact.png"
                    mask_square_path = output_dir / f"gt_{gt_num}_mask_square.png"
                    mask_exact_path = output_dir / f"gt_{gt_num}_mask_exact.png"

                    # Create square version (exact crop + pad to square)
                    # CRITICAL: This now returns RGBA with alpha channel preserved
                    square_image_rgba = crop_exact_and_pad_square(
                        image_no_bg,
                        tuple(config.preprocess.bg_rgb),
                        border_safety_margin_fraction=config.preprocess.border_safety_margin_fraction,
                        edge_threshold=config.preprocess.edge_threshold
                    )

                    # Resize square to canvas_px
                    if square_image_rgba.size[0] != config.preprocess.canvas_px:
                        square_image_rgba = square_image_rgba.resize(
                            (config.preprocess.canvas_px, config.preprocess.canvas_px),
                            Image.Resampling.LANCZOS
                        )

                    # Save RGB version for GT image (composite alpha over specified background color)
                    # Create background with specified color
                    bg_layer = Image.new("RGB", square_image_rgba.size, tuple(config.preprocess.bg_rgb))
                    # Composite RGBA over background using alpha channel as mask
                    square_image_rgb = Image.alpha_composite(
                        bg_layer.convert("RGBA"),
                        square_image_rgba
                    ).convert("RGB")
                    square_image_rgb.save(square_path, "PNG")

                    # Extract and save mask from alpha channel
                    if square_image_rgba.mode == "RGBA":
                        square_mask = square_image_rgba.split()[3]
                    else:
                        # Fallback: create opaque mask if somehow not RGBA
                        square_mask = Image.new("L", square_image_rgba.size, 255)
                    square_mask.save(mask_square_path, "PNG")

                    square_dimensions = square_image_rgba.size

                    # Create exact crop version (if enabled)
                    if exact_crop_enabled:
                        exact_image, bbox = crop_exact(
                            image_no_bg,
                            border_safety_margin_fraction=config.preprocess.border_safety_margin_fraction,
                            edge_threshold=config.preprocess.edge_threshold
                        )

                        # Resize to max dimension if needed
                        exact_image = resize_to_max_dimension(
                            exact_image,
                            config.preprocess.exact_crop_max_dimension
                        )

                        exact_image_rgb = exact_image.convert("RGB")
                        exact_image_rgb.save(exact_path, "PNG")

                        # Extract mask from exact version
                        if exact_image.mode == "RGBA":
                            exact_mask = exact_image.split()[3]
                        else:
                            exact_mask = Image.new("L", exact_image.size, 255)
                        exact_mask.save(mask_exact_path, "PNG")

                        exact_dimensions = exact_image.size
                        exact_bbox = bbox
                    else:
                        exact_dimensions = None
                        exact_bbox = None

                    # Build metadata for this GT (ensure all types are JSON-serializable)
                    gt_metadata = {
                        "gt_index": int(idx),
                        "gt_number": int(gt_num),
                        "is_selected": bool(is_selected),
                        "background_ratio": float(ratio),
                        "object_area": int(gt_data.get("object_area", 0)),
                        "background_area": int(gt_data.get("background_area", 0)),
                        "total_area": int(gt_data.get("total_area", 0)),
                        "square_path": f"gt_{gt_num}_square.png",
                        "mask_square_path": f"gt_{gt_num}_mask_square.png",
                        "square_dimensions": [int(d) for d in square_dimensions],
                        "original_path": str(gt_data["path"])
                    }

                    if exact_crop_enabled:
                        gt_metadata.update({
                            "exact_path": f"gt_{gt_num}_exact.png",
                            "mask_exact_path": f"gt_{gt_num}_mask_exact.png",
                            "exact_dimensions": [int(d) for d in exact_dimensions],
                            "exact_bbox": [int(b) for b in exact_bbox]
                        })

                    metadata_list.append(gt_metadata)

                # Save metadata (ensure all types are JSON-serializable)
                metadata = {
                    "gt_id": str(gt_id),
                    "num_gts": int(len(ref_paths)),
                    "num_processed": int(len(gts_to_process)),
                    "selection_enabled": bool(gt_selection_enabled),
                    "selected_index": int(selected_index) if gt_selection_enabled and selected_index >= 0 else None,
                    "exact_crop_enabled": bool(exact_crop_enabled),
                    "gts": metadata_list
                }

                with open(metadata_path, "w", encoding="utf-8") as f:
                    json.dump(metadata, f, indent=2)

                processed_gts += 1

            except Exception as e:
                console.print(f"[red]Error processing {gt_id}: {e}[/red]")

            progress.advance(task)

    console.print(f"[green]Successfully processed {processed_gts} GT set(s)[/green]")
    if gt_selection_enabled:
        console.print(f"[green]Selected {selected_gts} optimal GT image(s)[/green]")


def preprocess_gt_images_standalone(
    ref_images_paths: list,
    output_dir: Path,
    config: Config
) -> bool:
    """Standalone GT preprocessing for archi3D/external integration.

    This function preprocesses GT images without requiring a manifest file.
    It replicates the essential preprocessing steps from run_preprocess_gt().

    Args:
        ref_images_paths: List of Path objects to reference images
        output_dir: Directory to write preprocessed images (the gt_id subfolder)
        config: VFScore Config object

    Returns:
        True if successful, False otherwise
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    metadata_path = output_dir / "metadata.json"

    # Check if already processed
    if metadata_path.exists():
        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            # Verify that required files exist
            all_files_exist = True
            for gt_meta in metadata.get("gts", []):
                square_path = output_dir / gt_meta.get("square_path", "")
                mask_square_path = output_dir / gt_meta.get("mask_square_path", "")

                if not square_path.exists() or not mask_square_path.exists():
                    all_files_exist = False
                    break

                if config.preprocess.exact_crop_enabled:
                    exact_path = output_dir / gt_meta.get("exact_path", "")
                    mask_exact_path = output_dir / gt_meta.get("mask_exact_path", "")

                    if not exact_path.exists() or not mask_exact_path.exists():
                        all_files_exist = False
                        break

            if all_files_exist:
                # Already preprocessed - skip
                return True

        except Exception:
            # If metadata is corrupted, reprocess
            pass

    gt_selection_enabled = config.preprocess.gt_selection_enabled
    exact_crop_enabled = config.preprocess.exact_crop_enabled

    # Stage 1: Analyze all GTs
    gt_analysis = []

    for idx, ref_path in enumerate(ref_images_paths):
        if not ref_path.exists():
            print(f"[WARNING] GT image not found: {ref_path}")
            continue

        # Load and remove background
        print(f"[DEBUG PREPROCESS] Processing GT #{idx+1}/{len(ref_images_paths)}: {ref_path.name}")
        import sys
        sys.stdout.flush()

        print(f"[DEBUG PREPROCESS] Loading image...")
        sys.stdout.flush()
        image = Image.open(ref_path).convert("RGB")

        print(f"[DEBUG PREPROCESS] Removing background (this may take 5-10 seconds)...")
        sys.stdout.flush()
        image_no_bg = remove_background(image, config.preprocess.segmentation_model)
        print(f"[DEBUG PREPROCESS] Background removed successfully")
        sys.stdout.flush()

        # Explicitly delete original image to free memory immediately
        del image
        import gc
        gc.collect()

        # Extract alpha channel
        if image_no_bg.mode == "RGBA":
            alpha_full = np.array(image_no_bg.split()[3])
        else:
            alpha_full = np.ones((image_no_bg.height, image_no_bg.width), dtype=np.uint8) * 255

        # Get exact crop bbox
        x_min, y_min, x_max, y_max = get_exact_bbox(alpha_full, border_safety_margin_fraction=0.0)

        # Extract cropped alpha region
        alpha_cropped = alpha_full[y_min:y_max, x_min:x_max]

        # Calculate background ratio
        ratio = calculate_background_ratio(alpha_cropped)
        object_area = int(np.count_nonzero(alpha_cropped > 0))
        total_area = int(alpha_cropped.shape[0] * alpha_cropped.shape[1])
        background_area = total_area - object_area

        crop_bbox = (int(x_min), int(y_min), int(x_max), int(y_max))
        crop_dimensions = (int(x_max - x_min), int(y_max - y_min))

        gt_analysis.append({
            "index": idx,
            "path": str(ref_path),
            "ratio": float(ratio),
            "object_area": object_area,
            "background_area": background_area,
            "total_area": total_area,
            "crop_bbox": crop_bbox,
            "crop_dimensions": crop_dimensions,
            "image_no_bg": image_no_bg,
            "alpha_full": alpha_full
        })

    if not gt_analysis:
        print("[ERROR] No valid GT images")
        return False

    # Stage 2: Select best GT (minimum ratio) if selection is enabled
    if gt_selection_enabled:
        best_gt = min(gt_analysis, key=lambda x: x["ratio"])
        selected_index = best_gt["index"]
        gts_to_process = [best_gt]
    else:
        gts_to_process = gt_analysis
        selected_index = -1

    # Stage 3: Process GTs
    metadata_list = []

    for gt_data in gts_to_process:
        idx = gt_data["index"]
        image_no_bg = gt_data["image_no_bg"]
        alpha_full = gt_data["alpha_full"]
        ratio = gt_data["ratio"]
        is_selected = (idx == selected_index) if gt_selection_enabled else False

        # Generate output paths
        gt_num = idx + 1
        square_path = output_dir / f"gt_{gt_num}_square.png"
        exact_path = output_dir / f"gt_{gt_num}_exact.png"
        mask_square_path = output_dir / f"gt_{gt_num}_mask_square.png"
        mask_exact_path = output_dir / f"gt_{gt_num}_mask_exact.png"

        # Create square version (exact crop + pad to square)
        square_image_rgba = crop_exact_and_pad_square(
            image_no_bg,
            tuple(config.preprocess.bg_rgb),
            border_safety_margin_fraction=config.preprocess.border_safety_margin_fraction,
            edge_threshold=config.preprocess.edge_threshold
        )

        # Resize square to canvas_px
        if square_image_rgba.size[0] != config.preprocess.canvas_px:
            square_image_rgba = square_image_rgba.resize(
                (config.preprocess.canvas_px, config.preprocess.canvas_px),
                Image.Resampling.LANCZOS
            )

        # Save RGB version for GT image
        bg_layer = Image.new("RGB", square_image_rgba.size, tuple(config.preprocess.bg_rgb))
        square_image_rgb = Image.alpha_composite(
            bg_layer.convert("RGBA"),
            square_image_rgba
        ).convert("RGB")
        square_image_rgb.save(square_path, "PNG")

        # Extract and save mask
        if square_image_rgba.mode == "RGBA":
            square_mask = square_image_rgba.split()[3]
        else:
            square_mask = Image.new("L", square_image_rgba.size, 255)
        square_mask.save(mask_square_path, "PNG")

        square_dimensions = square_image_rgba.size

        # Build metadata for this GT
        gt_metadata = {
            "gt_index": int(idx),
            "gt_number": int(gt_num),
            "is_selected": bool(is_selected),
            "background_ratio": float(ratio),
            "object_area": int(gt_data.get("object_area", 0)),
            "background_area": int(gt_data.get("background_area", 0)),
            "total_area": int(gt_data.get("total_area", 0)),
            "square_path": f"gt_{gt_num}_square.png",
            "mask_square_path": f"gt_{gt_num}_mask_square.png",
            "square_dimensions": [int(d) for d in square_dimensions],
            "original_path": str(gt_data["path"])
        }

        # Create exact crop version (if enabled)
        if exact_crop_enabled:
            exact_image, bbox = crop_exact(
                image_no_bg,
                border_safety_margin_fraction=config.preprocess.border_safety_margin_fraction,
                edge_threshold=config.preprocess.edge_threshold
            )

            # Resize to max dimension if needed
            exact_image = resize_to_max_dimension(
                exact_image,
                config.preprocess.exact_crop_max_dimension
            )

            exact_image_rgb = exact_image.convert("RGB")
            exact_image_rgb.save(exact_path, "PNG")

            # Extract mask from exact version
            if exact_image.mode == "RGBA":
                exact_mask = exact_image.split()[3]
            else:
                exact_mask = Image.new("L", exact_image.size, 255)
            exact_mask.save(mask_exact_path, "PNG")

            exact_dimensions = exact_image.size
            exact_bbox = bbox

            gt_metadata.update({
                "exact_path": f"gt_{gt_num}_exact.png",
                "mask_exact_path": f"gt_{gt_num}_mask_exact.png",
                "exact_dimensions": [int(d) for d in exact_dimensions],
                "exact_bbox": [int(b) for b in exact_bbox]
            })

        metadata_list.append(gt_metadata)

        # Explicitly cleanup large objects after each image to prevent memory buildup
        del image_no_bg, alpha_full, alpha_cropped
        if exact_crop_enabled:
            del exact_image, exact_image_rgb, exact_mask
        import gc
        gc.collect()

    # Save metadata
    print(f"[DEBUG PREPROCESS] Saving metadata.json...")
    import sys
    sys.stdout.flush()

    metadata = {
        "gt_id": str(output_dir.name),  # Use directory name as gt_id
        "num_gts": int(len(ref_images_paths)),
        "num_processed": int(len(gts_to_process)),
        "selection_enabled": bool(gt_selection_enabled),
        "selected_index": int(selected_index) if gt_selection_enabled and selected_index >= 0 else None,
        "exact_crop_enabled": bool(exact_crop_enabled),
        "gts": metadata_list
    }

    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"[DEBUG PREPROCESS] Preprocessing completed successfully!")
    import sys
    sys.stdout.flush()

    return True


if __name__ == "__main__":
    from vfscore.config import get_config

    config = get_config()
    run_preprocess_gt(config)
