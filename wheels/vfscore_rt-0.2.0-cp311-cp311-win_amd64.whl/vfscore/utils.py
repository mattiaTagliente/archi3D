"""Utility functions for VFScore."""

import os
from pathlib import Path


def load_env_file(env_path: Path = Path(".env")) -> None:
    """Load environment variables from .env file.
    
    Simple .env loader that reads KEY=VALUE pairs.
    """
    if not env_path.exists():
        return
    
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue
            
            # Parse KEY=VALUE
            if "=" in line:
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip()
                
                # Remove quotes if present
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]
                
                # Set environment variable
                os.environ[key] = value


def make_gt_id(product_id: str, variant: str = "") -> str:
    """Create a GT-specific ID from product_id and variant for shared preprocessing.

    GT images are the same for all algorithms of the same product+variant, so we use
    a separate ID that excludes algorithm/job_id to enable sharing across algorithms.

    Args:
        product_id: Product identifier
        variant: Product variant (optional)

    Returns:
        GT ID string in format:
        - {product_id} (no variant)
        - {product_id}_{variant_sanitized} (with variant)

    Examples:
        >>> make_gt_id("353489")
        '353489'
        >>> make_gt_id("335888", "Curved backrest")
        '335888_curved-backrest'
    """
    # Build base (product_id + variant if present)
    if variant and variant.strip():
        sanitized_variant = variant.strip().lower().replace(" ", "-").replace("_", "-").replace("/", "-")
        return f"{product_id}_{sanitized_variant}"
    else:
        return product_id


def make_item_id(product_id: str, variant: str, algorithm: str = "", job_id: str = "") -> str:
    """Create a unique item_id from product_id, variant, algorithm, and optionally job_id.

    The item_id uniquely identifies a scorable item. When comparing multiple algorithms
    on the same product, the algorithm name is included to prevent collisions.

    Format:
        - No variant, no algorithm: "{product_id}"
        - With variant, no algorithm: "{product_id}_{variant}"
        - With algorithm (no variant): "{product_id}__{algorithm}"
        - With variant and algorithm: "{product_id}_{variant}__{algorithm}"
        - With job_id (optional): appends "_{job_id_short}" (first 8 chars)

    Args:
        product_id: The product identifier
        variant: The variant string (can be empty)
        algorithm: The generation algorithm (can be empty for GT-only items)
        job_id: Optional job identifier (first 8 chars used if provided)

    Returns:
        A composite identifier suitable for filesystem use
    """
    # Build base (product_id + variant if present)
    if variant and variant.strip():
        sanitized_variant = variant.strip().lower().replace(" ", "-").replace("_", "-").replace("/", "-")
        base = f"{product_id}_{sanitized_variant}"
    else:
        base = product_id

    # Add algorithm if present (separated by __)
    if algorithm and algorithm.strip():
        sanitized_algorithm = algorithm.strip().lower().replace(" ", "-").replace("_", "-").replace("/", "-")
        base = f"{base}__{sanitized_algorithm}"

    # Optionally add shortened job_id for uniqueness
    if job_id and job_id.strip():
        job_id_short = job_id.strip()[:8]  # First 8 chars
        base = f"{base}_{job_id_short}"

    return base


# Auto-load .env on import if in project root
if Path(".env").exists():
    load_env_file()
