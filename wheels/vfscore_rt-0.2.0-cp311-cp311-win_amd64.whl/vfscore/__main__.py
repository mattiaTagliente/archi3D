"""VFScore_RT CLI - Real-Time Visual Fidelity Scoring System."""

import os
import sys
from pathlib import Path

# Hard-disable bytecode generation when the CLI is invoked directly
sys.dont_write_bytecode = True
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")

# --- Pre-emptive .env loading to set PYTHONDONTWRITEBYTECODE ---
# This must run before any other imports that might trigger .pyc generation.
_env_path = Path(".env")
if _env_path.exists():
    with open(_env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            if key not in os.environ: # Avoid overwriting existing env vars
                os.environ[key] = value
# --- End of pre-emptive loading ---


# Suppress gRPC/Google library warnings before any imports
os.environ["GRPC_VERBOSITY"] = "NONE"
os.environ["GRPC_TRACE"] = ""
os.environ["GRPC_PYTHON_LOG_LEVEL"] = "ERROR"
os.environ["GLOG_minloglevel"] = "2"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["GOOGLE_LOGGING_VERBOSITY"] = "3"

from typing import Optional
import time
from contextlib import contextmanager

import typer
from rich.console import Console
from rich.panel import Panel

from vfscore import __version__
from vfscore.config import get_config

app = typer.Typer(
    name="vfscore",
    help="Real-Time Visual Fidelity Scoring for 3D Generated Objects",
    add_completion=False,
)
# Use legacy_windows=True for Windows compatibility
console = Console(legacy_windows=True)


def sanitize_error(e: Exception) -> str:
    """Sanitize exception message for Windows compatibility (remove emojis)."""
    return str(e).encode('ascii', errors='ignore').decode('ascii')


def format_elapsed_time(seconds: float) -> str:
    """Format elapsed time in human-readable format."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"


@contextmanager
def timed_step(step_name: str):
    """Context manager to time pipeline steps and log elapsed time."""
    start_time = time.time()
    try:
        yield
    finally:
        elapsed = time.time() - start_time
        console.print(f"[dim]Elapsed time: {format_elapsed_time(elapsed)}[/dim]")


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"[bold blue]VFScore_RT[/bold blue] version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """VFScore_RT - Real-Time Visual Fidelity Scoring for 3D Generated Objects."""
    pass


@app.command()
def ingest(
    config_path: Path = typer.Option("config.yaml", help="Path to config file"),
) -> None:
    """
    Ingest dataset: scan folders and create manifest.

    Reads:
    - datasets/refs/<item_id>/*.jpg|png
    - datasets/gens/<item_id>/*.glb
    - metadata/categories.csv

    Creates:
    - outputs/manifest.jsonl
    """
    from vfscore.ingest import run_ingest

    console.print(Panel.fit("[bold cyan]Step 1: Data Ingestion[/bold cyan]"))
    config = get_config()

    with timed_step("Data Ingestion"):
        try:
            manifest_path = run_ingest(config)
            console.print(f"[green][OK][/green] Manifest created: {manifest_path}")
        except Exception as e:
            console.print(f"[red][ERROR][/red] Ingestion failed: {sanitize_error(e)}")
            raise typer.Exit(code=1)


@app.command()
def preprocess_gt(
    config_path: Path = typer.Option("config.yaml", help="Path to config file"),
) -> None:
    """
    Preprocess ground truth photos: segment, standardize, label.

    Reads:
    - datasets/refs/<item_id>/*.jpg|png

    Creates:
    - outputs/preprocess/refs/<item_id>/gt_*.png
    """
    from vfscore.preprocess_gt import run_preprocess_gt

    console.print(Panel.fit("[bold cyan]Step 2: Ground Truth Preprocessing[/bold cyan]"))
    config = get_config()

    with timed_step("Ground Truth Preprocessing"):
        try:
            run_preprocess_gt(config)
            console.print("[green][OK][/green] Ground truth images preprocessed")
        except Exception as e:
            console.print(f"[red][ERROR][/red] GT preprocessing failed: {sanitize_error(e)}")
            raise typer.Exit(code=1)


@app.command()
def objective2(
    force: bool = typer.Option(False, "--force", help="Bypass all caches and regenerate everything"),
    config_path: Path = typer.Option("config.yaml", help="Path to config file"),
) -> None:
    """
    Run objective2 scoring pipeline: multi-GT pre-rendered library approach.

    This pipeline provides fast, accurate pose estimation by:
    1. Using ALL ground truth images (not just first)
    2. Pre-rendering a systematic library at 5 degree increments
    3. Matching all GT-candidate pairs to find best initialization
    4. Refining from the best match pair using gradient descent

    Reads:
    - outputs/manifest.jsonl
    - outputs/preprocess/refs/<item_id>/gt_*.png (ALL GT images)
    - GLB files from manifest

    Creates:
    - outputs/objective/<item_id>/prerender_library/ (library renders)
    - outputs/objective/<item_id>/matching/ (match results)
    - outputs/objective/<item_id>/pose_priors.json
    - outputs/objective/<item_id>/hq/hq_render.png
    - outputs/objective/<item_id>/final.json
    """
    from vfscore.objective2.pipeline_objective2 import run_objective2_pipeline

    console.print(Panel.fit("[bold cyan]Objective2 Scoring Pipeline[/bold cyan]"))
    config = get_config()

    with timed_step("Objective2 Scoring"):
        try:
            run_objective2_pipeline(config, force_cache=force)
            console.print("[green][OK][/green] Objective2 scoring complete")
        except Exception as e:
            console.print(f"[red][ERROR][/red] Objective2 scoring failed: {sanitize_error(e)}")
            raise typer.Exit(code=1)


@app.command()
def aggregate_objective(
    config_path: Path = typer.Option("config.yaml", help="Path to config file"),
) -> None:
    """
    Aggregate objective scoring results.

    Reads:
    - outputs/objective/<item_id>/final.json

    Creates:
    - outputs/results/objective_per_item.jsonl
    - outputs/results/objective_per_item.csv
    - outputs/results/objective_summary.json
    """
    from vfscore.aggregate_objective import aggregate_objective_results

    console.print(Panel.fit("[bold cyan]Objective Results Aggregation[/bold cyan]"))
    config = get_config()

    with timed_step("Objective Aggregation"):
        try:
            aggregate_objective_results(config)
            console.print("[green][OK][/green] Objective results aggregated")
        except Exception as e:
            console.print(f"[red][ERROR][/red] Aggregation failed: {sanitize_error(e)}")
            raise typer.Exit(code=1)


@app.command()
def report_objective(
    config_path: Path = typer.Option("config.yaml", help="Path to config file"),
) -> None:
    """
    Generate HTML report for objective scoring results.

    Reads:
    - outputs/results/objective_per_item.jsonl
    - outputs/objective/<item_id>/hq/render.png
    - outputs/preprocess/refs/<item_id>/gt_1.png

    Creates:
    - outputs/report/objective_report.html
    """
    from vfscore.report_objective import generate_objective_report

    console.print(Panel.fit("[bold cyan]Objective Report Generation[/bold cyan]"))
    config = get_config()

    with timed_step("Objective Report"):
        try:
            report_path = generate_objective_report(config)
            if report_path:
                console.print(f"[green][OK][/green] Objective report generated: {report_path}")
        except Exception as e:
            console.print(f"[red][ERROR][/red] Report generation failed: {sanitize_error(e)}")
            raise typer.Exit(code=1)


@app.command()
def run_all(
    fast: bool = typer.Option(False, help="Fast mode (not implemented yet)"),
    force: bool = typer.Option(False, "--force", help="Bypass all caches and regenerate everything"),
    config_path: Path = typer.Option("config.yaml", help="Path to config file"),
) -> None:
    """
    Run the complete pipeline: ingest -> preprocess -> objective2 scoring -> aggregate -> report.

    Pipeline features:
    - Multi-GT support: uses ALL reference photos
    - Pre-rendered library: systematic spherical sweep at 5 degree increments
    - GPU-accelerated: pyrender rendering (NO Blender needed for pose estimation)
    - Validation render: verify pose before expensive HQ Blender render
    - Best initialization: starts from best GT-candidate match
    """
    console.print(Panel.fit("[bold magenta]VFScore_RT Complete Pipeline[/bold magenta]"))

    console.print("[bold cyan]OBJECTIVE2 MODE (Real-Time)[/bold cyan]")
    console.print("[cyan]Multi-GT pre-rendered library approach[/cyan]")
    if fast:
        console.print("[yellow]Fast mode enabled[/yellow]")

    # Run objective2 pipeline
    steps = [
        ("ingest", lambda: ingest(config_path)),
        ("preprocess-gt", lambda: preprocess_gt(config_path)),
        ("objective2", lambda: objective2(
            force=force,
            config_path=config_path
        )),
        ("aggregate-objective", lambda: aggregate_objective(config_path)),
        ("report-objective", lambda: report_objective(config_path)),
    ]

    for step_name, step_func in steps:
        try:
            step_func()
        except Exception as e:
            console.print(f"[red]Pipeline stopped at: {step_name}[/red]")
            raise typer.Exit(code=1)

    console.print("\n[bold green][OK] Pipeline complete![/bold green]")


if __name__ == "__main__":
    app()
