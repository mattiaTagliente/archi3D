"""VFScore Evaluator - Public API for archi3D integration.

This module provides a simplified interface to the VFScore objective2 pipeline,
designed for integration with archi3D's adapter pattern.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

# Import after defining public function to avoid circular imports
def evaluate_visual_fidelity(
    cand_glb: str,
    ref_images: list[str],
    out_dir: str,
    repeats: int = 1,
    timeout_s: int | None = None,
    workspace: str | None = None,
    blender_exe: str | None = None,
) -> dict[str, Any]:
    """
    Evaluate visual fidelity of a generated 3D model against reference images.

    Args:
        cand_glb: Path to candidate GLB file (generated 3D model)
        ref_images: List of paths to reference (ground truth) images
        out_dir: Output directory for results and artifacts
        repeats: Number of LLM scoring repeats for consistency (default: 3)
        timeout_s: Optional timeout in seconds
        workspace: Optional workspace path (for config resolution)
        blender_exe: Optional Blender executable path override

    Returns:
        Dict with evaluation results:
        {
            "vfscore_overall_median": int (0-100 score),
            "vf_subscores_median": {
                "finish": int,
                "texture_identity": int,
                "texture_scale_placement": int
            },
            "repeats_n": int,
            "scores_all": [int, ...],
            "subscores_all": [{...}, ...],
            "iqr": float,
            "std": float,
            "llm_model": str,
            "rubric_weights": {
                "finish": float,
                "texture_identity": float,
                "texture_scale_placement": float
            },
            "render_settings": {
                "engine": "cycles",
                "hdri": str,
                "camera": str,
                "seed": int
            },
            "render_runtime_s": float,
            "scoring_runtime_s": float,
            "tool_version": str,
            "config_hash": str,
            "artifacts_dir": str,  # Path to vfscore_artifacts directory
            "gt_image": str,       # Relative path to GT image used (from artifacts_dir)
            "render_image": str    # Relative path to HQ render used (from artifacts_dir)
        }

    Raises:
        FileNotFoundError: If GLB or reference images don't exist
        ValueError: If configuration is invalid
        RuntimeError: If evaluation fails
    """
    # Import here to avoid circular dependencies and allow lazy loading
    from vfscore.config import load_config  # noqa: PLC0415
    from vfscore.objective2.pipeline_objective2 import Objective2Pipeline  # noqa: PLC0415
    from vfscore.data_sources.archi3d_source import Archi3DSource  # noqa: PLC0415
    import vfscore  # noqa: PLC0415
    import hashlib  # noqa: PLC0415
    import time  # noqa: PLC0415
    import gc  # noqa: PLC0415
    import sys  # noqa: PLC0415

    start_time = time.perf_counter()

    # Convert paths
    cand_glb_path = Path(cand_glb)
    ref_images_paths = [Path(p) for p in ref_images]
    out_dir_path = Path(out_dir)

    # Validate inputs
    if not cand_glb_path.exists():
        raise FileNotFoundError(f"Candidate GLB not found: {cand_glb}")

    for ref_img in ref_images_paths:
        if not ref_img.exists():
            raise FileNotFoundError(f"Reference image not found: {ref_img}")

    # Create output directory
    out_dir_path.mkdir(parents=True, exist_ok=True)

    # Load VFScore configuration with embedded defaults
    # Paths (blender_exe, hdri) should be passed through archi3d config
    workspace_path_obj = Path(workspace) if workspace else None
    blender_exe_path = Path(blender_exe) if blender_exe else None
    config = load_config(
        workspace_path=workspace_path_obj,
        blender_exe=blender_exe_path
    )

    # Override output directory to use provided out_dir
    # The pipeline will create a subdirectory: out_dir / item_id
    config.objective.priors_cache_dir = out_dir_path.parent

    # Compute config hash for reproducibility
    # Use mode='json' to serialize Path objects as strings
    config_str = json.dumps(config.model_dump(mode='json'), sort_keys=True)
    config_hash = hashlib.sha256(config_str.encode()).hexdigest()[:16]

    # Preprocess GT images using VFScore's preprocessing pipeline
    # The pipeline expects: config.paths.out_dir / "preprocess" / "refs" / gt_id
    from vfscore.utils import make_gt_id  # noqa: PLC0415
    from vfscore.preprocess_gt import preprocess_gt_images_standalone  # noqa: PLC0415

    item_id = out_dir_path.name
    product_id = item_id  # For archi3D integration, item_id serves as product_id
    variant = ""

    gt_id = make_gt_id(product_id, variant)
    gt_preprocess_dir = config.paths.out_dir / "preprocess" / "refs" / gt_id

    # Preprocess GT images (removes background, creates square/exact versions, generates metadata)
    print(f"[DEBUG] Preprocessing {len(ref_images_paths)} GT image(s)...")
    preprocessing_success = preprocess_gt_images_standalone(
        ref_images_paths,
        gt_preprocess_dir,
        config
    )

    if not preprocessing_success:
        raise RuntimeError("Failed to preprocess GT images")

    # Force garbage collection after preprocessing to free memory
    # This helps prevent memory corruption issues on Windows when transitioning to pipeline
    print("[DEBUG] Forcing garbage collection after preprocessing...")
    sys.stdout.flush()

    # Aggressive cleanup: run GC multiple times and give Windows time to release memory
    gc.collect()
    gc.collect()  # Second pass to catch circular references
    time.sleep(1.0)  # Longer pause to ensure ONNX/rembg memory is fully released

    print("[DEBUG] Garbage collection complete")
    sys.stdout.flush()

    # Verify preprocessing outputs
    metadata_path = gt_preprocess_dir / "metadata.json"
    if not metadata_path.exists():
        raise RuntimeError(f"GT preprocessing did not produce metadata.json at {metadata_path}")

    # Create record for pipeline
    record = {
        "item_id": item_id,
        "product_id": product_id,
        "variant": variant,
        "glb_path": str(cand_glb_path.absolute()),
    }

    # Debug: Print record details
    print(f"[DEBUG] VFScore record:")
    print(f"  item_id: {record['item_id']}")
    print(f"  product_id: {record['product_id']}")
    print(f"  variant: {record['variant']}")
    print(f"  glb_path: {record['glb_path']}")
    print(f"  glb exists: {Path(record['glb_path']).exists()}")
    print(f"  gt_id: {gt_id}")
    print(f"  gt_preprocess_dir: {gt_preprocess_dir}")
    print(f"  gt_preprocess_dir exists: {gt_preprocess_dir.exists()}")
    gt_files = list(gt_preprocess_dir.glob('*')) if gt_preprocess_dir.exists() else []
    print(f"  gt files ({len(gt_files)}): {[f.name for f in gt_files]}")

    # Initialize pipeline
    from vfscore.objective2.pipeline_objective2 import Objective2Pipeline  # noqa: PLC0415

    pipeline = Objective2Pipeline(config=config, force_cache=False)

    # Run evaluation
    try:
        print(f"[DEBUG] Calling pipeline._process_item()")
        result = pipeline._process_item(record)
        print(f"[DEBUG] Pipeline returned: {type(result)}, is None: {result is None}")
        if result:
            print(f"[DEBUG] Result keys: {list(result.keys()) if isinstance(result, dict) else 'not a dict'}")
    except Exception as e:
        print(f"[DEBUG] Pipeline raised exception: {type(e).__name__}: {e}")
        raise RuntimeError(f"VFScore evaluation failed: {e}") from e

    if result is None:
        raise RuntimeError("VFScore evaluation returned no result")

    # Load artifacts.json to get GT and render paths
    # The pipeline creates artifacts in out_dir_path / "vfscore_artifacts"
    artifacts_dir = out_dir_path / "vfscore_artifacts"
    artifacts_json_path = artifacts_dir / "artifacts.json"

    gt_image_rel = None
    render_image_rel = None
    if artifacts_json_path.exists():
        with open(artifacts_json_path, 'r', encoding='utf-8') as f:
            artifacts = json.load(f)
            gt_image_rel = artifacts.get("gt")
            render_image_rel = artifacts.get("render")

    # Extract timing from result
    total_runtime = time.perf_counter() - start_time
    render_runtime = result.get("time_seconds", total_runtime * 0.8)  # Estimate if not available
    scoring_runtime = total_runtime - render_runtime

    # Note: GT images remain in gt_preprocess_dir for potential reuse across evaluations
    # The preprocessed GT directory is at: config.paths.out_dir / "preprocess" / "refs" / gt_id

    # Extract pose parameters from result
    params = result.get("params", {})

    # Build comprehensive response for objective2 pipeline
    # Score is 0-1, convert to 0-100 for compatibility
    raw_score = result.get("score", 0.0)
    score_0_100 = int(raw_score * 100)

    response = {
        # Status (handled by adapter)
        # "vf_status": set by adapter
        # "vf_error": set by adapter

        # Core metrics
        "vfscore_overall_median": score_0_100,  # Final combined score (0-100)
        "lpips_distance": float(result.get("lpips", 0.0)),  # Raw LPIPS (0-1)
        "lpips_model": config.objective.lpips.model,  # "alex", "vgg", or "squeeze"
        "iou": float(result.get("iou", 0.0)),  # Mask IoU (0-1)
        "mask_error": float(result.get("mask_error", 0.0)),  # 1 - IoU
        "pose_confidence": float(result.get("iou", 0.0)),  # Same as IoU

        # Score combination parameters
        "gamma": float(config.objective.combiner.gamma),
        "pose_compensation_c": float(config.objective.combiner.pose_compensation_c),

        # Final pose parameters
        "azimuth_deg": float(params.get("azimuth_deg", 0.0)),
        "elevation_deg": float(params.get("elevation_deg", 0.0)),
        "radius": float(params.get("radius", 0.0)),
        "fov_deg": float(params.get("fov_deg", 0.0)),
        "obj_yaw_deg": float(params.get("obj_yaw_deg", 0.0)),

        # Pipeline statistics
        "pipeline_mode": result.get("pipeline_mode", "objective2"),
        "num_step2_candidates": result.get("num_step2_candidates"),
        "num_step4_candidates": result.get("num_step4_candidates"),
        "num_selected_candidates": result.get("num_selected_candidates"),
        "best_lpips_idx": result.get("best_lpips_idx"),

        # Performance & provenance
        "render_runtime_s": float(render_runtime),
        "scoring_runtime_s": float(scoring_runtime),
        "tool_version": vfscore.__version__,
        "config_hash": config_hash,

        # Artifact paths (workspace-relative)
        "artifacts_dir": str(artifacts_dir.relative_to(out_dir_path.parent.parent)) if artifacts_dir.exists() else None,
        "gt_image_path": gt_image_rel,
        "render_image_path": render_image_rel,

        # DEPRECATED fields (kept for backward compatibility, will be removed)
        "vf_subscores_median": {"finish": None, "texture_identity": None, "texture_scale_placement": None},
        "repeats_n": 1,
        "scores_all": [score_0_100],
        "subscores_all": [],
        "iqr": 0.0,
        "std": 0.0,
        "llm_model": None,
        "rubric_weights": {"finish": None, "texture_identity": None, "texture_scale_placement": None},
        "render_settings": {"engine": "pyrender", "hdri": None, "camera": None, "seed": None}
    }

    return response


__all__ = ["evaluate_visual_fidelity"]
