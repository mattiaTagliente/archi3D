"""Configuration management for VFScore_RT."""

from pathlib import Path
from typing import Any, Dict, List

import yaml
from pydantic import BaseModel, ConfigDict, Field


class PathsConfig(BaseModel):
    """File paths configuration."""

    refs_dir: Path = Field(default=Path("datasets/refs"))
    gens_dir: Path = Field(default=Path("datasets/gens"))
    categories: Path = Field(default=Path("metadata/categories.csv"))
    hdri: Path = Field(default=Path("assets/lights.hdr"))
    out_dir: Path = Field(default=Path("outputs"))
    blender_exe: Path = Field(default=Path("C:/Program Files/Blender Foundation/Blender 4.5/blender.exe"))


class CameraConfig(BaseModel):
    """Camera positioning configuration."""

    radius: float = 2.2
    azimuth_deg: float = 45.0
    elevation_deg: float = 35.0


class RenderConfig(BaseModel):
    """Blender rendering configuration."""

    engine: str = "cycles"
    samples: int = 256
    fov_deg: float = 20.0
    camera: CameraConfig = Field(default_factory=CameraConfig)
    object_prez_rot_z_deg: float = 20.0
    filmic: bool = True
    film_transparent: bool = True
    denoiser: str = "OIDN"
    resolution: int = 1024


class PreprocessConfig(BaseModel):
    """Image preprocessing configuration."""

    canvas_px: int = 1024
    bg_rgb: List[int] = Field(default=[0, 0, 0])
    crop_margin_frac: float = 0.05
    feather_px: int = 2
    label_bar_frac: float = 0.06
    segmentation_model: str = "u2netp"  # Use smaller model (4.7MB vs 176MB) for stability

    # GT selection configuration
    gt_selection_enabled: bool = True  # Enable single GT selection (False = process all GTs)
    gt_selection_criterion: str = "min_background_ratio"  # Selection criterion

    # Exact crop configuration
    exact_crop_enabled: bool = True  # Enable exact crop mode (False = square only)
    exact_crop_max_dimension: int = 1024  # Max dimension for exact crop images
    border_safety_margin_fraction: float = 0.02  # Required border as fraction of image size (matches radius calibration)
    edge_threshold: int = 64  # Threshold for bounding box calculation (0-255, matches radius calibration)


class DataSourceConfig(BaseModel):
    """Data source configuration for ingest."""

    type: str = "legacy"  # "legacy" or "archi3d"

    # Legacy source options
    base_path: Path | None = None  # Base directory for all legacy data (e.g., Testing/)
    dataset_folder: str = "dataset"  # Relative to base_path (e.g., "dataset")
    database_csv: Path = Field(default=Path("database.csv"))  # Relative to VFScore root
    selected_objects_csv: Path | None = Field(default=Path("selected_objects_optimized.csv"))

    # Archi3D source options
    workspace: Path | None = None
    run_id: str | None = None
    items_csv: Path | None = None
    generations_csv: Path | None = None
    refs_source: str = "used"  # "used" (default, uses used_image_*), "source" (uses source_image_*), or "folder" (uses source_folder)


class SilhouetteConfig(BaseModel):
    """Silhouette processing configuration."""

    binarize_threshold: int = 16
    erode_dilate_px: int = 1


class LPIPSConfig(BaseModel):
    """LPIPS configuration."""

    model: str = "alex"  # "vgg", "alex", or "squeeze"
    device: str = "cpu"  # "auto", "cuda", or "cpu"
    normalize: bool = True


class CombinerConfig(BaseModel):
    """Score combiner configuration."""

    gamma: float = 1.0
    pose_compensation_c: float = 0.5


class RadiusCalibrationConfig(BaseModel):
    """Radius calibration configuration for objective2 pipeline."""

    # Resolution for calibration renders (higher = more accurate)
    resolution: int = 256  # Use 256px for precise calibration
    pose_estimation_resolution: int = 256  # Resolution for pose estimation (steps 2 and 4)
    fov_deg: float = 20.0  # FOV for calibration renders (should match expected GT camera FOV)

    # Initial radius adjustment (Step 1) - performed before orientation search
    initial_adjustment_yaw: float = 45.0  # Yaw angle for initial radius check (degrees)
    initial_adjustment_elevation: float = 10.0  # Elevation angle for initial radius check (degrees)

    # Border safety check configuration (different margins for different stages)
    initial_border_safety_margin_fraction: float = 0.03  # Initial adjustment margin (3% = 7.68px @ 256px)
    intermediate_border_safety_margin_fraction: float = 0.005  # Intermediate adjustment margin (0.5% = 1.28px @ 256px)
    final_border_safety_margin_fraction: float = 0.005  # Final adjustment margin (0.5% = 1.28px @ 256px)
    radius_adjustment_step: float = 0.001  # Radius adjustment per iteration (0.1% per step)
    max_radius_adjustment_iterations: int = 1000  # Maximum iterations for radius adjustment

    # Binary search configuration (disabled by default - border adjustment is sufficient)
    binary_search_enabled: bool = False  # Enable area-ratio binary search (can undo border safety)
    max_iterations: int = 50  # Maximum binary search iterations
    tolerance: float = 0.002  # Convergence tolerance (0.2% = 0.002)
    target_bias: float = 1.02  # Target area_ratio (1.02 = 2% larger for robust matching)

    # Final recalibration after pose estimation
    final_radius_recalibration_enabled: bool = False  # Recalibrate radius at final estimated pose before HQ render

    # Mask processing
    edge_threshold: int = 64  # Threshold for mask area counting (0-255, lower includes anti-aliased edges)

    # Pipeline selection
    pipeline_mode: str = "tri_criterion"  # "tri_criterion" (new default), "aspect_ratio" (AR only), or "max_area" (area only)

    # Selection criterion for Step 2 (coarse pose search)
    step2_selection_criterion: str = "iou_ar"  # Which metric(s) to use for Step 2 candidate selection:
                                               # - "iou": IoU (Intersection over Union) only
                                               # - "area": Projected area only
                                               # - "ar": Aspect ratio only
                                               # - "iou_ar": IoU + AR hybrid (best IoU in top N% with AR constraint, default)
                                               # - "tri_criterion": Combined IoU + Area + AR

    # Selection criterion for Step 4 (final candidate selection)
    step4_selection_criterion: str = "iou"  # Which metric(s) to use for Step 4 candidate selection:
                                            # - "iou": IoU only (default, best silhouette match)
                                            # - "area": Projected area only
                                            # - "ar": Aspect ratio only
                                            # - "iou_ar": IoU + AR hybrid
                                            # - "tri_criterion": Combined IoU + Area + AR

    # Tri-criterion parameters (used when selection_criterion = "tri_criterion")
    tri_criterion_initial_top_fraction: float = 0.001  # Initial top fraction for tri-criterion (0.1%)
    tri_criterion_step_fraction: float = 0.001  # Increment step for expanding search (0.1%)
    tri_criterion_num_candidates: int = 15  # Number of candidates to select in step 4 (DEPRECATED, use step4_num_candidates)
    tri_criterion_coarse_iterations: int = 2  # Number of step 2 + step 3 iterations (coarse search + radius adjustment)

    # IoU + AR hybrid parameters (used when selection_criterion = "iou_ar")
    iou_ar_top_fraction: float = 0.03  # Top fraction for IoU+AR hybrid (e.g., 0.03 = top 3%)

    # Step 4 + Step 5 iteration configuration
    step4_5_iterations: int = 3  # Number of step 4 + step 5 iterations (candidate selection + radius adjustment)

    # Step 4 configuration
    step4_search_mode: str = "fine"  # "coarse" (full range search) or "fine" (local search around best Step 3 pose)
    step4_num_candidates: int = 15  # Number of candidates to select in Step 4

    # Step 5 configuration (radius adjustment after Step 4)
    step5_border_safety_margin_fraction: float = 0.005  # Border safety margin for Step 5 radius adjustment

    # Step 6 configuration (RGB + LPIPS scoring, renamed from old Step 5)
    step6_lpips_enabled: bool = False  # Enable LPIPS scoring in Step 6 (if False, select best from Step 4 only)

    # Crop operation control (individual per step)
    step2_crop_enabled: bool = True  # Enable exact crop in Step 2 pose estimation (coarse search, affects accuracy)
    step4_crop_enabled: bool = True  # Enable exact crop in Step 4 pose estimation (final candidate selection, affects accuracy)

    # Legacy orientation matching methods (used when pipeline_mode != "tri_criterion")
    orientation_method: str = "aspect_ratio"  # "aspect_ratio" (match GT bbox) or "max_area" (maximize area)
    ar_iou_filtering_enabled: bool = True  # Enable IoU filtering after AR matching (resolves ambiguity)
    ar_iou_filtering_top_fraction: float = 0.2  # Fraction of top AR candidates to score by IoU (0.0-1.0)

    # Iterative coarse search configuration (legacy pipeline only)
    coarse_iterations: int = 1  # Number of coarse search + radius adjustment iterations (1-5)

    # Yaw search configuration (full range, all pipelines)
    yaw_search_start: float = 0.0  # Starting yaw angle (degrees)
    yaw_search_stop: float = 360.0  # Ending yaw angle (degrees, non-inclusive)
    yaw_search_coarse_step: float = 4.0  # Coarse search step (degrees)
    yaw_search_fine_step: float = 0.5  # Fine search step around best coarse match (degrees)
    yaw_search_fine_range: float = 10.0  # Fine search range around best coarse match (degrees)

    # Elevation search configuration (full range, all pipelines)
    elevation_search_enabled: bool = True  # Enable elevation search (if False, use elevation=0)
    elevation_search_start: float = 0.0  # Starting elevation angle (degrees)
    elevation_search_stop: float = 45.0  # Ending elevation angle (degrees)
    elevation_search_coarse_step: float = 5.0  # Coarse search step (degrees)
    elevation_search_fine_step: float = 0.5  # Fine search step (degrees)
    elevation_search_fine_range: float = 10.0  # Fine search range around best coarse match (degrees)


class Objective2LibraryConfig(BaseModel):
    """Library generation configuration for objective2 pipeline."""

    radius_multipliers: List[float] = Field(default=[1.0])  # Multipliers for calibrated radius
    fov_values: List[float] = Field(default=[20.0])  # FOV values to test
    elevation_values: List[float] = Field(default=[0.0, 5.0, 10.0, 20.0, 30.0, 40.0])  # Elevation angles
    angular_step_deg: float = 4.0  # Yaw sweep step size (360/4 = 90 steps)
    radius_calibration: RadiusCalibrationConfig = Field(default_factory=RadiusCalibrationConfig)  # Calibration settings


class Objective2RefinementConfig(BaseModel):
    """Refinement configuration for objective2 pipeline."""

    enabled: bool = False  # Set to False to skip refinement and use library pose directly
    max_iterations: int = 100
    learning_rate: float = 0.01
    error_threshold: float = 0.10
    min_improvement: float = 0.0001
    trust_azimuth: float = 3.0
    trust_elevation: float = 3.0
    trust_log_radius: float = 0.05
    trust_yaw: float = 3.0
    trust_fov: float = 2.0
    freeze_yaw_until_iou: float = 0.70
    gradient_epsilon: float = 0.05
    iou_weight: float = 1.0  # Weight for IoU term in objective
    edge_weight: float = 0.25  # Weight for edge term (MUST match library matching!)


class Objective2Config(BaseModel):
    """Configuration for objective2 pipeline."""

    library: Objective2LibraryConfig = Field(default_factory=Objective2LibraryConfig)
    refinement: Objective2RefinementConfig = Field(default_factory=Objective2RefinementConfig)

    # GT matching mode configuration
    gt_matching_mode: str = "single"  # "single" (use selected GT) or "multi" (all GTs, fallback)

    # HQ render mode configuration
    hq_render_mode: str = "exact_crop"  # "exact_crop" (non-square) or "square" (backward compat)

    # Step 7 exact crop configuration
    step7_exact_crop_enabled: bool = False  # Enable exact crop of HQ render before LPIPS comparison

    # Library generation control
    skip_library_if_ar: bool = True  # Skip library generation when using AR-based orientation matching

    # Debug configuration
    debug_save_images: bool = False  # Save debug images for every step (with bboxes on crops)
    debug_save_top_candidates: bool = False  # Save top 15 candidates separately for IoU/Area/AR


class ObjectiveConfig(BaseModel):
    """Objective scoring pipeline configuration."""

    enabled: bool = True
    use_cache: bool = True  # Enable smart caching (renders, LPIPS, etc.)
    priors_cache_dir: Path = Field(default=Path("outputs/objective"))  # Per-item cache
    refinement_error_threshold: float = 0.30  # Only refine if library match error < this
    hq_error_threshold: float = 0.25  # Only do HQ render if refined error < this
    validation_error_threshold: float = 0.05  # Validation IoU gate threshold
    render_resolution: int = 512  # Resolution for mask renders (pose confidence)
    hq_resolution: int = 1024  # Resolution for final HQ render (LPIPS comparison)
    silhouette: SilhouetteConfig = Field(default_factory=SilhouetteConfig)
    lpips: LPIPSConfig = Field(default_factory=LPIPSConfig)
    combiner: CombinerConfig = Field(default_factory=CombinerConfig)
    objective2: Objective2Config = Field(default_factory=Objective2Config)


class Config(BaseModel):
    """Main configuration model."""

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        protected_namespaces=(),
        extra="allow",
    )

    paths: PathsConfig = Field(default_factory=PathsConfig)
    render: RenderConfig = Field(default_factory=RenderConfig)
    preprocess: PreprocessConfig = Field(default_factory=PreprocessConfig)
    data_source: DataSourceConfig = Field(default_factory=DataSourceConfig)
    objective: ObjectiveConfig = Field(default_factory=ObjectiveConfig)


def _deep_merge(base: dict, override: dict) -> dict:
    """Deep merge two dictionaries.

    Values in 'override' take precedence over 'base'.
    Nested dictionaries are merged recursively.

    Args:
        base: Base dictionary
        override: Override dictionary

    Returns:
        Merged dictionary
    """
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            # Recursively merge nested dicts
            result[key] = _deep_merge(result[key], value)
        else:
            # Override value
            result[key] = value

    return result


# Module-level functions for Config operations (extracted from class methods to avoid Cython/Pydantic conflicts)

def load_config_from_file(config_path: Path | str = "config.yaml") -> Config:
    """Load configuration from YAML file with local overrides.

    This function loads the base config.yaml and then applies any overrides
    from config.local.yaml if it exists. This allows developers to have
    machine-specific settings without modifying the shared config.

    Args:
        config_path: Path to the base configuration file

    Returns:
        Config instance with applied overrides
    """
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    # Load base configuration
    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    # Check for local configuration override
    local_config_path = config_path.parent / "config.local.yaml"
    if local_config_path.exists():
        with open(local_config_path, "r", encoding="utf-8") as f:
            local_data = yaml.safe_load(f)

        # Deep merge local config into base config
        if local_data:
            data = _deep_merge(data, local_data)

    return Config(**data)


def get_project_root_for_config(config: Config) -> Path:
    """Get project root directory (parent of config.yaml)."""
    return Path.cwd()


def resolve_config_paths(config: Config, project_root: Path | None = None) -> None:
    """Resolve all relative paths to absolute paths.

    Args:
        config: Config instance to modify
        project_root: Optional project root path (defaults to current directory)
    """
    if project_root is None:
        project_root = get_project_root_for_config(config)

    # Resolve paths
    for field_name in ["refs_dir", "gens_dir", "categories", "hdri", "out_dir"]:
        path = getattr(config.paths, field_name)
        if not path.is_absolute():
            setattr(config.paths, field_name, project_root / path)

    # Resolve objective paths
    if not config.objective.priors_cache_dir.is_absolute():
        config.objective.priors_cache_dir = project_root / config.objective.priors_cache_dir

    # Resolve data_source paths (base_path should be absolute, dataset_folder is relative)
    for field_name in ["base_path", "database_csv", "selected_objects_csv",
                      "workspace", "items_csv", "generations_csv"]:
        path = getattr(config.data_source, field_name)
        if path is not None and isinstance(path, Path) and not path.is_absolute():
            setattr(config.data_source, field_name, project_root / path)


# Global config instance
_config: Config | None = None


def get_config() -> Config:
    """Get global configuration instance."""
    global _config
    if _config is None:
        _config = load_config_from_file()
        resolve_config_paths(_config)
    return _config


def reload_config(config_path: Path | str = "config.yaml") -> Config:
    """Reload configuration from file."""
    global _config
    _config = load_config_from_file(config_path)
    resolve_config_paths(_config)
    return _config


def load_config(
    workspace_path: Path | None = None,
    blender_exe: Path | str | None = None,
    hdri_path: Path | str | None = None,
) -> Config:
    """
    Load VFScore configuration with embedded defaults and optional overrides.

    This function is designed for integration with archi3D, where technical
    parameters are embedded as Pydantic defaults, and paths are passed from
    archi3D configuration.

    Args:
        workspace_path: Optional archi3D workspace path for relative path resolution
        blender_exe: Optional Blender executable path override
        hdri_path: Optional HDRI file path override

    Returns:
        Config instance with embedded defaults and applied overrides
    """
    # Create config with embedded defaults (no file loading)
    config = Config()

    # Override paths if provided
    if blender_exe is not None:
        config.paths.blender_exe = Path(blender_exe)

    if hdri_path is not None:
        config.paths.hdri = Path(hdri_path)

    # If workspace_path provided, resolve relative paths relative to it
    if workspace_path is not None:
        workspace_path = Path(workspace_path)

        # Check for optional vfscore_config.yaml override in workspace
        override_config_path = workspace_path / "vfscore_config.yaml"
        if override_config_path.exists():
            # Load override config and merge
            with open(override_config_path, "r", encoding="utf-8") as f:
                import yaml
                override_data = yaml.safe_load(f)
                if override_data:
                    # Apply overrides (shallow merge for now)
                    for key, value in override_data.items():
                        if hasattr(config, key):
                            setattr(config, key, value)

        # Resolve paths relative to workspace if not absolute
        if not config.paths.hdri.is_absolute():
            config.paths.hdri = workspace_path / config.paths.hdri

        # Resolve out_dir relative to workspace if not absolute
        if not config.paths.out_dir.is_absolute():
            config.paths.out_dir = workspace_path / config.paths.out_dir

    return config
