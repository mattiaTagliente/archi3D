"""Aggregate objective scoring results into summary reports."""

import json
from pathlib import Path
from typing import Dict, List

from rich.console import Console

console = Console(legacy_windows=True)


def aggregate_objective_results(config) -> None:
    """Aggregate objective scoring results from all items.

    Reads final.json from each item and creates:
    - outputs/results/objective_per_item.jsonl (detailed results)
    - outputs/results/objective_per_item.csv (summary table)
    - outputs/results/objective_summary.json (overall statistics)

    Args:
        config: VFScore configuration
    """
    objective_dir = config.objective.priors_cache_dir
    results_dir = config.paths.out_dir / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    # Discover all final.json files
    final_files = list(objective_dir.glob("*/final.json"))

    if not final_files:
        console.print(
            "[yellow]No objective results found. "
            "Run 'vfscore objective' first.[/yellow]"
        )
        return

    console.print(f"Found {len(final_files)} objective results")

    # Load all results
    all_results = []
    for final_path in final_files:
        try:
            with open(final_path, "r") as f:
                result = json.load(f)
                all_results.append(result)
        except Exception as e:
            console.print(f"[yellow]Warning: Failed to load {final_path}: {e}[/yellow]")

    if not all_results:
        console.print("[yellow]No valid objective results to aggregate[/yellow]")
        return

    # Sort by item_id
    all_results.sort(key=lambda x: x["item_id"])

    # Write JSONL
    jsonl_path = results_dir / "objective_per_item.jsonl"
    with open(jsonl_path, "w") as f:
        for result in all_results:
            f.write(json.dumps(result) + "\n")

    # Write CSV
    csv_path = results_dir / "objective_per_item.csv"
    with open(csv_path, "w") as f:
        # Header
        f.write(
            "item_id,final_score,lpips,pose_confidence,gamma,pose_compensation_c,"
            "fov_deg,azimuth_deg,elevation_deg,radius,obj_yaw_deg\n"
        )

        # Data
        for result in all_results:
            params = result.get("params", {})
            f.write(
                f"{result['item_id']},"
                f"{result['final_score']:.4f},"
                f"{result['lpips']:.4f},"
                f"{result['pose_confidence']:.4f},"
                f"{result['gamma']:.2f},"
                f"{result['pose_compensation_c']:.2f},"
                f"{params.get('fov_deg', 0):.1f},"
                f"{params.get('azimuth_deg', 0):.1f},"
                f"{params.get('elevation_deg', 0):.1f},"
                f"{params.get('radius', 0):.2f},"
                f"{params.get('obj_yaw_deg', 0):.1f}\n"
            )

    # Compute summary statistics
    scores = [r["final_score"] for r in all_results]
    lpips_values = [r["lpips"] for r in all_results]
    pose_confidences = [r["pose_confidence"] for r in all_results]

    summary = {
        "n_items": len(all_results),
        "final_score": {
            "mean": sum(scores) / len(scores),
            "min": min(scores),
            "max": max(scores),
            "median": sorted(scores)[len(scores) // 2],
        },
        "lpips": {
            "mean": sum(lpips_values) / len(lpips_values),
            "min": min(lpips_values),
            "max": max(lpips_values),
            "median": sorted(lpips_values)[len(lpips_values) // 2],
        },
        "pose_confidence": {
            "mean": sum(pose_confidences) / len(pose_confidences),
            "min": min(pose_confidences),
            "max": max(pose_confidences),
            "median": sorted(pose_confidences)[len(pose_confidences) // 2],
        },
    }

    summary_path = results_dir / "objective_summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    console.print(f"[green]Objective results aggregated:[/green]")
    console.print(f"  - JSONL: {jsonl_path}")
    console.print(f"  - CSV: {csv_path}")
    console.print(f"  - Summary: {summary_path}")
    console.print(f"\n[cyan]Summary Statistics:[/cyan]")
    console.print(f"  Final Score: {summary['final_score']['mean']:.3f} "
                  f"(min: {summary['final_score']['min']:.3f}, "
                  f"max: {summary['final_score']['max']:.3f})")
    console.print(f"  LPIPS: {summary['lpips']['mean']:.3f} "
                  f"(min: {summary['lpips']['min']:.3f}, "
                  f"max: {summary['lpips']['max']:.3f})")
    console.print(f"  Pose Confidence: {summary['pose_confidence']['mean']:.3f} "
                  f"(min: {summary['pose_confidence']['min']:.3f}, "
                  f"max: {summary['pose_confidence']['max']:.3f})")
